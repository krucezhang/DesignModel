﻿var GrapeCityAutoTest = window.GrapeCityAutoTest;
if (typeof (GrapeCityAutoTest) === 'undefined') {
    GrapeCityAutoTest = window.GrapeCityAutoTest = {};
    GrapeCityAutoTest.TestObjects = {};

    GrapeCityAutoTest.loadScript = function (src) {
        GrapeCityAutoTest.loadScriptComplete = false;
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.onload = script.onreadystatechange = function () {
            if (!this.readyState || this.readyState === "loaded" || this.readyState === "complete") {
                GrapeCityAutoTest.loadScriptComplete = true;
                /* Handle memory leak in IE */
                script.onload = script.onreadystatechange = null;
            }
        };
        script.src = src;
        head.appendChild(script);
    };
    GrapeCityAutoTest.loadStylesheet = function (href) {
        GrapeCityAutoTest.loadStylesheetComplete = false;
        var head = document.getElementsByTagName('head')[0];
        var link = document.createElement('link');
        link.type = 'text/css';
        link.rel = "stylesheet";
        link.onload = link.onreadystatechange = function () {
            if (!this.readyState || this.readyState === "loaded" || this.readyState === "complete") {
                GrapeCityAutoTest.loadStylesheetComplete = true;
                /* Handle memory leak in IE */
                link.onload = link.onreadystatechange = null;
            }
        };
        link.href = href;
        head.appendChild(link);
    };

    GrapeCityAutoTest.buildStringFunction = function () {
        if (GrapeCityAutoTest.isInstallStringFunction) return;
        if (!String.prototype.trim) {
            String.prototype.trim = function () {
                return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
            };
        }
        if (!String.prototype.contains) {
            String.prototype.contains = function (str) {
                return this.indexOf(str) !== -1;
            };
        }
        if (!String.prototype.regexMatch) {
            String.prototype.regexMatch = function (pattern) {
                return new window.RegExp(pattern).test(this);
            };
        }
        if (!String.prototype.startsWith) {
            String.prototype.startsWith = function (prefix) {
                return this.slice(0, prefix.length) === prefix;
            };
        }
        if (!String.prototype.endsWith) {
            String.prototype.endsWith = function (suffix) {
                return this.indexOf(suffix, this.length - suffix.length) !== -1;
            };
        }
        GrapeCityAutoTest.isInstallStringFunction = true;
    };
    GrapeCityAutoTest.fillMatrixTableMap = function (map, row, keyMap) {
        var rowStyle = window.getComputedStyle ? window.getComputedStyle(row, null) : null || row.currentStyle;
        if (rowStyle.display != 'none') {
            var rowHeight = row.clientHeight;
            var cellIndex = 0;
            var cellLength = row.cells.length;
            for (var cIndex = 0; cIndex < cellLength; cIndex++) {
                var cell = row.cells[cIndex];
                var cellStyle = window.getComputedStyle ? window.getComputedStyle(cell, null) : null || cell.currentStyle;
                if (cellStyle.display != 'none') {
                    var mapRow = map.rows[map.currentRowIndex];
                    while (1) {
                        if (mapRow && mapRow[cellIndex]) {
                            cellIndex++;
                            continue;
                        }
                        break;
                    }
                    var rowSpan = Math.max(1, cell.rowSpan) - (rowHeight > 0 ? 0 : 1);
                    var colSpan = Math.max(1, cell.colSpan);
                    if (rowSpan > 0) {
                        if (keyMap) {
                            GrapeCityAutoTest.buildStringFunction();
                            map.columnKeyMap.push({ key: cell.textContent.trim(), value: cellIndex });
                        }
                        for (var rowIx = map.currentRowIndex; rowIx < (map.currentRowIndex + rowSpan) ; rowIx++) {
                            for (var colIx = cellIndex; colIx < (cellIndex + colSpan) ; colIx++) {
                                if (!map.rows[rowIx]) map.rows[rowIx] = [];
                                map.rows[rowIx][colIx] = cell;
                            }
                        }
                    }
                }
            }
            if (rowHeight > 0) {
                row.matrixMapRowIndex = map.currentRowIndex;
                map.rowList.push(row);
                map.currentRowIndex++;
            }
        }
    };
    GrapeCityAutoTest.queryMatrixTableMapRow = function (ele, mRowIndex, keyValues, hasColKeyMap, textCondition) {
        if (!ele) throw 'Table elment can not is Null.';
        hasColKeyMap = hasColKeyMap || false;
        var matchItem = GrapeCityAutoTest.queryMatchFunc = function (map, kValues, rowIndex) {
            if (!kValues || (kValues && kValues.length <= 0)) return false;
            for (var i = 0; i < kValues.length; i++) {
                var tdElement = map.rows[rowIndex][kValues[i].key];
                if (!tdElement) return false;
                GrapeCityAutoTest.buildStringFunction();
                var eleText = tdElement.textContent.trim();
                var values = kValues[i].value;
                var isMatched = false;
                if (!textCondition || textCondition === "Equals" || textCondition === "None") {
                    isMatched = false;
                    for (var vId = 0; vId < values.length; vId++) {
                        if (eleText == values[vId]) {
                            isMatched = true;
                            break;
                        }
                    }
                    if (!isMatched) return false;
                } else {
                    isMatched = false;
                    for (var vId = 0; vId < values.length; vId++) {
                        if (eleText.contains(values[vId])) {
                            isMatched = true;
                            break;
                        }
                    }
                    if (!isMatched) return false;
                }
            }
            return true;
        };
        if (!ele.matrixMap) {
            ele.matrixMap = { queryRowIndex: 0, currentRowIndex: 0, rows: [], rowList: [], columnKeyMap: null };
            var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
            if (MutationObserver) {
                var MutationObserverConfig = {
                    childList: true,
                    subtree: true,
                    attributes: true/*,characterData: true*/
                };
                ele.matrixMap.observer = new MutationObserver(function (mutations) {
                    ele.matrixMap.observer.disconnect();
                    ele.matrixMap = null;
                });
                ele.matrixMap.observer.observe(ele, MutationObserverConfig);
            }
            else if (ele.addEventListener) {
                ele.matrixMap.observerDOMModified = function (evt) {
                    ele.removeEventListener("DOMSubtreeModified", ele.matrixMap.observerDOMModified, false);
                    ele.matrixMap = null;
                };
                ele.addEventListener("DOMSubtreeModified", ele.matrixMap.observerDOMModified, false);
            }
            else {
                console.log('unsupported observer DOM changed.');
            }
        }
        if (mRowIndex >= 0 && mRowIndex < ele.matrixMap.currentRowIndex) return ele.matrixMap.rowList[mRowIndex];
        if (keyValues && keyValues.length > 0) {
            var maxRowIndex = ele.matrixMap.currentRowIndex;
            for (var rIndex = 0; rIndex < maxRowIndex; rIndex++) {
                if (matchItem(ele.matrixMap, keyValues, rIndex)) return ele.matrixMap.rowList[rIndex];
            }
        }
        var rows = ele.rows;
        if (rows && rows.length > ele.matrixMap.currentRowIndex) {
            var currentRowLength = rows.length;
            for (var rowIx = ele.matrixMap.queryRowIndex; rowIx < currentRowLength; rowIx++) {
                if (hasColKeyMap && !ele.matrixMap.columnKeyMap) ele.matrixMap.columnKeyMap = [];
                GrapeCityAutoTest.fillMatrixTableMap(ele.matrixMap, rows[rowIx], ele.matrixMap.columnKeyMap);
                ele.matrixMap.queryRowIndex++;
                var rowIndex = ele.matrixMap.currentRowIndex - 1;
                if (rowIndex >= 0 && (rowIndex == mRowIndex || matchItem(ele.matrixMap, keyValues, rowIndex))) return ele.matrixMap.rowList[rowIndex];
            }
        }
        return null;
    };
    GrapeCityAutoTest.getMatrixTableRows = function (ele) {
        if (ele && ele.matrixMap) return ele.matrixMap.rowList;
        GrapeCityAutoTest.queryMatrixTableMapRow(ele, -1, null, false);
        return ele.matrixMap.rowList;
    };
    GrapeCityAutoTest.getMatrixTableCell = function (ele, rowIndex, cellIndex) {
        if (ele && ele.matrixMap && rowIndex < ele.matrixMap.currentRowIndex) return ele.matrixMap.rows[rowIndex][cellIndex];
        GrapeCityAutoTest.queryMatrixTableMapRow(ele, rowIndex, null, false);
        if (rowIndex < ele.matrixMap.currentRowIndex) return ele.matrixMap.rows[rowIndex][cellIndex];
    };
    GrapeCityAutoTest.getMatrixTableColumnMap = function (ele) {
        if (ele && ele.matrixMap && ele.matrixMap.columnKeyMap) return ele.matrixMap.columnKeyMap;
        GrapeCityAutoTest.queryMatrixTableMapRow(ele, -1, null, true);
        return ele.matrixMap.columnKeyMap;
    };
    GrapeCityAutoTest.scrollIntoView = function (domElement) {
        /*if(domElement.scrollIntoViewIfNeeded){
           domElement.scrollIntoViewIfNeeded(false);
           return;
        }*/
        domElement.scrollIntoView(false);
    };
    GrapeCityAutoTest.scrollDomIntoView = function (domElement) {

        GrapeCityAutoTest.scrollIntoView(domElement);
        if (!window.jQuery) return;

        var $targetDom = $(domElement);
        var converter = {
            vertical: { x: false, y: true },
            horizontal: { x: true, y: false },
            both: { x: true, y: true },
            x: { x: true, y: false },
            y: { x: false, y: true }
        };

        var settings = {
            duration: 0,
            direction: 'both'
        };

        var rootrx = /^(?:html)$/i;

        var borders = function (domElement, styles) {
            styles = styles || (document.defaultView && document.defaultView.getComputedStyle ? document.defaultView.getComputedStyle(domElement, null) : domElement.currentStyle);
            var px = document.defaultView && document.defaultView.getComputedStyle ? true : false;
            var b = {
                top: (parseFloat(px ? styles.borderTopWidth : $.css(domElement, 'borderTopWidth')) || 0),
                left: (parseFloat(px ? styles.borderLeftWidth : $.css(domElement, 'borderLeftWidth')) || 0),
                bottom: (parseFloat(px ? styles.borderBottomWidth : $.css(domElement, 'borderBottomWidth')) || 0),
                right: (parseFloat(px ? styles.borderRightWidth : $.css(domElement, 'borderRightWidth')) || 0)
            };
            return {
                top: b.top,
                left: b.left,
                bottom: b.bottom,
                right: b.right,
                vertical: b.top + b.bottom,
                horizontal: b.left + b.right
            };
        };

        var dimensions = function ($element) {
            var win = $(window);
            var isRoot = rootrx.test($element[0].nodeName);
            return {
                border: isRoot ? { top: 0, left: 0, bottom: 0, right: 0 } : borders($element[0]),
                scroll: {
                    top: (isRoot ? win : $element).scrollTop(),
                    left: (isRoot ? win : $element).scrollLeft()
                },
                scrollbar: {
                    right: isRoot ? 0 : $element.innerWidth() - $element[0].clientWidth,
                    bottom: isRoot ? 0 : $element.innerHeight() - $element[0].clientHeight
                },
                rect: (function () {
                    var r = $element[0].getBoundingClientRect();
                    return {
                        top: isRoot ? 0 : r.top,
                        left: isRoot ? 0 : r.left,
                        bottom: isRoot ? $element[0].clientHeight : r.bottom,
                        right: isRoot ? $element[0].clientWidth : r.right
                    };
                })()
            };
        };

        $.extend($.expr.pseudos || $.expr[":"], {
            scrollable: function (element, index, meta, stack) {
                var direction = converter[typeof (meta[3]) === 'string' && meta[3].toLowerCase()] || converter.both;
                var styles = (document.defaultView && document.defaultView.getComputedStyle ? document.defaultView.getComputedStyle(element, null) : element.currentStyle);
                var overflow = {
                    x: scrollValue[styles.overflowX.toLowerCase()] || false,
                    y: scrollValue[styles.overflowY.toLowerCase()] || false,
                    isRoot: rootrx.test(element.nodeName)
                };

                /* check if completely unscrollable (exclude HTML element because it's special) */
                if (!overflow.x && !overflow.y && !overflow.isRoot) {
                    return false;
                }

                var size = {
                    height: {
                        scroll: element.scrollHeight,
                        client: element.clientHeight
                    },
                    width: {
                        scroll: element.scrollWidth,
                        client: element.clientWidth
                    },
                    /* check overflow.x/y because iPad (and possibly other tablets) don't dislay scrollbars */
                    scrollableX: function () {
                        return (overflow.x || overflow.isRoot) && this.width.scroll > this.width.client;
                    },
                    scrollableY: function () {
                        return (overflow.y || overflow.isRoot) && this.height.scroll > this.height.client;
                    }
                };
                return direction.y && size.scrollableY() || direction.x && size.scrollableX();
            }
        });

        var scrollValue = {
            auto: true,
            scroll: true,
            visible: false,
            hidden: false
        };

        var options = $.extend({}, settings);
        options.direction = converter[typeof (options.direction) === 'string' && options.direction.toLowerCase()] || converter.both;

        var dirStr = 'both';

        var el = $targetDom.eq(0);
        var scroller = el.closest(':scrollable(' + dirStr + ')');
        /* check if there's anything to scroll in the first place */
        if (scroller.length > 0) {
            scroller = scroller.eq(0);

            var dim = {
                e: dimensions(el),
                s: dimensions(scroller)
            };

            var rel = {
                top: dim.e.rect.top - (dim.s.rect.top + dim.s.border.top),
                bottom: dim.s.rect.bottom - dim.s.border.bottom - dim.s.scrollbar.bottom - dim.e.rect.bottom,
                left: dim.e.rect.left - (dim.s.rect.left + dim.s.border.left),
                right: dim.s.rect.right - dim.s.border.right - dim.s.scrollbar.right - dim.e.rect.right
            };

            var animOptions = {};

            /* vertical scroll */
            if (options.direction.y === true) {
                if (rel.top < 0) {
                    animOptions.scrollTop = dim.s.scroll.top + rel.top;
                }
                else if (rel.top > 0 && rel.bottom < 0) {
                    animOptions.scrollTop = dim.s.scroll.top + Math.min(rel.top, -rel.bottom);
                }
            }

            /* horizontal scroll */
            if (options.direction.x === true) {
                if (rel.left < 0) {
                    animOptions.scrollLeft = dim.s.scroll.left + rel.left;
                }
                else if (rel.left > 0 && rel.right < 0) {
                    animOptions.scrollLeft = dim.s.scroll.left + Math.min(rel.left, -rel.right);
                }
            }

            /* scroll if needed */
            if (!$.isEmptyObject(animOptions)) {
                if (rootrx.test(scroller[0].nodeName)) {
                    scroller = $('html,body');
                }
                scroller
                    .animate(animOptions, options.duration)
                    .eq(0) /* we want function to be called just once (ref. 'html,body') */
                    .queue(function (next) {
                        $.isFunction(options.complete) && options.complete.call(scroller[0]);
                        next();
                    });
            }
            else {
                /* when there's nothing to scroll, just call the 'complete' function */
                $.isFunction(options.complete) && options.complete.call(scroller[0]);
            }
        }
    };

    GrapeCityAutoTest.watchJSError = function () {
        if (GrapeCityAutoTest.Errors) return;
        GrapeCityAutoTest.Errors = [];
        window.onerror = function (msg, url, lineNo, columnNo, error) {
            var errorObj = {};
            errorObj.Message = msg;
            errorObj.URL = url;
            errorObj.Line = lineNo;
            errorObj.Column = columnNo;
            errorObj.ErrorObject = error;
            GrapeCityAutoTest.Errors.push(errorObj);
            return false;
        };
    };

    GrapeCityAutoTest.getStyleConverterDom = function () {
        var styleDom = document.getElementById('ATTestStyleConverter');
        if (styleDom) {
            return styleDom;
        }
        styleDom = document.createElement('span');
        styleDom.id = 'ATTestStyleConverter';
        styleDom.style.visibility = 'hidden';
        styleDom.style.top = '-10000px';
        styleDom.style.left = '-10000px';
        styleDom.style.lineHeight = 'normal';
        document.body.insertBefore(styleDom, null);
        return styleDom;
    };

    GrapeCityAutoTest.setCookie = function (c_name, value, expiredays) {
        var exdate = new Date();
        exdate.setDate(exdate.getDate() + expiredays);
        document.cookie = c_name + '=' + escape(value) + ((expiredays == null) ? '' : ';expires=' + exdate.toGMTString());
    };

    GrapeCityAutoTest.getCookie = function (name) {
        var arr, reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)');
        if (arr = document.cookie.match(reg))
            return (unescape(arr[2]));
        else
            return null;
    };

    GrapeCityAutoTest.delCookie = function (name) {
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval = GrapeCityAutoTest.getCookie(name);
        if (cval)
            document.cookie = name + '=' + ';expires=' + exp.toGMTString();
    };

    GrapeCityAutoTest.deleteAllCookies = function () {
        var cookies = document.cookie.split(";");
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i];
            var eqPos = cookie.indexOf("=");
            var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
            document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
        }
    };

    GrapeCityAutoTest.parserDate = function (date) {
        if (!date) return date;
        var dateArray = new Array('System.DateTime', date.getFullYear(), date.getMonth() + 1, date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
        return dateArray;
    };

    GrapeCityAutoTest.parseRect = function (rect) {
        if (!rect) return rect;
        var rectArray = new Array('System.Drawing.Rectangle', rect.x || rect.left, rect.y || rect.top, rect.width, rect.height);
        return rectArray;
    };

    GrapeCityAutoTest.parsePoint = function (point) {
        if (!point) return point;
        var x = point.x || point.left;
        var y = point.y || point.top;
        var pointArray = new Array('System.Drawing.Point', x, y);
        return pointArray;
    };

    GrapeCityAutoTest.parseJSONObj = function (jsonObj) {
        var objArray = new Array('SpreadASPExtension.Common.JSONObj', JSON.stringify(jsonObj));
        return objArray;
    };

    GrapeCityAutoTest.parseColor = function (color) {
        if (GrapeCityAutoTest.isNullOrUndefined(color)) {
            return null;
        }

        if (isHexColor(color)) {
            return ConvertToRGBfromHex(color);
        }
        if (isRGBColorStr(color)) {
            return convertToRGBfromRGBName(color);
        }
        if (color.toLowerCase() == 'transparent') {
            var RGBArray = new Array();
            RGBArray[0] = 'System.Drawing.Color';
            RGBArray[1] = 0;
            RGBArray[2] = 255;
            RGBArray[3] = 255;
            RGBArray[4] = 255;
            return RGBArray;
        }
        return convertToRGBfromName(color);
    };

    var isColor = function (value) {
        if (value == null)
            return false;
        for (var i = 0; i < colorName.length; i++) {
            var color = colorName[i].split(' ');
            if (value.toString().toLowerCase() == color[0].toLowerCase()) {
                return true;
            }
        }
        if (isHexColor(value)) {
            return true;
        }
        if (isRGBColorStr(value)) {
            return true;
        }
        return false;
    };

    GrapeCityAutoTest.parseArray = function (array) {
        var list = new Array();
        list.push('System.Collections.Generic.List<object>');
        for (var i = 0; i < array.length; i++) {
            var obj = GrapeCityAutoTest.parser(array[i]);
            list.push(obj);
        }
        return list;
    };

    GrapeCityAutoTest.parser = function (obj) {
        if (typeof obj == 'string') {
            return 'GCATString_' + obj;
        }
        if (typeof obj == 'number' || typeof obj == 'boolean' || typeof obj == undefined || typeof obj == null) {
            return obj;
        }
        if (typeof obj == 'object') {
            if ((obj instanceof Date) || Object.prototype.toString.call(obj) === '[object Date]') {
                return GrapeCityAutoTest.parserDate(obj);
            }
            if ((obj instanceof Array) || (Array.isArray && Array.isArray(obj))) {
                return GrapeCityAutoTest.parseArray(obj);
            }
            if ((obj instanceof HTMLCollection) || Object.prototype.toString.call(obj) === '[object HTMLCollection]') {
                return GrapeCityAutoTest.parseArray(obj);
            }
        }
        return obj;
    };

    GrapeCityAutoTest.isNullOrUndefined = function (value) {
        if (!value) {
            if (value === 0 || value === false) { return false; }
            return true;
        }
        return false;
    };

    GrapeCityAutoTest.simulate = function (f, c, d, e) {
        var b, a = null;
        for (b in GrapeCityAutoTest.eventMatchers) {
            if (GrapeCityAutoTest.eventMatchers[b].test(c))
            { a = b; break }
        }
        if (!a) return !1;
        document.createEvent ? (b = document.createEvent(a), a == 'HTMLEvents' ? b.initEvent(c, !0, !0) : b.initMouseEvent(c, !0, !0, document.defaultView, 0, d, e, d, e, !1, !1, !1, !1, 0, null), f.dispatchEvent(b))
        : (a = document.createEventObject(), a.detail = 0, a.screenX = d, a.screenY = e, a.clientX = d, a.clientY = e, a.ctrlKey = !1, a.altKey = !1, a.shiftKey = !1, a.metaKey = !1, a.button = 1, f.fireEvent('on' + c, a));
        return !0;
    };
    GrapeCityAutoTest.eventMatchers = { HTMLEvents: /^(?:load|unload|abort|error|select|change|submit|reset|focus|blur|resize|scroll)$/, MouseEvents: /^(?:click|dblclick|mouse(?:down|up|over|move|out))$/ };

    var isRGBColorStr = function (color) {
        if (color) {
            var bg = color.toString().match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);
            if (bg && bg.length >= 4) {
                return true;
            }
        }
        return false;
    };

    var convertToRGBfromRGBName = function (name) {
        var bg = name.toString().match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);
        var RGBArray = new Array();
        RGBArray[0] = 'System.Drawing.Color';
        if (bg[4]) { RGBArray[1] = parseFloat(bg[4]); } else { RGBArray[1] = 1; };
        RGBArray[2] = parseInt(bg[1]);
        RGBArray[3] = parseInt(bg[2]);
        RGBArray[4] = parseInt(bg[3]);
        return RGBArray;
    };

    var ConvertToRGBfromHex = function (color) {
        var HexColor2Decimal = function (s, n) {
            return 16 * HexDigit2Dec(s.charAt(n))
                    + HexDigit2Dec(s.charAt(n + 1));
        };
        var HexDigit2Dec = function (hex) {
            if ('0' <= hex && hex <= '9')
                return parseInt(hex);
            if (hex == 'A' || hex == 'a')
                return 10;
            if (hex == 'B' || hex == 'b')
                return 11;
            if (hex == 'C' || hex == 'c')
                return 12;
            if (hex == 'D' || hex == 'd')
                return 13;
            if (hex == 'E' || hex == 'e')
                return 14;
            if (hex == 'F' || hex == 'f')
                return 15;
            return 0;
        };

        var red = HexColor2Decimal(color, 1);
        var green = HexColor2Decimal(color, 3);
        var blue = HexColor2Decimal(color, 5);
        var RGBArray = new Array();
        RGBArray[0] = 'System.Drawing.Color';
        RGBArray[1] = 1;
        RGBArray[2] = red;
        RGBArray[3] = green;
        RGBArray[4] = blue;
        return RGBArray;
    };

    var convertToRGBfromName = function (name) {
        for (var i = 0; i < colorName.length; i++) {
            var color = colorName[i].split(' ');
            if (name.toLowerCase() == color[0].toLowerCase()) {
                return ConvertToRGBfromHex(color[1]);
            }
        }
        return null;
    };

    var isHexColor = function (s) {
        var i, c;
        if (s == null || s.toString().charAt(0) != '#' || s.length != 7)
            return false;
        for (i = 1; i < 7; ++i) {
            c = s.charAt(i);
            if ('0' <= c && c <= '9')
                continue;
            if ('A' <= c && c <= 'F')
                continue;
            if ('a' <= c && c <= 'f')
                continue;
            return false;  /* bad character */
        }
        return true;
    };

    var colorName = new Array();
    colorName.push(
        'AliceBlue #F0F8FF',
        'AntiqueWhite #FAEBD7',
        'Aqua #00FFFF',
        'Aquamarine #7FFFD4',
        'Azure #F0FFFF',
        'Beige #F5F5DC',
        'Bisque #FFE4C4',
        'Black #000000',
        'BlanchedAlmond #FFEBCD',
        'Blue #0000FF',
        'BlueViolet #8A2BE2',
        'Brown #A52A2A',
        'BurlyWood #DEB887',
        'CadetBlue #5F9EA0',
        'Chartreuse #7FFF00',
        'Chocolate #D2691E',
        'Coral #FF7F50',
        'CornflowerBlue #6495ED',
        'Cornsilk #FFF8DC',
        'Crimson #DC143C',
        'Cyan #00FFFF',
        'DarkBlue #00008B',
        'DarkCyan #008B8B',
        'DarkGoldenRod #B8860B',
        'DarkGray #A9A9A9',
        'DarkGreen #006400',
        'DarkKhaki #BDB76B',
        'DarkMagenta #8B008B',
        'DarkOliveGreen #556B2F',
        'Darkorange #FF8C00',
        'DarkOrchid #9932CC',
        'DarkRed #8B0000',
        'DarkSalmon #E9967A',
        'DarkSeaGreen #8FBC8F',
        'DarkSlateBlue #483D8B',
        'DarkSlateGray #2F4F4F',
        'DarkTurquoise #00CED1',
        'DarkViolet #9400D3',
        'DeepPink #FF1493',
        'DeepSkyBlue #00BFFF',
        'DimGray #696969',
        'DodgerBlue #1E90FF',
        'Feldspar #D19275',
        'FireBrick #B22222',
        'FloralWhite #FFFAF0',
        'ForestGreen #228B22',
        'Fuchsia #FF00FF',
        'Gainsboro #DCDCDC',
        'GhostWhite #F8F8FF',
        'Gold #FFD700',
        'GoldenRod #DAA520',
        'Gray #808080',
        'Green #008000',
        'GreenYellow #ADFF2F',
        'HoneyDew #F0FFF0',
        'HotPink #FF69B4',
        'IndianRed #CD5C5C',
        'Indigo #4B0082',
        'Ivory #FFFFF0',
        'Khaki #F0E68C',
        'Lavender #E6E6FA',
        'LavenderBlush #FFF0F5',
        'LawnGreen #7CFC00',
        'LemonChiffon #FFFACD',
        'LightBlue #ADD8E6',
        'LightCoral #F08080',
        'LightCyan #E0FFFF',
        'LightGoldenRodYellow #FAFAD2',
        'LightGrey #D3D3D3',
        'LightGreen #90EE90',
        'LightPink #FFB6C1',
        'LightSalmon #FFA07A',
        'LightSeaGreen #20B2AA',
        'LightSkyBlue #87CEFA',
        'LightSlateBlue #8470FF',
        'LightSlateGray #778899',
        'LightSteelBlue #B0C4DE',
        'LightYellow #FFFFE0',
        'Lime #00FF00',
        'LimeGreen #32CD32',
        'Linen #FAF0E6',
        'Magenta #FF00FF',
        'Maroon #800000',
        'MediumAquaMarine #66CDAA',
        'MediumBlue #0000CD',
        'MediumOrchid #BA55D3',
        'MediumPurple #9370D8',
        'MediumSeaGreen #3CB371',
        'MediumSlateBlue #7B68EE',
        'MediumSpringGreen #00FA9A',
        'MediumTurquoise #48D1CC',
        'MediumVioletRed #C71585',
        'MidnightBlue #191970',
        'MintCream #F5FFFA',
        'MistyRose #FFE4E1',
        'Moccasin #FFE4B5',
        'NavajoWhite #FFDEAD',
        'Navy #000080',
        'OldLace #FDF5E6',
        'Olive #808000',
        'OliveDrab #6B8E23',
        'Orange #FFA500',
        'OrangeRed #FF4500',
        'Orchid #DA70D6',
        'PaleGoldenRod #EEE8AA',
        'PaleGreen #98FB98',
        'PaleTurquoise #AFEEEE',
        'PaleVioletRed #D87093',
        'PapayaWhip #FFEFD5',
        'PeachPuff #FFDAB9',
        'Peru #CD853F',
        'Pink #FFC0CB',
        'Plum #DDA0DD',
        'PowderBlue #B0E0E6',
        'Purple #800080',
        'Red #FF0000',
        'RosyBrown #BC8F8F',
        'RoyalBlue #4169E1',
        'SaddleBrown #8B4513',
        'Salmon #FA8072',
        'SandyBrown #F4A460',
        'SeaGreen #2E8B57',
        'SeaShell #FFF5EE',
        'Sienna #A0522D',
        'Silver #C0C0C0',
        'SkyBlue #87CEEB',
        'SlateBlue #6A5ACD',
        'SlateGray #708090',
        'Snow #FFFAFA',
        'SpringGreen #00FF7F',
        'SteelBlue #4682B4',
        'Tan #D2B48C',
        'Teal #008080',
        'Thistle #D8BFD8',
        'Tomato #FF6347',
        'Transparent #FFFFFF',
        'Turquoise #40E0D0',
        'Violet #EE82EE',
        'VioletRed #D02090',
        'Wheat #F5DEB3',
        'White #FFFFFF',
        'WhiteSmoke #F5F5F5',
        'Yellow #FFFF00',
        'YellowGreen #9ACD3');
};