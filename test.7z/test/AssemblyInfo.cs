﻿// Assembly Selenium.Test.Toolkit, Version 1.0.0.0

[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.0", FrameworkDisplayName=".NET Framework 4")]
[assembly: System.Runtime.InteropServices.Guid("5d572fda-a5c4-4992-b0d6-984446dea103")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyTitle("Selenium.Test.Toolkit")]
[assembly: System.Reflection.AssemblyProduct("Selenium.Test.Toolkit")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2014")]
[assembly: System.Reflection.AssemblyTrademark("")]

