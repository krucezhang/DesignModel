﻿namespace Selenium.Test.Toolkit.Event
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class EventInfo : JSObject
    {
        public const string EVENT_ARGUMENTS = "EventArgs";
        public const string EVENT_NAME = "EventName";

        public EventInfo(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public ArrayObject<JSObject> Arguments
        {
            get
            {
                CodeSnippet jSPropertyJSSnippet = this.GetJSPropertyJSSnippet("EventArgs", "event_Args");
                if (this.IsNullJSObject(jSPropertyJSSnippet))
                {
                    return null;
                }
                return new ArrayObject<JSObject>(jSPropertyJSSnippet);
            }
        }

        public string EventName
        {
            get
            {
                return this.GetJSProperty<string>("EventName");
            }
        }
    }
}

