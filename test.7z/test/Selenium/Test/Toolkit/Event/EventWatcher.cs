﻿namespace Selenium.Test.Toolkit.Event
{
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class EventWatcher : ExecutableObject
    {
        private ExecutableObject _watchedObj;
        private const string FiredEventsHeader = "FiredEvents";

        public EventWatcher() : base(null)
        {
        }

        public EventWatcher(WebElementGUI watchedGUIObj) : this(watchedGUIObj.ExecutableAdapter)
        {
        }

        public EventWatcher(ExecutableObject watchedObj) : base(null)
        {
            this._watchedObj = watchedObj;
        }

        public void AssertFiredEvents(params object[] eventTypes)
        {
            ArrayObject<EventInfo> firedEvents = this.FiredEvents;
            bool flag = true;
            int length = firedEvents.length;
            flag = eventTypes.Length == length;
            if (flag)
            {
                for (int i = 0; i < length; i++)
                {
                    if (eventTypes[i].ToString() != firedEvents[i].EventName)
                    {
                        flag = false;
                        break;
                    }
                }
            }
            if (!flag)
            {
                string str = string.Empty;
                for (int j = 0; j < eventTypes.Length; j++)
                {
                    str = str + (string.IsNullOrEmpty(str) ? "" : ", ") + eventTypes[j].ToString();
                }
                string str2 = string.Empty;
                for (int k = 0; k < length; k++)
                {
                    str2 = str2 + (string.IsNullOrEmpty(str2) ? "" : ", ") + firedEvents[k].EventName;
                }
                throw new InvalidCastException("Expected Events:{" + str + "} " + Environment.NewLine + "Actual Events:{" + str2 + "}");
            }
        }

        public void bind(object eventType, CodeSnippet eventFunc = null)
        {
            this.bind(eventType, delegate (CodeSnippet func) {
                if (this.WatchedObj == null)
                {
                    throw new InvalidProgramException("Event watched Object is Null.");
                }
                CodeSnippet executeCode = ExecutableObject.GetInvokeJSSnippet(this.WatchedObj.DependedScript, "bind", null, "bindEvent1", new object[] { eventType, func });
                this.ExecuteJS(executeCode);
            }, eventFunc);
        }

        public void bind(object eventType, BindFunctionHandler functionHandler, CodeSnippet eventFunc = null)
        {
            CodeSnippet eventFunction = eventFunc;
            if (eventFunction == null)
            {
                eventFunction = this.GetEventFunction(eventType, null);
            }
            functionHandler(eventFunction);
        }

        public void ClearWatchInfo()
        {
            string snippet = string.Format("{0}.{1} = [];", base.DependedScript.CodeHeader, "FiredEvents");
            this.ExecuteJS(new CodeSnippet(string.Empty, snippet, new object[0]));
        }

        public override void Dispose()
        {
            this._watchedObj = null;
            base.Dispose();
        }

        protected override CodeSnippet GetDependedScript()
        {
            CodeSnippet dependedScript = base.GetDependedScript();
            if (dependedScript == null)
            {
                CodeSnippet executeCode = new CodeSnippet("eventWatcher", "var eventWatcher = {};" + string.Format(" eventWatcher.{0} = [];", "FiredEvents"), new object[0]);
                dependedScript = this.GetExecutedJSSnippet(executeCode, "EventWatcher");
                base.DependedScript = dependedScript;
            }
            return dependedScript;
        }

        private CodeSnippet GetEventFunction(object eventType = null, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "eventFunc1" : header;
            return new CodeSnippet(str, (((string.Empty + "var " + str + " = function(){") + "var eventInfo = {};") + string.Format("eventInfo.{0} = '{1}';", "EventName", eventType.ToString()) + string.Format("eventInfo.{0} = arguments;", "EventArgs")) + string.Format("{0}.{1}.push({2});", base.DependedScript.CodeHeader, "FiredEvents", "eventInfo") + "};", new object[0]);
        }

        public void WatchEvents(params object[] eventTypes)
        {
            this.ClearWatchInfo();
            foreach (object obj2 in eventTypes)
            {
                this.bind(obj2, null);
            }
        }

        public ArrayObject<EventInfo> FiredEvents
        {
            get
            {
                return new ArrayObject<EventInfo>(this.GetJSPropertyJSSnippet("FiredEvents", "firedEvents"));
            }
        }

        internal ExecutableObject WatchedObj
        {
            get
            {
                return this._watchedObj;
            }
        }

        public delegate void BindFunctionHandler(CodeSnippet eventFunc);
    }
}

