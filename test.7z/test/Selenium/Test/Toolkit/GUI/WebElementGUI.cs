﻿namespace Selenium.Test.Toolkit.GUI
{
    using GrapeCity.Win.Testing.Tools;
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Action;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.PageObjects;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;

    public class WebElementGUI : MarshalByRefObject, IElementGUI, IFindElementGUI, IProxyElement, IDisposable, IExecutable
    {
        private Rectangle _bounds;
        private Dictionary<string, By> _cachedClassFinders;
        private Dictionary<string, By> _customFinders;
        private CodeSnippet _dependedScript;
        private bool _doPrepareAction;
        private Selenium.Test.Toolkit.Core.FinderBuffer _finderBuffer;
        private IElementGUI _parent;
        private IUIActions _uiActions;
        private bool _useFinderBuffer;
        private IWebElement _webElement;

        public WebElementGUI(IWebElement webElement) : this(webElement, null)
        {
        }

        public WebElementGUI(IWebElement webElement, CodeSnippet dependedScript) : this(webElement, dependedScript, Rectangle.Empty, null)
        {
        }

        public WebElementGUI(IWebElement webElement, Rectangle bounds, IElementGUI parentGUI = null) : this(webElement, null, bounds, parentGUI)
        {
        }

        public WebElementGUI(IWebElement webElement, CodeSnippet dependedScript, Rectangle bounds, IElementGUI parentGUI = null)
        {
            this._bounds = Rectangle.Empty;
            this._doPrepareAction = true;
            this.AssignElement(webElement);
            this._dependedScript = dependedScript;
            this._bounds = bounds;
            this._parent = parentGUI;
            this.Initization();
        }

        protected virtual void AssignElement(IWebElement element)
        {
            this._webElement = element;
        }

        public virtual T AsTo<T>()
        {
            return TestUtility.CreateInstance<T>(this._dependedScript, this.WebElement, this.Parent, new object[0]);
        }

        internal virtual bool Contains(Point point)
        {
            return this.Bounds.Contains(point);
        }

        public virtual void Dispose()
        {
            this._parent = null;
            this._webElement = null;
            this._uiActions = null;
            this._customFinders = null;
            if (this._cachedClassFinders != null)
            {
                this._cachedClassFinders.Clear();
                this._cachedClassFinders = null;
            }
            if (this._dependedScript != null)
            {
                this._dependedScript.Dispose();
                this._dependedScript = null;
            }
            if (this._finderBuffer != null)
            {
                this._finderBuffer.Dispose();
                this._finderBuffer = null;
            }
        }

        protected virtual void EndAction()
        {
            Manager.Current.ActiveBrowser.WaitForAjax(0x2710);
        }

        public override bool Equals(object obj)
        {
            IElementGUI element = obj as IElementGUI;
            return (((element != null) && (base.GetType() == element.GetType())) && this.ReferenceElementEquals(element));
        }

        public virtual bool ExistDisplayedElement(IElementGUI element)
        {
            return (((element != null) && element.IsExistElement) && element.Visible);
        }

        public virtual bool ExistElement(IElementGUI element)
        {
            return ((element != null) && element.IsExistElement);
        }

        public DomElementGUI FindDisplayedElementGUI(By by)
        {
            return this.FindDisplayedElementGUI<DomElementGUI>(by);
        }

        public T FindDisplayedElementGUI<T>(By by)
        {
            return this.FindDisplayedElementGUI<T>(by, false);
        }

        public T FindDisplayedElementGUI<T>(By by, bool throwExpection)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.FindDisplayedElementGUI<T>(this.WebElement, by, throwExpection);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public IList<DomElementGUI> FindDisplayedElementGUIs(By by)
        {
            return this.FindDisplayedElementGUIs<DomElementGUI>(by);
        }

        public IList<T> FindDisplayedElementGUIs<T>(By by)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase))
            {
                return (IList<T>) obj2;
            }
            IList<T> list = TestUtility.FindDisplayedElementGUIs<T>(this.WebElement, by);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, list, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return list;
        }

        public DomElementGUI FindElementGUI(By by)
        {
            return this.FindElementGUI<DomElementGUI>(by);
        }

        public T FindElementGUI<T>(By by)
        {
            return this.FindElementGUI<T>(by, true);
        }

        public T FindElementGUI<T>(By by, bool throwExpection)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.FindElementGUI<T>(this.WebElement, by, throwExpection);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public IList<DomElementGUI> FindElementGUIs(By by)
        {
            return this.FindElementGUIs<DomElementGUI>(by);
        }

        public IList<T> FindElementGUIs<T>(By by)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase))
            {
                return (IList<T>) obj2;
            }
            IList<T> list = TestUtility.FindElementGUIs<T>(this.WebElement, by);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, list, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return list;
        }

        protected virtual CodeSnippet GetDependedScript()
        {
            if (this._dependedScript == null)
            {
                return this.GetWebElementRefScript();
            }
            return this._dependedScript;
        }

        internal virtual Rectangle GetDomElementBounds()
        {
            Point point = this.DomJQueryExecutable.offset();
            return new Rectangle(point.X, point.Y, this.DomJQueryExecutable.width(), this.DomJQueryExecutable.height());
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        protected virtual CodeSnippet GetWebElementRefScript()
        {
            return new CodeSnippet("domElement1", "var domElement1 = arguments[0];", new object[0]) { Args = { this.WebElement } };
        }

        protected virtual void Initization()
        {
        }

        protected virtual Point PointToClient(Point point)
        {
            throw new NotImplementedException();
        }

        protected virtual Point PointToPage(Point point)
        {
            throw new NotImplementedException();
        }

        protected virtual void PrepareAction()
        {
            if (this.DoPrepareAction)
            {
                Manager.DoMessageFlushAfterAction = true;
            }
            if (PageGUI.CheckElementEnabled && !this.Enabled)
            {
                this.WaitForElementEnabled();
            }
        }

        public bool ReferenceElementEquals(IElementGUI element)
        {
            return ((element != null) && this.WebElement.Equals(element.WebElement));
        }

        public virtual void scrollIntoView()
        {
            this.DomExecutable.InvokeJSMehtod("scrollIntoView", new object[0]);
        }

        public virtual void scrollIntoView(bool alignToTop)
        {
            this.DomExecutable.InvokeJSMehtod("scrollIntoView", new object[] { alignToTop });
        }

        protected virtual By TryGetByFinder(string key, By defaultFinder = null)
        {
            By by;
            By by3;
            By by4;
            if ((this._customFinders != null) && this.Finders.TryGetValue(key, out by))
            {
                return by;
            }
            for (IElementGUI tgui = this.Parent; tgui != null; tgui = tgui.Parent)
            {
                By by2;
                if (tgui.Finders.TryGetValue(key, out by2) && (by2 != null))
                {
                    return by2;
                }
            }
            if (this._cachedClassFinders == null)
            {
                Attribute[] attributes = Attribute.GetCustomAttributes(base.GetType(), typeof(ComponentFinderAttribute), true);
                this._cachedClassFinders = ComponentFinderAttribute.BuildFinders(attributes);
            }
            if (this._cachedClassFinders.TryGetValue(key, out by3))
            {
                return by3;
            }
            if (Manager.GlobalFinders.TryGetValue(key, out by4))
            {
                return by4;
            }
            return defaultFinder;
        }

        protected internal virtual void TryToScrollElementIntoView()
        {
            try
            {
                Manager.Current.GrapeCityAutoTest.InvokeJSMehtod("scrollDomIntoView", new object[] { this.DomExecutable });
            }
            catch
            {
            }
        }

        public virtual WebElementGUI UIClearValue()
        {
            this.PrepareAction();
            this.UIActions.UIClearValue(this.HotPoint);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIClick()
        {
            this.UIClick(this.HotPoint, MouseButtonType.Left, false);
            return this;
        }

        public virtual WebElementGUI UIClick(Point point, MouseButtonType mouseButtons = 0x100000, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or elementGUI size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIClick(point, mouseButtons);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIDoubleClick()
        {
            this.UIDoubleClick(this.HotPoint, false);
            return this;
        }

        public virtual WebElementGUI UIDoubleClick(Point point, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIDoubleClick(point);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIDragTo(WebElementGUI element, bool isPixelMove = false)
        {
            if (element == null)
            {
                throw new ArgumentNullException("The element is Null.");
            }
            this.PrepareAction();
            Manager.DoMessageFlushAfterAction = false;
            this.UIActions.UIMouseDown(this.HotPoint);
            Point hotPoint = element.HotPoint;
            if (isPixelMove)
            {
                element.UIActions.UIMoveHover(hotPoint);
            }
            else
            {
                element.UIActions.UIHover(hotPoint);
            }
            Manager.DoMessageFlushAfterAction = true;
            element.UIActions.UIMouseUp(hotPoint);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIDragTo(Point from, Point to, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIDragTo(from, to);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIDragToInBody(Point from, Point to)
        {
            DomElementGUI body = Manager.Current.ActiveBrowser.Body;
            Point location = this.Location;
            Point point = new Point((location.X + from.X) - body.Location.X, (location.Y + from.Y) - body.Location.Y);
            Point point3 = point;
            point3.Offset(to.X, to.Y);
            body.UIHover(point, true).UIClick(point, MouseButtonType.Left, true).UIHover(point, true).UIMouseDown(point, true).UIHover(point3, true).UIMouseUp(point3, true);
            return this;
        }

        public virtual WebElementGUI UIHover()
        {
            this.UIHover(this.HotPoint, false);
            return this;
        }

        public virtual WebElementGUI UIHover(Point point, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIHover(point);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIKeyHit(string key, int hitCount = 1)
        {
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            for (int i = 0; i < hitCount; i++)
            {
                this.UIActions.UIKeyPress(key);
            }
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIKeyHitWithAlt(string key)
        {
            this.UIModifierKeyDown(Keys.LeftAlt);
            this.UIKeyHit(key, 1);
            this.UIModifierKeyUp(Keys.LeftAlt);
            return this;
        }

        public virtual WebElementGUI UIKeyHitWithControl(string key)
        {
            this.UIModifierKeyDown(Keys.LeftControl);
            this.UIKeyHit(key, 1);
            this.UIModifierKeyUp(Keys.LeftControl);
            return this;
        }

        public virtual WebElementGUI UIKeyHitWithControlShift(string key)
        {
            this.UIModifierKeyDown(Keys.LeftControl);
            this.UIModifierKeyDown(Keys.LeftShift);
            this.UIKeyHit(key, 1);
            this.UIModifierKeyUp(Keys.LeftShift);
            this.UIModifierKeyUp(Keys.LeftControl);
            return this;
        }

        public virtual WebElementGUI UIKeyHitWithShift(string key)
        {
            this.UIModifierKeyDown(Keys.LeftShift);
            this.UIKeyHit(key, 1);
            this.UIModifierKeyUp(Keys.LeftShift);
            return this;
        }

        public virtual WebElementGUI UIModifierKeyDown(string key)
        {
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIModifierKeyDown(key);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIModifierKeyUp(string key)
        {
            bool visible = false;
            try
            {
                visible = this.Visible;
            }
            catch
            {
            }
            if (visible)
            {
                this.PrepareAction();
                this.UIActions.UIModifierKeyUp(key);
                this.EndAction();
            }
            else
            {
                Manager.Current.ActiveBrowser.Body.UIModifierKeyUp(key);
            }
            return this;
        }

        public virtual WebElementGUI UIMouseDown()
        {
            this.UIMouseDown(this.HotPoint, false);
            return this;
        }

        public virtual WebElementGUI UIMouseDown(Point point, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIMouseDown(point);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIMouseUp()
        {
            this.UIMouseUp(this.HotPoint, false);
            return this;
        }

        public virtual WebElementGUI UIMouseUp(Point point, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIMouseUp(point);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UIMoveHover()
        {
            this.UIMoveHover(this.HotPoint, false);
            return this;
        }

        public virtual WebElementGUI UIMoveHover(Point point, bool tryShowElement = true)
        {
            if (tryShowElement)
            {
                this.TryToScrollElementIntoView();
            }
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UIMoveHover(point);
            this.EndAction();
            return this;
        }

        public virtual WebElementGUI UISendKeys(string keysToSend)
        {
            if (!this.Visible)
            {
                throw new InvalidOperationException(string.Format("The {0} element not display or size is zero.", this.WebElement.get_TagName()));
            }
            this.PrepareAction();
            this.UIActions.UISendKeys(keysToSend);
            this.EndAction();
            return this;
        }

        public virtual Bitmap UISnap(bool byDesktop = false)
        {
            return this.UISnap(Rectangle.Empty, byDesktop);
        }

        public virtual Bitmap UISnap(Rectangle clipBounds, bool byDesktop = false)
        {
            Bitmap bitmap5;
            this.TryToScrollElementIntoView();
            if (!this.Visible)
            {
                throw new InvalidCastException("The element can't display, so can't snap image.");
            }
            Thread.Sleep(0x3e8);
            if (byDesktop && !Manager.Current.ActiveBrowser.IsRemote)
            {
                using (Bitmap bitmap = Camera.SnapshotDesktop().Bitmap)
                {
                    Rectangle a = new Rectangle(new Point(0, 0), bitmap.Size);
                    using (Bitmap bitmap2 = bitmap.Clone(Rectangle.Intersect(a, Manager.Current.ActiveBrowser.GetElementRectangleByScreem(this.WebElement)), PixelFormat.Undefined))
                    {
                        Rectangle bounds = this.Bounds;
                        if (clipBounds != Rectangle.Empty)
                        {
                            bounds = Rectangle.Intersect(bounds, clipBounds);
                        }
                        return bitmap2.Clone(Rectangle.Intersect(bounds, new Rectangle(Point.Empty, bitmap2.Size)), PixelFormat.Undefined);
                    }
                }
            }
            using (Bitmap bitmap3 = new Bitmap(new MemoryStream(((ITakesScreenshot) this.WebDriver).GetScreenshot().get_AsByteArray())))
            {
                Rectangle domElementBounds = this.GetDomElementBounds();
                int x = domElementBounds.X;
                int y = domElementBounds.Y;
                if (Manager.Current.ActiveBrowser.BrowserType != BrowserType.Firefox)
                {
                    x -= this.DocumentScrollLeft;
                    y -= this.DocumentScrollTop;
                }
                Rectangle rectangle4 = new Rectangle(new Point(x, y), domElementBounds.Size);
                using (Bitmap bitmap4 = bitmap3.Clone(Rectangle.Intersect(rectangle4, new Rectangle(Point.Empty, bitmap3.Size)), PixelFormat.Undefined))
                {
                    Rectangle rectangle5 = Rectangle.Intersect(new Rectangle(Point.Empty, rectangle4.Size), this.Bounds);
                    if (clipBounds != Rectangle.Empty)
                    {
                        rectangle5 = Rectangle.Intersect(rectangle5, clipBounds);
                    }
                    bitmap5 = bitmap4.Clone(Rectangle.Intersect(rectangle5, new Rectangle(Point.Empty, bitmap4.Size)), PixelFormat.Undefined);
                }
            }
            return bitmap5;
        }

        public DomElementGUI WaitFindDisplayedElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindDisplayedElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindDisplayedElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, text, condition, comparison) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.WaitFindDisplayElementGUI<T>(this.WebDriver, this.WebElement, new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, text, condition, comparison);
            return local;
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.WaitFindDisplayElementGUI<T>(this.WebDriver, this.WebElement, by, throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public DomElementGUI WaitFindElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, text, condition, comparison) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.WaitFindElementGUI<T>(this.WebDriver, this.WebElement, new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, text, condition, comparison);
            return local;
        }

        public DomElementGUI WaitFindElementGUI(By by, int timeout)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = TestUtility.WaitFindElementGUI<T>(this.WebDriver, this.WebElement, by, throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public IElementGUI WaitForElementDisappeared()
        {
            return this.WaitForElementDisappeared(PageGUI.PageFindElementTimeout);
        }

        public IElementGUI WaitForElementDisappeared(int timeout)
        {
            TestUtility.WaitFunc(() => this.IsDisappeared, timeout, true, "Wait element disappeared is timeout[{0}s]");
            return this;
        }

        public IElementGUI WaitForElementEnabled()
        {
            return this.WaitForElementEnabled(PageGUI.PageFindElementTimeout);
        }

        public IElementGUI WaitForElementEnabled(int timeout)
        {
            TestUtility.WaitFunc(() => this.Enabled, timeout, true, "Wait element enabled is timeout[{0}s]");
            return this;
        }

        public IElementGUI WaitForElementVisible()
        {
            return this.WaitForElementVisible(PageGUI.PageFindElementTimeout);
        }

        public IElementGUI WaitForElementVisible(int timeout)
        {
            TestUtility.WaitFunc(() => this.IsExistDisplayedElement, timeout, true, "Wait element display is timeout[{0}s]");
            return this;
        }

        public virtual Rectangle Bounds
        {
            get
            {
                Rectangle rectangle = this._bounds;
                if (rectangle.IsEmpty)
                {
                    rectangle = new Rectangle(Point.Empty, this.Size);
                }
                return rectangle;
            }
            protected set
            {
                this._bounds = value;
            }
        }

        public CodeSnippet DependedScript
        {
            get
            {
                return this.GetDependedScript();
            }
            protected set
            {
                this._dependedScript = value;
            }
        }

        private int DocumentScrollLeft
        {
            get
            {
                return Convert.ToInt32((this.WebDriver as IJavaScriptExecutor).ExecuteScript("return Math.max(document.documentElement.scrollLeft, document.body.scrollLeft);", new object[0]));
            }
        }

        private int DocumentScrollTop
        {
            get
            {
                return Convert.ToInt32((this.WebDriver as IJavaScriptExecutor).ExecuteScript("return Math.max(document.documentElement.scrollTop, document.body.scrollTop);", new object[0]));
            }
        }

        protected ExecutableObject DomExecutable
        {
            get
            {
                return new ExecutableObject(this.GetWebElementRefScript());
            }
        }

        protected JQueryObject DomJQueryExecutable
        {
            get
            {
                return new JQueryObject(this.GetWebElementRefScript());
            }
        }

        public bool DoPrepareAction
        {
            get
            {
                return this._doPrepareAction;
            }
            set
            {
                this._doPrepareAction = value;
            }
        }

        public virtual string ElementText
        {
            get
            {
                return this.WebElement.get_Text();
            }
        }

        public virtual bool Enabled
        {
            get
            {
                return this.WebElement.get_Enabled();
            }
        }

        public virtual ExecutableObject ExecutableAdapter
        {
            get
            {
                return new ExecutableObject(this.DependedScript);
            }
        }

        protected Selenium.Test.Toolkit.Core.FinderBuffer FinderBuffer
        {
            get
            {
                if (this._finderBuffer == null)
                {
                    this._finderBuffer = new Selenium.Test.Toolkit.Core.FinderBuffer();
                    this._finderBuffer.Enable = this.UseFinderBuffer;
                }
                return this._finderBuffer;
            }
        }

        public Dictionary<string, By> Finders
        {
            get
            {
                if (this._customFinders == null)
                {
                    this._customFinders = new Dictionary<string, By>();
                }
                return this._customFinders;
            }
            set
            {
                this._customFinders = value;
            }
        }

        public virtual Point HotPoint
        {
            get
            {
                this.TryToScrollElementIntoView();
                Rectangle bounds = this.Bounds;
                return new Point(bounds.Left + (bounds.Width / 2), bounds.Top + (bounds.Height / 2));
            }
        }

        protected virtual bool IsDisappeared
        {
            get
            {
                try
                {
                    return !this.Visible;
                }
                catch (ElementNotVisibleException)
                {
                    return true;
                }
                catch (StaleElementReferenceException)
                {
                    return true;
                }
            }
        }

        public bool IsExistDisplayedElement
        {
            get
            {
                return this.Visible;
            }
        }

        public bool IsExistElement
        {
            get
            {
                return true;
            }
        }

        public bool IsNull
        {
            get
            {
                return false;
            }
        }

        public virtual JQueryObject JQueryExecutableAdapter
        {
            get
            {
                return new JQueryObject(this.GetWebElementRefScript());
            }
        }

        internal virtual Point Location
        {
            get
            {
                try
                {
                    return this.WebElement.get_Location();
                }
                catch
                {
                    return this.JQueryExecutableAdapter.offset();
                }
            }
        }

        protected virtual Point OffSet
        {
            get
            {
                return this.JQueryExecutableAdapter.offset();
            }
        }

        public virtual IElementGUI Parent
        {
            get
            {
                return this._parent;
            }
            set
            {
                this._parent = value;
            }
        }

        public IElementGUI Self
        {
            get
            {
                return this;
            }
        }

        internal virtual System.Drawing.Size Size
        {
            get
            {
                try
                {
                    return this.WebElement.get_Size();
                }
                catch
                {
                    return new System.Drawing.Size(this.ExecutableAdapter.GetJSProperty<int>("offsetWidth"), this.ExecutableAdapter.GetJSProperty<int>("offsetHeight"));
                }
            }
        }

        protected virtual int StyleHeight
        {
            get
            {
                return this.JQueryExecutableAdapter.height();
            }
        }

        protected virtual int StyleWidth
        {
            get
            {
                return this.JQueryExecutableAdapter.width();
            }
        }

        protected IUIActions UIActions
        {
            get
            {
                if (this._uiActions == null)
                {
                    this._uiActions = Manager.Current.ActionFactory.GetUIActions(this.WebElement, Manager.Current.TestSettings.ActionType);
                }
                return this._uiActions;
            }
        }

        public bool UseFinderBuffer
        {
            get
            {
                return this._useFinderBuffer;
            }
            set
            {
                this._useFinderBuffer = value;
                this.FinderBuffer.Enable = this._useFinderBuffer;
            }
        }

        public virtual bool UseResourceTextFinder { get; set; }

        public virtual bool Visible
        {
            get
            {
                if (!this.WebElement.get_Displayed())
                {
                    return false;
                }
                Rectangle bounds = this.Bounds;
                return ((bounds.Width > 0) && (bounds.Height > 0));
            }
        }

        protected IWebDriver WebDriver
        {
            get
            {
                return Manager.Current.ActiveBrowser.WebDriver;
            }
        }

        public virtual IWebElement WebElement
        {
            get
            {
                return this._webElement;
            }
            internal set
            {
                this._webElement = value;
            }
        }
    }
}

