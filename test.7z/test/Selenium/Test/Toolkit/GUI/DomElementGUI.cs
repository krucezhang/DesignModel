﻿namespace Selenium.Test.Toolkit.GUI
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Remote;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.BOMObject;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Drawing;
    using System.Linq;

    public class DomElementGUI : WebElementGUI
    {
        public DomElementGUI(By by) : this(Manager.Current.ActiveBrowser.WebDriver.FindElement(by))
        {
        }

        public DomElementGUI(IWebElement element) : base(element, Rectangle.Empty, null)
        {
        }

        public DomElementGUI(IWebElement element, Rectangle bounds) : base(element, bounds, null)
        {
        }

        public override T AsTo<T>()
        {
            return TestUtility.CreateInstance<T>(null, this.WebElement, this.Parent, new object[0]);
        }

        public void Focus()
        {
            this.ExecutableAdapter.InvokeJSMehtod("focus", new object[0]);
        }

        public string GetAttribute(string atrName)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<string>("getAttribute", new object[] { atrName });
        }

        private DomElementGUI GetChildElement(DomElementGUI elementGUI, int pageX, int pageY)
        {
            ArrayObject<DomElementGUI> children = elementGUI.Children;
            int length = children.length;
            DomElementGUI tgui = null;
            Rectangle bounds = elementGUI.Bounds;
            bounds = new Rectangle(elementGUI.Location, bounds.Size);
            if (!bounds.Contains(pageX, pageY))
            {
                return null;
            }
            for (int i = 0; i < length; i++)
            {
                tgui = this.GetChildElement(children[0], pageX, pageY);
                if (tgui != null)
                {
                    return tgui;
                }
            }
            return elementGUI;
        }

        public Style getComputedStyle(string pseudoElement)
        {
            return Style.GetComputedStyle(this, pseudoElement);
        }

        public string GetCssValue(string cssName)
        {
            return this.WebElement.GetCssValue(cssName);
        }

        public T GetCssValue<T>(string cssName)
        {
            return this.ComputedStyle.getPropertyValue<T>(cssName);
        }

        internal DomElementGUI GetEffectChildElementGUI(int x, int y)
        {
            Point location = this.Location;
            location.Offset(x, y);
            DomElementGUI tgui = this.GetChildElement(this, location.X, location.Y);
            if (tgui != null)
            {
                return tgui;
            }
            return this;
        }

        public bool HasAttribute(string atrName)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("hasAttribute", new object[] { atrName });
        }

        public bool HasClass(string className)
        {
            return this.ClassName.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList<string>().Contains(className);
        }

        private string HtmlTextEncode(string value)
        {
            if (value == null)
            {
                return value;
            }
            return value.Replace('\x00a0', ' ');
        }

        public DomElementGUI SetAttribute(string atrName, string value)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setAttribute", new object[] { atrName, value });
            return this;
        }

        public virtual ArrayObject<DomElementGUI> Children
        {
            get
            {
                return new ArrayObject<DomElementGUI>(this.ExecutableAdapter.GetJSPropertyJSSnippet("children", "childArray"));
            }
        }

        public string ClassName
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("className");
            }
        }

        public int clientHeight
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("clientHeight");
            }
        }

        public int clientWidth
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("clientWidth");
            }
        }

        public Style ComputedStyle
        {
            get
            {
                return Style.GetComputedStyle(this, null);
            }
        }

        public override string ElementText
        {
            get
            {
                string textContent = this.TextContent;
                if (!string.IsNullOrEmpty(textContent))
                {
                    return textContent.Trim();
                }
                string tagName = this.TagName;
                if (tagName.Equals("input", StringComparison.OrdinalIgnoreCase))
                {
                    return new HtmlInputGUI(this.WebElement).ElementText;
                }
                if (tagName.Equals("textarea", StringComparison.OrdinalIgnoreCase))
                {
                    return new HtmlTextareaGUI(this.WebElement).ElementText;
                }
                return string.Empty;
            }
        }

        public override bool Enabled
        {
            get
            {
                if (!base.Enabled)
                {
                    return false;
                }
                string attribute = this.GetAttribute("disabled");
                return (!"true".Equals(attribute, StringComparison.OrdinalIgnoreCase) && !"disabled".Equals(attribute, StringComparison.OrdinalIgnoreCase));
            }
        }

        public string ID
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("id");
            }
        }

        public string InnerHTML
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("innerHTML");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("innerHTML", value);
            }
        }

        private string InnerText
        {
            get
            {
                if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Firefox)
                {
                    return this.TextContent;
                }
                return this.ExecutableAdapter.GetJSProperty<string>("innerText");
            }
        }

        public DomElementGUI NextSiblingNode
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<DomElementGUI>("nextSibling");
            }
        }

        public DomElementGUI ParentNode
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<DomElementGUI>("parentNode");
            }
        }

        public DomElementGUI PreviousSiblingNode
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<DomElementGUI>("previousSibling");
            }
        }

        public Style style
        {
            get
            {
                return Style.GetDomStyle(this);
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("style", value);
            }
        }

        public int TabIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("tabIndex");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("tabIndex", value);
            }
        }

        public string TagName
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("tagName");
            }
        }

        public string TextContent
        {
            get
            {
                if ((Manager.Current.ActiveBrowser.BrowserType == BrowserType.IE) && (Convert.ToInt32(((RemoteWebDriver) base.WebDriver).get_Capabilities().get_Version()) < 9))
                {
                    return this.HtmlTextEncode(this.InnerText);
                }
                return this.HtmlTextEncode(this.ExecutableAdapter.GetJSProperty<string>("textContent"));
            }
        }
    }
}

