﻿namespace Selenium.Test.Toolkit.GUI
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Collections.Generic;
    using System.Drawing;

    public interface IElementGUI : IFindElementGUI, IProxyElement, IDisposable
    {
        WebElementGUI UIClick();
        WebElementGUI UIDoubleClick();
        WebElementGUI UISendKeys(string keysToSend);

        Rectangle Bounds { get; }

        string ElementText { get; }

        bool Enabled { get; }

        Dictionary<string, By> Finders { get; set; }

        Point HotPoint { get; }

        IElementGUI Parent { get; set; }

        bool Visible { get; }

        IWebElement WebElement { get; }
    }
}

