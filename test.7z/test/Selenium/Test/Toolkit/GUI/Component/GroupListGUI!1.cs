﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class GroupListGUI<T> : GroupGUI<GroupContainerGUI<T>, T> where T: WebElementGUI
    {
        public GroupListGUI(IWebElement element) : base(element)
        {
        }
    }
}

