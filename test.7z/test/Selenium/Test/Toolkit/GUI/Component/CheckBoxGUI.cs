﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Action;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Drawing;
    using System.Linq;
    using System.Runtime.CompilerServices;

    public class CheckBoxGUI : DomElementGUI
    {
        private bool _checkInputDome;
        private HtmlInputGUI _innerInputGUI;

        public CheckBoxGUI(IWebElement element) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            IWebElement webElement = element;
            if (webElement.get_TagName().Equals("input", StringComparison.OrdinalIgnoreCase))
            {
                this._innerInputGUI = new HtmlInputGUI(element);
                this._checkInputDome = true;
                webElement = this._innerInputGUI.ParentNode.WebElement;
            }
            base.AssignElement(webElement);
        }

        public CheckBoxGUI UICheck()
        {
            return this.UICheck(true);
        }

        public CheckBoxGUI UICheck(bool value)
        {
            if (this.Checked != value)
            {
                this.TryToScrollElementIntoView();
                HtmlInputGUI innerCheckBoxGUI = this.InnerCheckBoxGUI;
                if ((innerCheckBoxGUI != null) && innerCheckBoxGUI.Visible)
                {
                    Size size = innerCheckBoxGUI.Size;
                    if ((size.Width >= 5) && (size.Height >= 5))
                    {
                        innerCheckBoxGUI.UIClick();
                        return this;
                    }
                }
                DomElementGUI tgui2 = base.FindDisplayedElementGUI<DomElementGUI>(this.LabelFinder, false);
                if (tgui2 == null)
                {
                    tgui2 = this;
                    if ((innerCheckBoxGUI != null) && !tgui2.Visible)
                    {
                        DomElementGUI parentNode = innerCheckBoxGUI;
                        for (int i = 0; i < 5; i++)
                        {
                            parentNode = parentNode.ParentNode;
                            if (parentNode == null)
                            {
                                break;
                            }
                            if (parentNode.Visible)
                            {
                                tgui2 = parentNode;
                                break;
                            }
                        }
                    }
                }
                tgui2.UIClick();
                try
                {
                    if (this.Checked != value)
                    {
                        Rectangle bounds = tgui2.Bounds;
                        tgui2.UIClick(new Point(bounds.X + 8, bounds.Y + (bounds.Height / 2)), MouseButtonType.Left, false);
                    }
                }
                catch
                {
                }
            }
            return this;
        }

        public CheckBoxGUI UIUnCheck()
        {
            return this.UICheck(false);
        }

        protected virtual By BoxFinder
        {
            get
            {
                return this.TryGetByFinder("CheckBoxGUI.Box", null);
            }
        }

        public bool Checked
        {
            get
            {
                Func<DomElementGUI, bool> predicate = null;
                Func<DomElementGUI, bool> func2 = null;
                if (this.CheckedFunc != null)
                {
                    return this.CheckedFunc(this);
                }
                HtmlInputGUI innerCheckBoxGUI = this.InnerCheckBoxGUI;
                if (innerCheckBoxGUI != null)
                {
                    return innerCheckBoxGUI.Checked;
                }
                DomElementGUI tgui2 = null;
                By checkedStatusFinder = this.CheckedStatusFinder;
                if (checkedStatusFinder != null)
                {
                    tgui2 = base.FindElementGUI<DomElementGUI>(checkedStatusFinder, false);
                    if (tgui2 == null)
                    {
                        if (predicate == null)
                        {
                            predicate = ele => ele.ReferenceElementEquals(this);
                        }
                        tgui2 = base.ParentNode.FindElementGUIs(checkedStatusFinder).SingleOrDefault<DomElementGUI>(predicate);
                    }
                    if (tgui2 != null)
                    {
                        return true;
                    }
                }
                checkedStatusFinder = this.UnCheckedStatusFinder;
                if (checkedStatusFinder != null)
                {
                    tgui2 = base.FindElementGUI<DomElementGUI>(checkedStatusFinder, false);
                    if (tgui2 == null)
                    {
                        if (func2 == null)
                        {
                            func2 = ele => ele.ReferenceElementEquals(this);
                        }
                        tgui2 = base.ParentNode.FindElementGUIs(checkedStatusFinder).SingleOrDefault<DomElementGUI>(func2);
                    }
                    if (tgui2 == null)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public Func<CheckBoxGUI, bool> CheckedFunc { get; set; }

        protected virtual By CheckedStatusFinder
        {
            get
            {
                return this.TryGetByFinder("CheckBoxGUI.CheckedStatus", By.CssSelector(".checked"));
            }
        }

        public override string ElementText
        {
            get
            {
                DomElementGUI tgui = base.FindElementGUI<DomElementGUI>(this.LabelFinder, false);
                if (tgui != null)
                {
                    string elementText = tgui.ElementText;
                    if (!string.IsNullOrWhiteSpace(elementText))
                    {
                        return elementText;
                    }
                }
                return base.ElementText;
            }
        }

        protected HtmlInputGUI InnerCheckBoxGUI
        {
            get
            {
                if (!this._checkInputDome)
                {
                    this._innerInputGUI = base.FindElementGUI<HtmlInputGUI>(By.TagName("input"), false);
                    this._checkInputDome = true;
                }
                return this._innerInputGUI;
            }
        }

        protected virtual By LabelFinder
        {
            get
            {
                return this.TryGetByFinder("CheckBoxGUI.ElementText", By.CssSelector("label"));
            }
        }

        protected virtual By UnCheckedStatusFinder
        {
            get
            {
                return this.TryGetByFinder("CheckBoxGUI.UnCheckedStatus", null);
            }
        }
    }
}

