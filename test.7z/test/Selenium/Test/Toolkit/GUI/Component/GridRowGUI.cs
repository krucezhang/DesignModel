﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public class GridRowGUI : DomElementGUI, IGridRowGUI
    {
        private bool _checkTableRowDome;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI _tableRowGUI;

        public GridRowGUI(IWebElement element) : base(element)
        {
        }

        public int CellCount
        {
            get
            {
                if (this.HtmlTableRowGUI != null)
                {
                    return this.HtmlTableRowGUI.Cells.length;
                }
                return this.CellsGUI.Count;
            }
        }

        protected virtual By CellFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.Cell", By.CssSelector("td, th, .column"));
            }
        }

        public virtual IList<DomElementGUI> CellsGUI
        {
            get
            {
                Func<HtmlTableCellGUI, HtmlTableCellGUI> selector = null;
                if (this.HtmlTableRowGUI == null)
                {
                    return base.FindElementGUIs(this.CellFinder).Select<DomElementGUI, DomElementGUI>(delegate (DomElementGUI item) {
                        item.Parent = this;
                        return item;
                    }).ToList<DomElementGUI>();
                }
                if (selector == null)
                {
                    selector = delegate (HtmlTableCellGUI item) {
                        item.Parent = this;
                        return item;
                    };
                }
                return ((IEnumerable<DomElementGUI>) this.HtmlTableRowGUI.CellGUIs.Select<HtmlTableCellGUI, HtmlTableCellGUI>(selector)).ToList<DomElementGUI>();
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI HtmlTableRowGUI
        {
            get
            {
                if (!this._checkTableRowDome)
                {
                    if (base.TagName.Trim().Equals("tr", StringComparison.OrdinalIgnoreCase))
                    {
                        this._tableRowGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI>();
                    }
                    if (this._tableRowGUI == null)
                    {
                        this._tableRowGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI>(By.TagName("tr"), false);
                    }
                    this._checkTableRowDome = true;
                }
                return this._tableRowGUI;
            }
        }

        public int Index { get; private set; }

        public virtual DomElementGUI this[int cellIndex]
        {
            get
            {
                if (this.HtmlTableRowGUI != null)
                {
                    return this.HtmlTableRowGUI.Cells[cellIndex];
                }
                return this.CellsGUI[cellIndex];
            }
        }

        public virtual DomElementGUI this[string headName]
        {
            get
            {
                IGridGUI parent = this.Parent as IGridGUI;
                if (parent != null)
                {
                    int columnIndex = parent.GetColumnIndex(headName);
                    if ((parent.MatrixColumnCount == this.CellCount) || (this.HtmlTableRowGUI == null))
                    {
                        return this[columnIndex];
                    }
                    int num2 = 0;
                    foreach (HtmlTableCellGUI lgui in this.CellsGUI)
                    {
                        int colSpan = lgui.ColSpan;
                        if ((columnIndex >= num2) && (columnIndex < (num2 + colSpan)))
                        {
                            return lgui;
                        }
                        num2 += colSpan;
                    }
                }
                throw new InvalidOperationException("The GridRow have not owner Grid.");
            }
        }
    }
}

