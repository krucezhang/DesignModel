﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class ListCheckBoxGUI : ListGUI<CheckBoxGUI>
    {
        public ListCheckBoxGUI(IWebElement element) : base(element)
        {
        }

        protected bool InnerUICheckAll(bool value)
        {
            CheckBoxGUI checkAll = this.CheckAll;
            if (checkAll != null)
            {
                checkAll.UICheck(!value);
                this.CheckAll.UICheck(value);
                return true;
            }
            return false;
        }

        public ListCheckBoxGUI UIAdditionalCheck(params string[] text)
        {
            this.GetItem(delegate (CheckBoxGUI element) {
                element.UICheck();
            }, null, false, false, true, text);
            return this;
        }

        public ListCheckBoxGUI UIAdditionalUnCheck(params string[] text)
        {
            this.GetItem(delegate (CheckBoxGUI element) {
                element.UIUnCheck();
            }, null, false, false, true, text);
            return this;
        }

        public ListCheckBoxGUI UICheck(params string[] text)
        {
            bool isCheckAll = this.InnerUICheckAll(false);
            this.GetItem(delegate (CheckBoxGUI element) {
                element.UICheck();
            }, delegate (CheckBoxGUI element) {
                if (!isCheckAll)
                {
                    element.UIUnCheck();
                }
            }, false, true, true, text);
            return this;
        }

        public ListCheckBoxGUI UICheckAll(bool value)
        {
            if (!this.InnerUICheckAll(value))
            {
                throw new InvalidOperationException("Can't find CheckAll item in ListCheckBoxGUI.");
            }
            return this;
        }

        public ListCheckBoxGUI UIUnCheck(params string[] text)
        {
            bool isCheckAll = this.InnerUICheckAll(true);
            this.GetItem(delegate (CheckBoxGUI element) {
                element.UIUnCheck();
            }, delegate (CheckBoxGUI element) {
                if (!isCheckAll)
                {
                    element.UICheck();
                }
            }, false, true, true, text);
            return this;
        }

        public virtual CheckBoxGUI CheckAll
        {
            get
            {
                By checkAllFinder = this.CheckAllFinder;
                if (checkAllFinder == null)
                {
                    return null;
                }
                CheckBoxGUI item = base.FindDisplayedElementGUI<CheckBoxGUI>(checkAllFinder, false);
                if (item != null)
                {
                    this.InitizationItem(item);
                }
                return item;
            }
        }

        protected virtual By CheckAllFinder
        {
            get
            {
                return this.TryGetByFinder("ListCheckBoxGUI.CheckAll", null);
            }
        }

        protected override By ItemFinder
        {
            get
            {
                return this.TryGetByFinder("ListCheckBoxGUI.Item", base.ItemFinder);
            }
        }
    }
}

