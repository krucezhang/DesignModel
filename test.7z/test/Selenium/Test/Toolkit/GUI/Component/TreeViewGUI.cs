﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class TreeViewGUI : TreeViewNodeGUI
    {
        public TreeViewGUI(IWebElement element) : base(element)
        {
        }
    }
}

