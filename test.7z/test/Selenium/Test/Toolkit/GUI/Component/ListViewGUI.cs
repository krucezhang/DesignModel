﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class ListViewGUI : ListGUI<DomElementGUI>
    {
        public ListViewGUI(IWebElement element) : base(element)
        {
        }
    }
}

