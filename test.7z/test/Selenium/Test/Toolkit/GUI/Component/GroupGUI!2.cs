﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public class GroupGUI<G, T> : DomElementGUI where G: GroupContainerGUI<T> where T: WebElementGUI
    {
        public GroupGUI(IWebElement element) : base(element)
        {
            this.FinderTextCondition = TextFindCondition.Equals;
            this.FinderTextComparison = TextComparison.IgnoreCase;
            this.UseResourceTextFinder = true;
        }

        public G GetGroupGUI(string groupHeader)
        {
            foreach (G local in this.GroupsGUI)
            {
                local.UseResourceTextFinder = this.UseResourceTextFinder;
                if (ByContentText.CompareText(groupHeader, local.HeaderText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                {
                    return local;
                }
            }
            throw new InvalidProgramException(string.Format("Can't find document Group[groupHeaderText:{0}].", groupHeader));
        }

        public TextComparison FinderTextComparison { get; set; }

        public TextFindCondition FinderTextCondition { get; set; }

        public IList<G> GroupsGUI
        {
            get
            {
                return base.FindElementGUIs<G>(By.CssSelector(".df-group-container, .df-group-view-container"));
            }
        }

        public override Point HotPoint
        {
            get
            {
                this.TryToScrollElementIntoView();
                Rectangle bounds = this.Bounds;
                return new Point(bounds.Left + (bounds.Width / 2), bounds.Bottom - 30);
            }
        }

        public T this[string itemText]
        {
            get
            {
                foreach (T local in this.ItemsGUI)
                {
                    if (ByContentText.CompareText(itemText, local.ElementText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                    {
                        return local;
                    }
                }
                throw new InvalidProgramException(string.Format("Can't find group item[Text:{0}] in GroupList.", itemText));
            }
        }

        public T this[string groupHeader, string itemText]
        {
            get
            {
                return this.GetGroupGUI(groupHeader)[new string[] { itemText }];
            }
        }

        public T this[string groupHeader, int itemIndex]
        {
            get
            {
                return this.GetGroupGUI(groupHeader).ItemsGUI[itemIndex];
            }
        }

        public T this[int groupIndex, int itemIndex]
        {
            get
            {
                G local = this.GroupsGUI[groupIndex];
                return local.ItemsGUI[itemIndex];
            }
        }

        public IList<T> ItemsGUI
        {
            get
            {
                foreach (G local in this.GroupsGUI)
                {
                    local.UIExpand();
                }
                return base.FindElementGUIs<T>(By.CssSelector(".df-group-item-container, .df-group-view-item-container"));
            }
        }
    }
}

