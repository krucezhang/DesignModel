﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Reflection;

    public interface IGridGUI
    {
        int GetColumnIndex(string columnName);
        DomElementGUI GetMatrixElementGUI(int rowIndex, int cellIndex);

        DomElementGUI this[int rowIndex, int cellIndex] { get; }

        int MatrixColumnCount { get; }

        int RowCount { get; }
    }
}

