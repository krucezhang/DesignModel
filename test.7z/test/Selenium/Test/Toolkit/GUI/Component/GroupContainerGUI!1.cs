﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;

    public class GroupContainerGUI<T> : ListGUI<T> where T: WebElementGUI
    {
        internal GroupContainerGUI(IWebElement element) : base(element)
        {
        }

        public GroupContainerGUI<T> UIExpand()
        {
            if (this.IsCollapsed)
            {
                this.DropDownButtonGUI.UIClick();
            }
            return (GroupContainerGUI<T>) this;
        }

        public DomElementGUI DropDownButtonGUI
        {
            get
            {
                return base.FindElementGUI(By.CssSelector(".df-group-state, .df-group-view-state"));
            }
        }

        public HtmlInputGUI GroupEditorGUI
        {
            get
            {
                return base.FindDisplayedElementGUI<HtmlInputGUI>(By.CssSelector(".df-group-editor, .df-group-view-editor"));
            }
        }

        public DomElementGUI GroupHeaderGUI
        {
            get
            {
                return base.FindElementGUI(By.CssSelector(".df-group-header, .df-group-view-header"));
            }
        }

        public string HeaderText
        {
            get
            {
                return base.FindElementGUI(By.CssSelector(".df-group-header-text, .df-group-view-header-text")).ElementText;
            }
        }

        public bool IsActive
        {
            get
            {
                return base.HasClass("active");
            }
        }

        public bool IsCollapsed
        {
            get
            {
                return base.HasClass("group-collapsed");
            }
        }

        public override IList<T> ItemsGUI
        {
            get
            {
                this.UIExpand();
                return base.FindElementGUIs<T>(By.CssSelector(".df-group-item-container, .df-group-view-item-container"));
            }
        }
    }
}

