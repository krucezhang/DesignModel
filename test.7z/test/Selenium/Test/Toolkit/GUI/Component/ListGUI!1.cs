﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class ListGUI<T> : DomElementGUI where T: WebElementGUI
    {
        public ListGUI(IWebElement element) : base(element)
        {
            this.FinderTextCondition = TextFindCondition.Equals;
            this.FinderTextComparison = TextComparison.IgnoreCase;
            this.UseResourceTextFinder = true;
        }

        public virtual bool ContainsItem(params string[] text)
        {
            T local;
            return this.TryGetItem(out local, text);
        }

        protected virtual T GetItem(Action<T> matchedAction, Action<T> unMatchedAction, bool isSequence, bool searchAll, bool throwException, params string[] text)
        {
            int index = 0;
            string itemPath = text[index];
            IList<T> itemsGUI = this.ItemsGUI;
            int count = itemsGUI.Count;
            int num3 = 0;
            for (int i = 0; i < count; i++)
            {
                T item = itemsGUI[i];
                this.InitizationItem(item);
                string actualText = string.Empty;
                try
                {
                    actualText = item.ElementText;
                }
                catch (StaleElementReferenceException)
                {
                    itemsGUI = this.ItemsGUI;
                    count = itemsGUI.Count;
                    item = itemsGUI[i];
                    this.InitizationItem(item);
                    actualText = item.ElementText;
                }
                if (isSequence)
                {
                    if (ByContentText.CompareText(text[index], actualText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                    {
                        if (matchedAction != null)
                        {
                            matchedAction(item);
                        }
                        if (index >= (text.Length - 1))
                        {
                            return item;
                        }
                        num3++;
                        index++;
                        itemPath = itemPath + "->" + text[index];
                    }
                    else if (unMatchedAction != null)
                    {
                        unMatchedAction(item);
                    }
                }
                else
                {
                    bool flag = false;
                    for (int j = 0; j < text.Length; j++)
                    {
                        if (ByContentText.CompareText(text[j], actualText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                        {
                            flag = true;
                            num3++;
                            if (matchedAction != null)
                            {
                                matchedAction(item);
                            }
                            if ((num3 >= text.Length) && !searchAll)
                            {
                                return item;
                            }
                            break;
                        }
                    }
                    if (!flag && (unMatchedAction != null))
                    {
                        unMatchedAction(item);
                    }
                }
                if ((i == (count - 1)) && (index < text.Length))
                {
                    item.UIHover();
                    itemsGUI = this.ItemsGUI;
                    count = itemsGUI.Count;
                }
            }
            if (throwException)
            {
                if (isSequence)
                {
                    this.ThrowNotFindItemException(itemPath);
                }
                else if (num3 < text.Length)
                {
                    throw new InvalidOperationException(string.Format("Can't find All Items in ListGUI.", new object[0]));
                }
            }
            return default(T);
        }

        protected virtual void InitizationItem(T item)
        {
            item.Parent = this;
        }

        protected virtual void ThrowNotFindItemException(string itemPath)
        {
            throw new NoSuchElementException(string.Format("Can't find item[{0}] in ListGUI.", itemPath));
        }

        public virtual bool TryGetItem(out T item, params string[] text)
        {
            item = this.GetItem(null, null, true, false, false, text);
            return (((T) item) != null);
        }

        public virtual ListGUI<T> UIMultiSelect(params string[] text)
        {
            this.GetItem(delegate (T element) {
                element.UIClick();
            }, null, false, true, true, text);
            return (ListGUI<T>) this;
        }

        public virtual ListGUI<T> UIPerform(Action<T> matchedAction, params string[] text)
        {
            this.GetItem(matchedAction, null, false, false, true, text);
            return (ListGUI<T>) this;
        }

        public virtual ListGUI<T> UISelect(params string[] text)
        {
            this[text].UIClick();
            return (ListGUI<T>) this;
        }

        public TextComparison FinderTextComparison { get; set; }

        public TextFindCondition FinderTextCondition { get; set; }

        public T this[string[] text]
        {
            get
            {
                return this.GetItem(null, null, true, false, true, text);
            }
        }

        protected virtual By ItemFinder
        {
            get
            {
                return this.TryGetByFinder("ListGUI.Item", By.CssSelector("li, .list-item, .table-row"));
            }
        }

        public virtual IList<T> ItemsGUI
        {
            get
            {
                return base.FindElementGUIs<T>(this.ItemFinder);
            }
        }
    }
}

