﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;

    public class GridExGUI<T> : DomElementGUI, IGridGUI where T: WebElementGUI, IGridRowGUI
    {
        private bool _checkTableDome;
        private bool _checkTableHeadDome;
        private Dictionary<string, int> _columnKeyMap;
        private int? _matrixColumnCount;
        private int? _matrixRowCount;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI _tableGUI;
        private HtmlTableSectionGUI _tableHeadGUI;
        private const int MaxMatrixColumnCount = 30;

        public GridExGUI(IWebElement element) : base(element)
        {
            this._matrixColumnCount = null;
            this._matrixRowCount = null;
            this.FinderTextCondition = TextFindCondition.Equals;
            this.FinderTextComparison = TextComparison.IgnoreCase;
            this.UseResourceTextFinder = true;
            this.IsDetectFillRows = false;
        }

        protected void AddRowKeyValue(ref List<KeyValuePair<int, List<string>>> keyValues, params string[] rowKeyValues)
        {
            foreach (string str in rowKeyValues)
            {
                int index = str.IndexOf(':');
                if (index < 0)
                {
                    throw new InvalidCastException("Error Row KeyValue format, must containts ':' split char.");
                }
                keyValues.Add(new KeyValuePair<int, List<string>>(this.GetColumnIndex(str.Substring(0, index)), new List<string>(ByContentText.GetFinderText(str.Substring(index + 1), this.UseResourceTextFinder))));
            }
        }

        protected void AddRowKeyValue(ref List<KeyValuePair<int, List<string>>> keyValues, int rowIndex, string value)
        {
            keyValues.Add(new KeyValuePair<int, List<string>>(rowIndex, new List<string>(ByContentText.GetFinderText(value, this.UseResourceTextFinder))));
        }

        public override void Dispose()
        {
            base.Dispose();
            if (this._columnKeyMap != null)
            {
                this._columnKeyMap.Clear();
                this._columnKeyMap = null;
            }
        }

        public int GetColumnIndex(string columnName)
        {
            foreach (string str in ByContentText.GetFinderText(columnName, this.UseResourceTextFinder))
            {
                int num;
                if (this.ColumnKeyMap.TryGetValue(str, out num))
                {
                    return num;
                }
            }
            throw new InvalidProgramException("Can't get column index by specify column name.");
        }

        public virtual DomElementGUI GetMatrixElementGUI(int rowIndex, int cellIndex)
        {
            return this.getMatrixTableCell(this.HtmlTableBodyGUI, rowIndex, cellIndex);
        }

        private DomElementGUI getMatrixTableCell(DomElementGUI element, int rowIndex, int cellIndex)
        {
            return Manager.Current.ActiveBrowser.BuildInTestObj.InvokeJSMehtod<DomElementGUI>("getMatrixTableCell", new object[] { element, rowIndex, cellIndex });
        }

        private Dictionary<string, int> getMatrixTableColumnMap(DomElementGUI element)
        {
            return Manager.Current.ActiveBrowser.BuildInTestObj.InvokeJSMehtod<Dictionary<string, int>>("getMatrixTableColumnMap", new object[] { element });
        }

        public List<DomElementGUI> getMatrixTableRows(DomElementGUI element)
        {
            return (from item in Manager.Current.ActiveBrowser.BuildInTestObj.InvokeJSMehtod<List<IWebElement>>("getMatrixTableRows", new object[] { element }) select new DomElementGUI(item)).ToList<DomElementGUI>();
        }

        protected virtual int InitializeColumnMap(Dictionary<string, int> map)
        {
            if (this.HtmlTableHeadGUI != null)
            {
                this._columnKeyMap = this.getMatrixTableColumnMap(this.HtmlTableHeadGUI);
                if (this._columnKeyMap != null)
                {
                    return this._columnKeyMap.Count;
                }
            }
            By headRowFinder = this.HeadRowFinder;
            if ((this.HtmlTableBodyGUI != null) && (headRowFinder == null))
            {
                this._columnKeyMap = this.getMatrixTableColumnMap(this.HtmlTableBodyGUI);
                if (this._columnKeyMap != null)
                {
                    return this._columnKeyMap.Count;
                }
            }
            T local = this.HeadRowsGUI[0];
            IList<DomElementGUI> cellsGUI = local.CellsGUI;
            int num = 0;
            bool flag = false;
            foreach (DomElementGUI tgui in cellsGUI)
            {
                if (num == 0)
                {
                    flag = tgui is HtmlTableCellGUI;
                }
                string elementText = tgui.ElementText;
                if (!map.ContainsKey(elementText))
                {
                    map.Add(tgui.ElementText, num);
                }
                num += flag ? (tgui as HtmlTableCellGUI).ColSpan : 1;
            }
            return num;
        }

        private T queryMatrixTableMapRow(DomElementGUI element, int matrixRowIndex, List<KeyValuePair<int, List<string>>> keyValues, bool hasColKeyMap = false)
        {
            return Manager.Current.ActiveBrowser.BuildInTestObj.InvokeJSMehtod<T>("queryMatrixTableMapRow", new object[] { element, matrixRowIndex, keyValues, hasColKeyMap, this.FinderTextCondition });
        }

        protected virtual T SearchRowItem(int matrixRowIndex, params string[] rowKeyValues)
        {
            List<KeyValuePair<int, List<string>>> keyValues = new List<KeyValuePair<int, List<string>>>();
            this.AddRowKeyValue(ref keyValues, rowKeyValues);
            return this.SearchRowItem(matrixRowIndex, keyValues);
        }

        protected virtual T SearchRowItem(int matrixRowIndex, List<KeyValuePair<int, List<string>>> keyValues)
        {
            T local = this.queryMatrixTableMapRow(this.HtmlTableBodyGUI, matrixRowIndex, keyValues, false);
            if (local != null)
            {
                local.Parent = this;
            }
            return local;
        }

        protected virtual void WaitTableGridFillRows(int timeout = -1)
        {
            if (!this.IsDetectFillRows)
            {
                if (timeout <= 0)
                {
                    timeout = PageGUI.PageFindElementTimeout;
                }
                TestUtility.WaitFunc(delegate {
                    if (base.RowCount > 0)
                    {
                        base.IsDetectFillRows = true;
                        return true;
                    }
                    Manager.Current.ActiveBrowser.WaitForAjax(0x1388);
                    Thread.Sleep(300);
                    return false;
                }, timeout, true, "Wait TableGrid fill row data is timeout[{0}s].");
            }
        }

        protected virtual By BodyTableFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.BodyTable", null);
            }
        }

        protected virtual Dictionary<string, int> ColumnKeyMap
        {
            get
            {
                if (this._columnKeyMap == null)
                {
                    this._columnKeyMap = new Dictionary<string, int>();
                    this._matrixColumnCount = new int?(this.InitializeColumnMap(this._columnKeyMap));
                }
                return this._columnKeyMap;
            }
        }

        public TextComparison FinderTextComparison { get; set; }

        public TextFindCondition FinderTextCondition { get; set; }

        public int HeadRowCount
        {
            get
            {
                if (this.HtmlTableHeadGUI != null)
                {
                    return this.HtmlTableHeadGUI.Rows.length;
                }
                By headRowFinder = this.HeadRowFinder;
                if ((this.HtmlTableBodyGUI != null) && (headRowFinder == null))
                {
                    return this.HtmlTableBodyGUI.Rows.length;
                }
                return this.HeadRowsGUI.Count;
            }
        }

        protected virtual By HeadRowFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.HeadRow", null);
            }
        }

        public virtual IList<T> HeadRowsGUI
        {
            get
            {
                Func<DomElementGUI, T> selector = null;
                Func<DomElementGUI, T> func2 = null;
                if ((this.HtmlTableHeadGUI != null) && (this.HtmlTableHeadGUI.Rows.length > 0))
                {
                    Dictionary<string, int> dictionary1 = this.ColumnKeyMap;
                    if (selector == null)
                    {
                        selector = delegate (DomElementGUI item) {
                            T local = item.AsTo<T>();
                            local.Parent = this;
                            return local;
                        };
                    }
                    return this.getMatrixTableRows(this.HtmlTableHeadGUI).Select<DomElementGUI, T>(selector).ToList<T>();
                }
                By headRowFinder = this.HeadRowFinder;
                if (((this.HtmlTableBodyGUI == null) || (headRowFinder != null)) || (this.HtmlTableBodyGUI.Rows.length <= 0))
                {
                    return base.FindElementGUIs<T>(this.HeadRowFinder).Select<T, T>(delegate (T item) {
                        item.Parent = this;
                        return item;
                    }).ToList<T>();
                }
                Dictionary<string, int> columnKeyMap = this.ColumnKeyMap;
                if (func2 == null)
                {
                    func2 = delegate (DomElementGUI item) {
                        T local = item.AsTo<T>();
                        local.Parent = this;
                        return local;
                    };
                }
                return this.getMatrixTableRows(this.HtmlTableBodyGUI).Select<DomElementGUI, T>(func2).ToList<T>();
            }
        }

        protected HtmlTableSectionGUI HtmlTableBodyGUI
        {
            get
            {
                if (this.HtmlTableGUI.TBodies.length > 0)
                {
                    return this.HtmlTableGUI.TBodies[0];
                }
                return this.HtmlTableGUI;
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI HtmlTableGUI
        {
            get
            {
                if (!this._checkTableDome)
                {
                    By bodyTableFinder = this.BodyTableFinder;
                    if (bodyTableFinder != null)
                    {
                        this._tableGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>(bodyTableFinder, false);
                    }
                    if ((this._tableGUI == null) && base.TagName.Trim().Equals("table", StringComparison.OrdinalIgnoreCase))
                    {
                        this._tableGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>();
                    }
                    if (this._tableGUI == null)
                    {
                        this._tableGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>(By.TagName("table"), false);
                    }
                    this._checkTableDome = true;
                }
                return this._tableGUI;
            }
        }

        protected virtual HtmlTableSectionGUI HtmlTableHeadGUI
        {
            get
            {
                if (!this._checkTableHeadDome)
                {
                    if (this.HtmlTableGUI != null)
                    {
                        By tableHeadFinder = this.TableHeadFinder;
                        if (tableHeadFinder != null)
                        {
                            this._tableHeadGUI = base.FindDisplayedElementGUI<HtmlTableSectionGUI>(tableHeadFinder, false);
                        }
                        if (this._tableHeadGUI == null)
                        {
                            this._tableHeadGUI = this.HtmlTableGUI.THead;
                        }
                        if (this._tableHeadGUI == null)
                        {
                            this._tableHeadGUI = base.FindDisplayedElementGUI<HtmlTableTHeadGUI>(By.TagName("thead"), false);
                        }
                    }
                    this._checkTableHeadDome = true;
                }
                return this._tableHeadGUI;
            }
        }

        private bool IsDetectFillRows { get; set; }

        public virtual T this[int rowIndex]
        {
            get
            {
                this.WaitTableGridFillRows(-1);
                if (this.HtmlTableGUI == null)
                {
                    return this.RowsGUI[rowIndex];
                }
                T local = this.SearchRowItem(rowIndex, new string[0]);
                if (local == null)
                {
                    throw new InvalidOperationException("Can't find specify rowIndex row.");
                }
                return local;
            }
        }

        public virtual T this[string rowKeyValue]
        {
            get
            {
                this.WaitTableGridFillRows(-1);
                if (this.HtmlTableGUI == null)
                {
                    throw new NotImplementedException("Not Support for No-Table tag grid style.");
                }
                T local = this.SearchRowItem(-1, new string[] { rowKeyValue });
                if (local == null)
                {
                    throw new InvalidOperationException("Can't find specify rowKeyValue row.");
                }
                return local;
            }
        }

        public virtual DomElementGUI this[int rowIndex, int cellIndex]
        {
            get
            {
                T local = this[rowIndex];
                return local[cellIndex];
            }
        }

        public virtual DomElementGUI this[string rowKeyValue, string colName]
        {
            get
            {
                T local = this[rowKeyValue];
                return local[colName];
            }
        }

        public int MatrixColumnCount
        {
            get
            {
                if (!this._matrixColumnCount.HasValue)
                {
                    Dictionary<string, int> columnKeyMap = this.ColumnKeyMap;
                }
                return this._matrixColumnCount.Value;
            }
        }

        public int RowCount
        {
            get
            {
                if (this.HtmlTableGUI != null)
                {
                    return this.HtmlTableBodyGUI.Rows.length;
                }
                return this.RowsGUI.Count;
            }
        }

        protected virtual By RowFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.Row", By.CssSelector("tbody tr, .table-row"));
            }
        }

        public virtual IList<T> RowsGUI
        {
            get
            {
                Func<DomElementGUI, T> selector = null;
                if (this.HtmlTableBodyGUI == null)
                {
                    return base.FindElementGUIs<T>(this.RowFinder).Select<T, T>(delegate (T item) {
                        item.Parent = this;
                        return item;
                    }).ToList<T>();
                }
                if (selector == null)
                {
                    selector = delegate (DomElementGUI item) {
                        T local = item.AsTo<T>();
                        local.Parent = this;
                        return local;
                    };
                }
                return this.getMatrixTableRows(this.HtmlTableBodyGUI).Select<DomElementGUI, T>(selector).ToList<T>();
            }
        }

        protected virtual By TableHeadFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.TableHead", null);
            }
        }
    }
}

