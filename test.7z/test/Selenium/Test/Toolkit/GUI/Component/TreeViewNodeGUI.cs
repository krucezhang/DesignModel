﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public class TreeViewNodeGUI : DomElementGUI
    {
        internal TreeViewNodeGUI(IWebElement element) : base(element)
        {
            this.FinderTextCondition = TextFindCondition.Equals;
            this.FinderTextComparison = TextComparison.IgnoreCase;
            this.UseResourceTextFinder = true;
        }

        public override WebElementGUI UIClick()
        {
            this.TextGUI.UIClick();
            return this;
        }

        public override WebElementGUI UIDoubleClick()
        {
            this.TextGUI.UIDoubleClick();
            return this;
        }

        public TreeViewNodeGUI UIExpand()
        {
            if (((this.ChildrenBodyGUI != null) && base.TagName.Equals("li", StringComparison.OrdinalIgnoreCase)) && !base.HasClass("opened"))
            {
                this.UIClick();
            }
            return this;
        }

        public override WebElementGUI UIHover()
        {
            this.TextGUI.UIHover();
            return this;
        }

        protected DomElementGUI ChildrenBodyGUI
        {
            get
            {
                ArrayObject<DomElementGUI> children = this.Children;
                int length = children.length;
                for (int i = 0; i < length; i++)
                {
                    DomElementGUI tgui = children[i];
                    if (tgui.TagName.Equals("ul", StringComparison.OrdinalIgnoreCase))
                    {
                        return tgui;
                    }
                }
                return null;
            }
        }

        public override string ElementText
        {
            get
            {
                return this.TextGUI.ElementText;
            }
        }

        public DomElementGUI ExpandIconGUI
        {
            get
            {
                ArrayObject<DomElementGUI> children = this.Children;
                int length = children.length;
                for (int i = 0; i < length; i++)
                {
                    DomElementGUI tgui = children[i];
                    if (tgui.TagName.Equals("span", StringComparison.OrdinalIgnoreCase))
                    {
                        return tgui;
                    }
                }
                throw new InvalidProgramException("Can't find ExpandIcon in curretn item.");
            }
        }

        public TextComparison FinderTextComparison { get; set; }

        public TextFindCondition FinderTextCondition { get; set; }

        public TreeViewNodeGUI this[string[] text]
        {
            get
            {
                string str = string.Empty;
                TreeViewNodeGUI egui = null;
                for (int i = 0; i < text.Length; i++)
                {
                    str = ((i == 0) ? "" : "->") + text[i];
                    if (egui == null)
                    {
                        foreach (TreeViewNodeGUI egui2 in this.NodesGUI)
                        {
                            string elementText = egui2.ElementText;
                            if (ByContentText.CompareText(text[i], elementText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                            {
                                egui = egui2;
                                break;
                            }
                        }
                    }
                    else
                    {
                        egui = egui[new string[] { text[i] }];
                    }
                    if ((i >= (text.Length - 1)) && (egui != null))
                    {
                        return egui;
                    }
                }
                throw new NoSuchElementException(string.Format("Can't find item[Text:{0}] in TreeView.", str));
            }
        }

        public TreeViewNodeGUI LastChildItem
        {
            get
            {
                IList<TreeViewNodeGUI> nodesGUI = this.NodesGUI;
                if (nodesGUI.Count > 0)
                {
                    return nodesGUI[nodesGUI.Count - 1];
                }
                return null;
            }
        }

        public IList<TreeViewNodeGUI> NodesGUI
        {
            get
            {
                this.UIExpand();
                List<TreeViewNodeGUI> list = new List<TreeViewNodeGUI>();
                DomElementGUI childrenBodyGUI = this.ChildrenBodyGUI;
                ArrayObject<DomElementGUI> obj2 = (childrenBodyGUI == null) ? null : childrenBodyGUI.Children;
                int num = (obj2 == null) ? 0 : obj2.length;
                for (int i = 0; i < num; i++)
                {
                    DomElementGUI tgui2 = obj2[i];
                    if (tgui2.TagName.Equals("li", StringComparison.OrdinalIgnoreCase))
                    {
                        list.Add(tgui2.AsTo<TreeViewNodeGUI>());
                    }
                }
                return list;
            }
        }

        public DomElementGUI TextGUI
        {
            get
            {
                ArrayObject<DomElementGUI> children = this.Children;
                int length = children.length;
                for (int i = 0; i < length; i++)
                {
                    DomElementGUI tgui = children[i];
                    if (tgui.TagName.Equals("a", StringComparison.OrdinalIgnoreCase))
                    {
                        return tgui;
                    }
                }
                throw new InvalidProgramException("Can't find ItemText in curretn item.");
            }
        }
    }
}

