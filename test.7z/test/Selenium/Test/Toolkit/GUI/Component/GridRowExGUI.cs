﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class GridRowExGUI : DomElementGUI, IGridRowGUI
    {
        private bool _checkTableRowDome;
        private int _index;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI _tableRowGUI;

        public GridRowExGUI(IWebElement element) : base(element)
        {
            this._index = -1;
        }

        public int CellCount
        {
            get
            {
                if (this.HtmlTableRowGUI != null)
                {
                    return this.HtmlTableRowGUI.Cells.length;
                }
                return this.CellsGUI.Count;
            }
        }

        protected virtual By CellFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.Cell", By.CssSelector("td, th, .column"));
            }
        }

        public virtual IList<DomElementGUI> CellsGUI
        {
            get
            {
                Func<HtmlTableCellGUI, HtmlTableCellGUI> selector = null;
                if (this.HtmlTableRowGUI == null)
                {
                    return base.FindElementGUIs(this.CellFinder).Select<DomElementGUI, DomElementGUI>(delegate (DomElementGUI item) {
                        item.Parent = this;
                        return item;
                    }).ToList<DomElementGUI>();
                }
                if (selector == null)
                {
                    selector = delegate (HtmlTableCellGUI item) {
                        item.Parent = this;
                        return item;
                    };
                }
                return ((IEnumerable<DomElementGUI>) this.HtmlTableRowGUI.CellGUIs.Select<HtmlTableCellGUI, HtmlTableCellGUI>(selector)).ToList<DomElementGUI>();
            }
        }

        public IGridGUI GridGUI
        {
            get
            {
                return (this.Parent as IGridGUI);
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI HtmlTableRowGUI
        {
            get
            {
                if (!this._checkTableRowDome)
                {
                    if (base.TagName.Trim().Equals("tr", StringComparison.OrdinalIgnoreCase))
                    {
                        this._tableRowGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI>();
                    }
                    if (this._tableRowGUI == null)
                    {
                        this._tableRowGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableRowGUI>(By.TagName("tr"), false);
                    }
                    this._checkTableRowDome = true;
                }
                return this._tableRowGUI;
            }
        }

        public int Index
        {
            get
            {
                if (this._index < 0)
                {
                    int? jSProperty = this.ExecutableAdapter.GetJSProperty<int?>("matrixMapRowIndex");
                    if (!jSProperty.HasValue)
                    {
                        throw new InvalidProgramException("Current Row matrixMapRowIndex is override.");
                    }
                    this._index = jSProperty.Value;
                }
                return this._index;
            }
        }

        public virtual DomElementGUI this[int cellIndex]
        {
            get
            {
                if (this.HtmlTableRowGUI == null)
                {
                    return this.CellsGUI[cellIndex];
                }
                IGridGUI gridGUI = this.GridGUI;
                if (gridGUI != null)
                {
                    DomElementGUI matrixElementGUI = gridGUI.GetMatrixElementGUI(this.Index, cellIndex);
                    matrixElementGUI.Parent = this;
                    return matrixElementGUI;
                }
                return this.HtmlTableRowGUI.Cells[cellIndex];
            }
        }

        public virtual DomElementGUI this[string headName]
        {
            get
            {
                IGridGUI gridGUI = this.GridGUI;
                if (gridGUI != null)
                {
                    int columnIndex = gridGUI.GetColumnIndex(headName);
                    if (this.HtmlTableRowGUI != null)
                    {
                        DomElementGUI matrixElementGUI = gridGUI.GetMatrixElementGUI(this.Index, columnIndex);
                        matrixElementGUI.Parent = this;
                        return matrixElementGUI;
                    }
                    if ((gridGUI.MatrixColumnCount == this.CellCount) || (this.HtmlTableRowGUI == null))
                    {
                        return this[columnIndex];
                    }
                    int num2 = 0;
                    foreach (HtmlTableCellGUI lgui in this.CellsGUI)
                    {
                        int colSpan = lgui.ColSpan;
                        if ((columnIndex >= num2) && (columnIndex < (num2 + colSpan)))
                        {
                            return lgui;
                        }
                        num2 += colSpan;
                    }
                }
                throw new InvalidOperationException("The GridRow have not owner Grid.");
            }
        }
    }
}

