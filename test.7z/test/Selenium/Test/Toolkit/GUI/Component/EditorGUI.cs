﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;

    public class EditorGUI : DomElementGUI
    {
        private bool _checkInputDome;
        private bool _checkTextareaDome;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlInputGUI _inputGUI;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTextareaGUI _textareaGUI;

        public EditorGUI(IWebElement element) : base(element)
        {
        }

        public override WebElementGUI UISendKeys(string keysToSend)
        {
            return this.UISendKeys(keysToSend, true);
        }

        public virtual WebElementGUI UISendKeys(string keysToSend, bool ovrride)
        {
            if (this.HtmlInputGUI != null)
            {
                this.HtmlInputGUI.UISendKeys(keysToSend, ovrride);
                return this;
            }
            if (this.HtmlTextareaGUI != null)
            {
                this.HtmlTextareaGUI.UISendKeys(keysToSend, ovrride);
                return this;
            }
            if (ovrride)
            {
                this.UIClearValue();
            }
            else
            {
                this.UIClick();
                this.UIKeyHit(Keys.End, 1);
            }
            return base.UISendKeys(keysToSend);
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlInputGUI HtmlInputGUI
        {
            get
            {
                if (!this._checkInputDome)
                {
                    if (base.TagName.Trim().Equals("input", StringComparison.OrdinalIgnoreCase))
                    {
                        this._inputGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlInputGUI>();
                    }
                    if (this._inputGUI == null)
                    {
                        this._inputGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlInputGUI>(By.TagName("input"), false);
                    }
                    this._checkInputDome = true;
                }
                return this._inputGUI;
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTextareaGUI HtmlTextareaGUI
        {
            get
            {
                if (!this._checkTextareaDome)
                {
                    if (base.TagName.Trim().Equals("textarea", StringComparison.OrdinalIgnoreCase))
                    {
                        this._textareaGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTextareaGUI>();
                    }
                    if (this._textareaGUI == null)
                    {
                        this._textareaGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTextareaGUI>(By.TagName("textarea"), false);
                    }
                    this._checkTextareaDome = true;
                }
                return this._textareaGUI;
            }
        }
    }
}

