﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class GridGUI : GridGUI<GridRowGUI>
    {
        public GridGUI(IWebElement element) : base(element)
        {
        }
    }
}

