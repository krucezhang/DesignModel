﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class GridGUI<T> : DomElementGUI, IGridGUI where T: WebElementGUI, IGridRowGUI
    {
        private bool _checkTableDome;
        private Dictionary<string, int> _columnMap;
        private int? _matrixColumnCount;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI _tableGUI;

        public GridGUI(IWebElement element) : base(element)
        {
            this._matrixColumnCount = null;
        }

        public int GetColumnIndex(string columnName)
        {
            int num;
            if (!this.ColumnKeyMap.TryGetValue(columnName, out num))
            {
                throw new InvalidProgramException("Can't find specify column name.");
            }
            return num;
        }

        public virtual DomElementGUI GetMatrixElementGUI(int rowIndex, int cellIndex)
        {
            return this[rowIndex, cellIndex];
        }

        protected virtual int InitializeColumnMap(Dictionary<string, int> map)
        {
            IList<DomElementGUI> cellsGUI = this.HeadGUI.CellsGUI;
            int num = 0;
            bool flag = false;
            foreach (DomElementGUI tgui in cellsGUI)
            {
                if (num == 0)
                {
                    flag = tgui is HtmlTableCellGUI;
                }
                string elementText = tgui.ElementText;
                if (!map.ContainsKey(elementText))
                {
                    map.Add(tgui.ElementText, num);
                }
                num += flag ? (tgui as HtmlTableCellGUI).ColSpan : 1;
            }
            return num;
        }

        protected virtual By BodyTableFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.BodyTable", null);
            }
        }

        protected virtual Dictionary<string, int> ColumnKeyMap
        {
            get
            {
                if (this._columnMap == null)
                {
                    this._columnMap = new Dictionary<string, int>();
                    this._matrixColumnCount = new int?(this.InitializeColumnMap(this._columnMap));
                }
                return this._columnMap;
            }
        }

        protected virtual By HeadFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.Head", By.CssSelector("tHead tr, .table-head"));
            }
        }

        public virtual T HeadGUI
        {
            get
            {
                T local = default(T);
                if (this.HtmlTableGUI != null)
                {
                    HtmlTableTHeadGUI tHead = this.HtmlTableGUI.THead;
                    if ((tHead != null) && (tHead.Rows.length > 0))
                    {
                        local = tHead.Rows[0].AsTo<T>();
                        local.Parent = this;
                        return local;
                    }
                }
                local = base.FindDisplayedElementGUI<T>(this.HeadFinder, true);
                local.Parent = this;
                return local;
            }
        }

        protected HtmlTableSectionGUI HtmlTableBodyGUI
        {
            get
            {
                if (this.HtmlTableGUI.TBodies.length > 0)
                {
                    return this.HtmlTableGUI.TBodies[0];
                }
                return this.HtmlTableGUI;
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI HtmlTableGUI
        {
            get
            {
                if (!this._checkTableDome)
                {
                    By bodyTableFinder = this.BodyTableFinder;
                    if (bodyTableFinder != null)
                    {
                        this._tableGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>(bodyTableFinder, false);
                    }
                    if ((this._tableGUI == null) && base.TagName.Trim().Equals("table", StringComparison.OrdinalIgnoreCase))
                    {
                        this._tableGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>();
                    }
                    if (this._tableGUI == null)
                    {
                        this._tableGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlTableGUI>(By.TagName("table"), false);
                    }
                    this._checkTableDome = true;
                }
                return this._tableGUI;
            }
        }

        public virtual T this[int rowIndex]
        {
            get
            {
                if (this.HtmlTableGUI != null)
                {
                    T local = this.HtmlTableBodyGUI.Rows[rowIndex].AsTo<T>();
                    local.Parent = this;
                    return local;
                }
                return this.RowsGUI[rowIndex];
            }
        }

        public virtual DomElementGUI this[int rowIndex, int cellIndex]
        {
            get
            {
                if (this.HtmlTableGUI != null)
                {
                    HtmlTableRowGUI wgui = this.HtmlTableBodyGUI.Rows[rowIndex];
                    wgui.Parent = this;
                    return wgui[cellIndex];
                }
                T local = this.RowsGUI[rowIndex];
                return local[cellIndex];
            }
        }

        public virtual DomElementGUI this[int rowIndex, string headName]
        {
            get
            {
                if (this.HtmlTableGUI != null)
                {
                    T local = this.HtmlTableBodyGUI.Rows[rowIndex].AsTo<T>();
                    local.Parent = this;
                    return local[headName];
                }
                T local2 = this.RowsGUI[rowIndex];
                return local2[headName];
            }
        }

        public int MatrixColumnCount
        {
            get
            {
                if (!this._matrixColumnCount.HasValue)
                {
                    Dictionary<string, int> columnKeyMap = this.ColumnKeyMap;
                }
                return this._matrixColumnCount.Value;
            }
        }

        public int RowCount
        {
            get
            {
                if (this.HtmlTableGUI != null)
                {
                    return this.HtmlTableBodyGUI.Rows.length;
                }
                return this.RowsGUI.Count;
            }
        }

        protected virtual By RowFinder
        {
            get
            {
                return this.TryGetByFinder("GridGUI.Row", By.CssSelector("tbody tr, .table-row"));
            }
        }

        public virtual IList<T> RowsGUI
        {
            get
            {
                if (this.HtmlTableGUI == null)
                {
                    return base.FindElementGUIs<T>(this.RowFinder).Select<T, T>(delegate (T item) {
                        item.Parent = this;
                        return item;
                    }).ToList<T>();
                }
                List<T> list = new List<T>();
                foreach (HtmlTableRowGUI wgui in this.HtmlTableBodyGUI.RowGUIs)
                {
                    T local = wgui.AsTo<T>();
                    local.Parent = this;
                    list.Add(local);
                }
                return list;
            }
        }
    }
}

