﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public interface IGridRowGUI
    {
        int CellCount { get; }

        IList<DomElementGUI> CellsGUI { get; }

        int Index { get; }

        DomElementGUI this[int cellIndex] { get; }

        DomElementGUI this[string headName] { get; }
    }
}

