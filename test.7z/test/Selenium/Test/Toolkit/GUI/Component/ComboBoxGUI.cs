﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class ComboBoxGUI : ListViewGUI
    {
        private bool _checkHtmlSelectDome;
        private Selenium.Test.Toolkit.GUI.HtmlElement.HtmlSelectGUI _selectGUI;

        public ComboBoxGUI(IWebElement element) : base(element)
        {
        }

        public override ListGUI<DomElementGUI> UISelect(params string[] text)
        {
            if (text.Length == 1)
            {
                string selectedText = this.SelectedText;
                if (ByContentText.CompareText(text[0], selectedText, base.FinderTextCondition, base.FinderTextComparison, this.UseResourceTextFinder))
                {
                    return this;
                }
            }
            if (this.HtmlSelectGUI != null)
            {
                this.HtmlSelectGUI.FinderTextCondition = base.FinderTextCondition;
                this.HtmlSelectGUI.FinderTextComparison = base.FinderTextComparison;
                this.HtmlSelectGUI.UseResourceTextFinder = this.UseResourceTextFinder;
                this.HtmlSelectGUI.UISelectByText(text[0]);
                return this;
            }
            this.UIClick();
            this.DropDownListGUI.UISelect(text);
            return this;
        }

        protected virtual By DropDownListFinder
        {
            get
            {
                return this.TryGetByFinder("ComboBoxGUI.DropDownList", null);
            }
        }

        public virtual ListGUI<DomElementGUI> DropDownListGUI
        {
            get
            {
                Func<bool> action = null;
                IWebElement webElement = this.WebElement;
                By dropDownFinder = this.DropDownListFinder;
                ListGUI<DomElementGUI> dropDownList = null;
                if (dropDownFinder != null)
                {
                    if (action == null)
                    {
                        action = delegate {
                            dropDownList = this.FindDisplayedElementGUI<ListGUI<DomElementGUI>>(dropDownFinder, false);
                            if (dropDownList == null)
                            {
                                dropDownList = Manager.Current.ActiveBrowser.FindDisplayedElementGUI<ListGUI<DomElementGUI>>(dropDownFinder, false);
                            }
                            return dropDownList != null;
                        };
                    }
                    TestUtility.WaitFunc(action, PageGUI.PageFindElementTimeout, true, "Wait Find ComboBoxGUI.DropDownList is timeout[{0}s]");
                }
                dropDownList.FinderTextCondition = base.FinderTextCondition;
                dropDownList.FinderTextComparison = base.FinderTextComparison;
                dropDownList.UseResourceTextFinder = this.UseResourceTextFinder;
                if (this.ItemFinder != null)
                {
                    dropDownList.Finders.Add("ListGUI.Item", this.ItemFinder);
                }
                return dropDownList;
            }
        }

        protected virtual Selenium.Test.Toolkit.GUI.HtmlElement.HtmlSelectGUI HtmlSelectGUI
        {
            get
            {
                if (!this._checkHtmlSelectDome)
                {
                    if (base.TagName.Trim().Equals("select", StringComparison.OrdinalIgnoreCase))
                    {
                        this._selectGUI = this.AsTo<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlSelectGUI>();
                    }
                    if (this._selectGUI == null)
                    {
                        this._selectGUI = base.FindDisplayedElementGUI<Selenium.Test.Toolkit.GUI.HtmlElement.HtmlSelectGUI>(By.TagName("select"), false);
                    }
                    this._checkHtmlSelectDome = true;
                }
                return this._selectGUI;
            }
        }

        protected override By ItemFinder
        {
            get
            {
                return this.TryGetByFinder("ComboBoxGUI.Item", base.ItemFinder);
            }
        }

        public override IList<DomElementGUI> ItemsGUI
        {
            get
            {
                if (this.HtmlSelectGUI != null)
                {
                    return this.HtmlSelectGUI.SelectOptionsGUI.ToList<DomElementGUI>();
                }
                this.UIClick();
                IList<DomElementGUI> itemsGUI = this.DropDownListGUI.ItemsGUI;
                this.UIClick();
                return itemsGUI;
            }
        }

        public virtual string SelectedText
        {
            get
            {
                if (this.HtmlSelectGUI != null)
                {
                    return this.HtmlSelectGUI.ElementText;
                }
                return this.ElementText;
            }
        }
    }
}

