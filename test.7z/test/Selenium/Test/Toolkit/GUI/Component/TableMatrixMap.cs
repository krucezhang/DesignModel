﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.GUI.HtmlElement;
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class TableMatrixMap : IDisposable
    {
        private int _currentRowIndex;
        private WebElementGUI[,] _matrixMap;
        private List<WebElementGUI> _rowList;

        public TableMatrixMap(int maxRowCount, int maxColCount, Dictionary<string, int> columnKeyMap = null)
        {
            this.MaxRowCount = maxRowCount;
            this.MaxColCount = maxColCount;
            this.ColumnKeyMap = columnKeyMap;
            this._matrixMap = new WebElementGUI[this.MaxRowCount, this.MaxColCount];
            this._rowList = new List<WebElementGUI>();
        }

        public void Dispose()
        {
            this.ColumnKeyMap = null;
            this._matrixMap = null;
            if (this._rowList != null)
            {
                this._rowList.Clear();
                this._rowList = null;
            }
        }

        public void FillMap(HtmlTableRowGUI rowGUI)
        {
            if (rowGUI.WebElement.get_Displayed())
            {
                int height = rowGUI.Bounds.Height;
                int num2 = 0;
                foreach (IWebElement element in rowGUI.WebCellElements)
                {
                    if (element.get_Displayed())
                    {
                        while (this._matrixMap[this._currentRowIndex, num2] != null)
                        {
                            num2++;
                        }
                        HtmlTableCellGUI lgui = new HtmlTableCellGUI(element);
                        int num3 = Math.Max(1, lgui.RowSpan) - ((height > 0) ? 0 : 1);
                        int num4 = Math.Max(1, lgui.ColSpan);
                        if (num3 > 0)
                        {
                            if (this.ColumnKeyMap != null)
                            {
                                string elementText = lgui.ElementText;
                                if (!this.ColumnKeyMap.ContainsKey(elementText))
                                {
                                    this.ColumnKeyMap.Add(elementText, num2);
                                }
                            }
                            for (int i = this._currentRowIndex; i < (this._currentRowIndex + num3); i++)
                            {
                                for (int j = num2; j < (num2 + num4); j++)
                                {
                                    this._matrixMap[i, j] = lgui;
                                }
                            }
                        }
                    }
                }
                if (height > 0)
                {
                    this._rowList.Add(rowGUI);
                    this._currentRowIndex++;
                }
            }
        }

        public Dictionary<string, int> ColumnKeyMap { get; private set; }

        public int CurrentRowIndex
        {
            get
            {
                return this._currentRowIndex;
            }
        }

        public WebElementGUI this[int row, int col]
        {
            get
            {
                if (row >= this._currentRowIndex)
                {
                    throw new ArgumentException("row indexed is large than current search row area.", "row");
                }
                return this._matrixMap[row, col];
            }
        }

        public int MaxColCount { get; set; }

        public int MaxRowCount { get; set; }

        public List<WebElementGUI> Rows
        {
            get
            {
                return this._rowList;
            }
        }
    }
}

