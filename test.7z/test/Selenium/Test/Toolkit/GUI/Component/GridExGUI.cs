﻿namespace Selenium.Test.Toolkit.GUI.Component
{
    using OpenQA.Selenium;
    using System;

    public class GridExGUI : GridExGUI<GridRowExGUI>
    {
        public GridExGUI(IWebElement element) : base(element)
        {
        }
    }
}

