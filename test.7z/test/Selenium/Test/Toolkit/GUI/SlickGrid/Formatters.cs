﻿namespace Selenium.Test.Toolkit.GUI.SlickGrid
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public static class Formatters
    {
        public static CodeSnippet Checkmark = new CodeSnippet("Slick.Formatters.Checkmark", string.Empty, new object[0]);
        public static CodeSnippet PercentComplete = new CodeSnippet("Slick.Formatters.PercentComplete", string.Empty, new object[0]);
        public static CodeSnippet PercentCompleteBar = new CodeSnippet("Slick.Formatters.PercentCompleteBar", string.Empty, new object[0]);
        public static CodeSnippet YesNo = new CodeSnippet("Slick.Formatters.YesNo", string.Empty, new object[0]);
    }
}

