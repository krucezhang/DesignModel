﻿namespace Selenium.Test.Toolkit.GUI.SlickGrid
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class SlickGridOptions : JSOptions
    {
        public SlickGridOptions() : base(null)
        {
        }

        internal SlickGridOptions(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public int asyncEditorLoadDelay
        {
            get
            {
                return this.GetJSProperty<int>("asyncEditorLoadDelay");
            }
            set
            {
                this.SetJSProperty("asyncEditorLoadDelay", value);
            }
        }

        public bool asyncEditorLoading
        {
            get
            {
                return this.GetJSProperty<bool>("asyncEditorLoading");
            }
            set
            {
                this.SetJSProperty("asyncEditorLoading", value);
            }
        }

        public int asyncPostRenderDelay
        {
            get
            {
                return this.GetJSProperty<int>("asyncPostRenderDelay");
            }
            set
            {
                this.SetJSProperty("asyncPostRenderDelay", value);
            }
        }

        public bool autoEdit
        {
            get
            {
                return this.GetJSProperty<bool>("autoEdit");
            }
            set
            {
                this.SetJSProperty("autoEdit", value);
            }
        }

        public bool autoHeight
        {
            get
            {
                return this.GetJSProperty<bool>("autoHeight");
            }
            set
            {
                this.SetJSProperty("autoHeight", value);
            }
        }

        public string cellFlashingCssClass
        {
            get
            {
                return this.GetJSProperty<string>("cellFlashingCssClass");
            }
            set
            {
                this.SetJSProperty("cellFlashingCssClass", value);
            }
        }

        public string cellHighlightCssClass
        {
            get
            {
                return this.GetJSProperty<string>("cellHighlightCssClass");
            }
            set
            {
                this.SetJSProperty("cellHighlightCssClass", value);
            }
        }

        public CodeSnippet dataItemColumnValueExtractor
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("dataItemColumnValueExtractor", null), "dataItemColumnValueExtractorFunc");
            }
            set
            {
                this.SetJSProperty("dataItemColumnValueExtractor", value);
            }
        }

        public int defaultColumnWidth
        {
            get
            {
                return this.GetJSProperty<int>("defaultColumnWidth");
            }
            set
            {
                this.SetJSProperty("defaultColumnWidth", value);
            }
        }

        public CodeSnippet defaultFormatter
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("defaultFormatter", null), "defaultFormatterFunc");
            }
            set
            {
                this.SetJSProperty("defaultFormatter", value);
            }
        }

        public bool editable
        {
            get
            {
                return this.GetJSProperty<bool>("editable");
            }
            set
            {
                this.SetJSProperty("editable", value);
            }
        }

        public CodeSnippet editCommandHandler
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("editCommandHandler", null), "editCommandHandlerFunc");
            }
            set
            {
                this.SetJSProperty("editCommandHandler", value);
            }
        }

        public CodeSnippet editorFactory
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("editorFactory", null), "editorFactoryFunc");
            }
            set
            {
                this.SetJSProperty("editorFactory", value);
            }
        }

        public CodeSnippet editorLock
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("editorLock", null), "editorLockFunc");
            }
            set
            {
                this.SetJSProperty("editorLock", value);
            }
        }

        public bool enableAddRow
        {
            get
            {
                return this.GetJSProperty<bool>("enableAddRow");
            }
            set
            {
                this.SetJSProperty("enableAddRow", value);
            }
        }

        public bool enableAsyncPostRender
        {
            get
            {
                return this.GetJSProperty<bool>("enableAsyncPostRender");
            }
            set
            {
                this.SetJSProperty("enableAsyncPostRender", value);
            }
        }

        public bool enableCellNavigation
        {
            get
            {
                return this.GetJSProperty<bool>("enableCellNavigation");
            }
            set
            {
                this.SetJSProperty("enableCellNavigation", value);
            }
        }

        public bool enableCellRangeSelection
        {
            get
            {
                return this.GetJSProperty<bool>("enableCellRangeSelection");
            }
            set
            {
                this.SetJSProperty("enableCellRangeSelection", value);
            }
        }

        public bool enableColumnReorder
        {
            get
            {
                return this.GetJSProperty<bool>("enableColumnReorder");
            }
            set
            {
                this.SetJSProperty("enableColumnReorder", value);
            }
        }

        public CodeSnippet enableRowReordering
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("enableRowReordering", null), "enableRowReorderingFunc");
            }
            set
            {
                this.SetJSProperty("enableRowReordering", value);
            }
        }

        public bool enableTextSelectionOnCells
        {
            get
            {
                return this.GetJSProperty<bool>("enableTextSelectionOnCells");
            }
            set
            {
                this.SetJSProperty("enableTextSelectionOnCells", value);
            }
        }

        public bool explicitInitialization
        {
            get
            {
                return this.GetJSProperty<bool>("explicitInitialization");
            }
            set
            {
                this.SetJSProperty("explicitInitialization", value);
            }
        }

        public bool forceFitColumns
        {
            get
            {
                return this.GetJSProperty<bool>("forceFitColumns");
            }
            set
            {
                this.SetJSProperty("forceFitColumns", value);
            }
        }

        public bool forceSyncScrolling
        {
            get
            {
                return this.GetJSProperty<bool>("forceSyncScrolling");
            }
            set
            {
                this.SetJSProperty("forceSyncScrolling", value);
            }
        }

        public CodeSnippet formatterFactory
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("formatterFactory", null), "formatterFactoryFunc");
            }
            set
            {
                this.SetJSProperty("formatterFactory", value);
            }
        }

        public bool fullWidthRows
        {
            get
            {
                return this.GetJSProperty<bool>("fullWidthRows");
            }
            set
            {
                this.SetJSProperty("fullWidthRows", value);
            }
        }

        public int headerRowHeight
        {
            get
            {
                return this.GetJSProperty<int>("headerRowHeight");
            }
            set
            {
                this.SetJSProperty("headerRowHeight", value);
            }
        }

        public bool leaveSpaceForNewRows
        {
            get
            {
                return this.GetJSProperty<bool>("leaveSpaceForNewRows");
            }
            set
            {
                this.SetJSProperty("leaveSpaceForNewRows", value);
            }
        }

        public bool multiColumnSort
        {
            get
            {
                return this.GetJSProperty<bool>("multiColumnSort");
            }
            set
            {
                this.SetJSProperty("multiColumnSort", value);
            }
        }

        public bool multiSelect
        {
            get
            {
                return this.GetJSProperty<bool>("multiSelect");
            }
            set
            {
                this.SetJSProperty("multiSelect", value);
            }
        }

        public int rowHeight
        {
            get
            {
                return this.GetJSProperty<int>("rowHeight");
            }
            set
            {
                this.SetJSProperty("rowHeight", value);
            }
        }

        public string selectedCellCssClass
        {
            get
            {
                return this.GetJSProperty<string>("selectedCellCssClass");
            }
            set
            {
                this.SetJSProperty("selectedCellCssClass", value);
            }
        }

        public bool showHeaderRow
        {
            get
            {
                return this.GetJSProperty<bool>("showHeaderRow");
            }
            set
            {
                this.SetJSProperty("showHeaderRow", value);
            }
        }

        public bool syncColumnCellResize
        {
            get
            {
                return this.GetJSProperty<bool>("syncColumnCellResize");
            }
            set
            {
                this.SetJSProperty("syncColumnCellResize", value);
            }
        }

        public int topPanelHeight
        {
            get
            {
                return this.GetJSProperty<int>("topPanelHeight");
            }
            set
            {
                this.SetJSProperty("topPanelHeight", value);
            }
        }
    }
}

