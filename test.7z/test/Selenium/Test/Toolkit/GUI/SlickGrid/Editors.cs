﻿namespace Selenium.Test.Toolkit.GUI.SlickGrid
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public static class Editors
    {
        public static CodeSnippet Checkbox = new CodeSnippet("Slick.Editors.Checkbox", string.Empty, new object[0]);
        public static CodeSnippet Date = new CodeSnippet("Slick.Editors.Date", string.Empty, new object[0]);
        public static CodeSnippet Integer = new CodeSnippet("Slick.Editors.Integer", string.Empty, new object[0]);
        public static CodeSnippet LongText = new CodeSnippet("Slick.Editors.LongText", string.Empty, new object[0]);
        public static CodeSnippet PercentComplete = new CodeSnippet("Slick.Editors.PercentComplete", string.Empty, new object[0]);
        public static CodeSnippet Text = new CodeSnippet("Slick.Editors.Text", string.Empty, new object[0]);
        public static CodeSnippet YesNoSelect = new CodeSnippet("Slick.Editors.YesNoSelect", string.Empty, new object[0]);
    }
}

