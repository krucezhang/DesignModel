﻿namespace Selenium.Test.Toolkit.GUI.SlickGrid
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class SlickGridGUI : DomElementGUI
    {
        private CodeSnippet _dependedScript;

        private SlickGridGUI(CodeSnippet slickInstance) : base(null, Rectangle.Empty)
        {
            this._dependedScript = slickInstance;
            this.AssignElement(this.getCanvasNode().WebElement);
        }

        public SlickGridGUI(By by, CodeSnippet data, ArrayObject<ColumnOptions> columns, SlickGridOptions options = null) : base(by)
        {
            if (columns == null)
            {
                throw new ArgumentNullException("columns can't is Null.");
            }
            this.InitSlickGrid(this.WebElement, data, columns, options);
        }

        public void autosizeColumns()
        {
            this.ExecutableAdapter.InvokeJSMehtod("autosizeColumns", new object[0]);
        }

        public bool canCellBeActive(int row, int col)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("canCellBeActive", new object[] { row, col });
        }

        public bool canCellBeSelected(int row, int col)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("canCellBeSelected", new object[] { row, col });
        }

        public void editActiveCell(CodeSnippet editor)
        {
            this.ExecutableAdapter.InvokeJSMehtod("editActiveCell", new object[] { editor });
        }

        public void flashCell(int row, int cell)
        {
            this.ExecutableAdapter.InvokeJSMehtod("flashCell", new object[] { row, cell });
        }

        public void flashCell(int row, int cell, int speed)
        {
            this.ExecutableAdapter.InvokeJSMehtod("flashCell", new object[] { row, cell, speed });
        }

        public CodeSnippet getActiveCell()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getActiveCell", null, new object[0]), "SlickGridActiveCell");
        }

        public DomElementGUI getActiveCellNode()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<DomElementGUI>("getActiveCellNode", new object[0]);
        }

        public CodeSnippet getActiveCellPosition()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getActiveCellPosition", null, new object[0]), "SlickGridActiveCellPosition");
        }

        public DomElementGUI getCanvasNode()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<DomElementGUI>("getCanvasNode", new object[0]);
        }

        public DomElementGUI getCellEditor()
        {
            CodeSnippet code = this.ExecutableAdapter.GetInvokeJSSnippet("getCellEditor", "cellEditor1", new object[0]);
            if (this.ExecutableAdapter.IsNullJSObject(code))
            {
                return null;
            }
            return new ExecutableObject(code).GetJSProperty<ExecutableObject>("args").GetJSProperty<DomElementGUI>("container");
        }

        public CodeSnippet getCellFromPoint(int x, int y)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getCellFromPoint", string.Empty, new object[] { x, y }), "SlickGridCellFromPoint");
        }

        public DomElementGUI getCellNode(int row, int cell)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<DomElementGUI>("getCellNode", new object[] { row, cell });
        }

        public CodeSnippet getCellNodeBox(int row, int cell)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getCellNodeBox", string.Empty, new object[] { row, cell }), "SlickGridCellNodeBox");
        }

        public int getColumnIndex(string id)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<int>("getColumnIndex", new object[] { id });
        }

        public ArrayObject<ExecutableObject> getColumns()
        {
            return new ArrayObject<ExecutableObject>(this.ExecutableAdapter.GetInvokeJSSnippet("getColumns", "columns", new object[0]));
        }

        public List<object> getData()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<List<object>>("getData", new object[0]);
        }

        public CodeSnippet getDataItem(int index)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getDataItem", string.Empty, new object[] { index }), "slickgridDataItem");
        }

        public int getDataLength()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<int>("getDataLength", new object[0]);
        }

        public CodeSnippet getGridPosition()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getGridPosition", null, new object[0]), "SlickGridPosition");
        }

        public DomElementGUI getHeaderRow()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<DomElementGUI>("getHeaderRow", new object[0]);
        }

        public DomElementGUI getHeaderRowColumn(string columnId)
        {
            return this.ExecutableAdapter.InvokeJSMehtod<DomElementGUI>("getHeaderRowColumn", new object[0]);
        }

        public ExecutableObject getOptions()
        {
            return new ExecutableObject(this.ExecutableAdapter.GetInvokeJSSnippet("getOptions", null, new object[0]));
        }

        public CodeSnippet getRenderedRange()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getRenderedRange", null, new object[0]), "SlickGridRenderedRange");
        }

        public CodeSnippet getRenderedRange(int viewportTop)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getRenderedRange", string.Empty, new object[] { viewportTop }), "SlickGridRenderedRange");
        }

        public CodeSnippet getRenderedRange(int viewportTop, int viewportLeft)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getRenderedRange", string.Empty, new object[] { viewportTop, viewportLeft }), "SlickGridRenderedRange");
        }

        public IList<int> getSelectedRows()
        {
            List<int> list = new List<int>();
            IList list2 = this.ExecutableAdapter.InvokeJSMehtod<IList>("getSelectedRows", new object[0]);
            for (int i = 0; i < list2.Count; i++)
            {
                list.Add(Convert.ToInt32(list2[i]));
            }
            return list;
        }

        public CodeSnippet getSelectionModel()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getSelectionModel", null, new object[0]), "SlickGridSelectionModel");
        }

        public CodeSnippet getSortColumns()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getSortColumns", null, new object[0]), "SlickGridSortColumns");
        }

        public CodeSnippet getTopPanel()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getTopPanel", null, new object[0]), "SlickGridTopPanel");
        }

        public CodeSnippet getViewport()
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getViewport", null, new object[0]), "SlickGridViewport");
        }

        public CodeSnippet getViewport(int viewportTop)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getViewport", string.Empty, new object[] { viewportTop }), "SlickGridViewport");
        }

        public CodeSnippet getViewport(int viewportTop, int viewportLeft)
        {
            return this.ExecutableAdapter.GetExecutedJSSnippet(this.ExecutableAdapter.GetInvokeJSSnippet("getViewport", string.Empty, new object[] { viewportTop, viewportLeft }), "SlickGridViewport");
        }

        public void gotoCell(int row, int cell)
        {
            this.ExecutableAdapter.InvokeJSMehtod("gotoCell", new object[] { row, cell });
        }

        public void gotoCell(int row, int cell, bool forceEdit)
        {
            this.ExecutableAdapter.InvokeJSMehtod("gotoCell", new object[] { row, cell, forceEdit });
        }

        public void init()
        {
            this.ExecutableAdapter.InvokeJSMehtod("init", new object[0]);
        }

        private void InitSlickGrid(IWebElement element, CodeSnippet data, ArrayObject<ColumnOptions> columns, SlickGridOptions options)
        {
            this._dependedScript = this.ExecutableAdapter.GetCtorJSSnippet("Slick.Grid", "SlickGrid", new object[] { element, data, columns, options });
        }

        public static SlickGridGUI Instance(string header)
        {
            if (string.IsNullOrEmpty(header))
            {
                return null;
            }
            return new SlickGridGUI(new CodeSnippet(header, string.Empty, new object[0]));
        }

        public void invalidate()
        {
            this.ExecutableAdapter.InvokeJSMehtod("invalidate", new object[0]);
        }

        public void invalidateAllRows()
        {
            this.ExecutableAdapter.InvokeJSMehtod("invalidateAllRows", new object[0]);
        }

        public void invalidateRow(int row)
        {
            this.ExecutableAdapter.InvokeJSMehtod("invalidateRow", new object[] { row });
        }

        public void invalidateRows(Array rows)
        {
            this.ExecutableAdapter.InvokeJSMehtod("invalidateRows", new object[] { rows });
        }

        public bool navigateDown()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigateDown", new object[0]);
        }

        public bool navigateLeft()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigateLeft", new object[0]);
        }

        public bool navigateNext()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigateNext", new object[0]);
        }

        public bool navigatePrev()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigatePrev", new object[0]);
        }

        public bool navigateRight()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigateRight", new object[0]);
        }

        public bool navigateUp()
        {
            return this.ExecutableAdapter.InvokeJSMehtod<bool>("navigateUp", new object[0]);
        }

        public void removeCellCssStyles(string key)
        {
            this.ExecutableAdapter.InvokeJSMehtod("removeCellCssStyles", new object[] { key });
        }

        public void render()
        {
            this.ExecutableAdapter.InvokeJSMehtod("render", new object[0]);
        }

        public void resetActiveCell()
        {
            this.ExecutableAdapter.InvokeJSMehtod("resetActiveCell", new object[0]);
        }

        public void resizeCanvas()
        {
            this.ExecutableAdapter.InvokeJSMehtod("resizeCanvas", new object[0]);
        }

        public void scrollCellIntoView(int row, int cell)
        {
            this.ExecutableAdapter.InvokeJSMehtod("scrollCellIntoView", new object[] { row, cell });
        }

        public void scrollRowIntoView(int row)
        {
            this.ExecutableAdapter.InvokeJSMehtod("scrollRowIntoView", new object[] { row });
        }

        public void scrollRowIntoView(int row, bool doPaging)
        {
            this.ExecutableAdapter.InvokeJSMehtod("scrollRowIntoView", new object[] { row, doPaging });
        }

        public void scrollRowToTop(int row)
        {
            this.ExecutableAdapter.InvokeJSMehtod("scrollRowToTop", new object[] { row });
        }

        public void setActiveCell(int row, int cell)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setActiveCell", new object[] { row, cell });
        }

        public void setColumns(CodeSnippet columnDefinitions)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setColumns", new object[] { columnDefinitions });
        }

        public void setData(CodeSnippet newData, bool scrollToTop)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setData", new object[] { newData, scrollToTop });
        }

        public void setHeaderRowVisibility(bool visible)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setHeaderRowVisibility", new object[] { visible });
        }

        public void setOptions(SlickGridOptions options)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setOptions", new object[] { options });
        }

        public void setSelectedRows(List<int> rowsArray)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setSelectedRows", new object[] { rowsArray });
        }

        public void setSelectionModel(CodeSnippet selectionModel)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setSelectionModel", new object[] { selectionModel });
        }

        public void setSortColumn(string columnId, bool ascending)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setSortColumn", new object[] { columnId, ascending });
        }

        public void setSortColumns(CodeSnippet cols)
        {
            this.ExecutableAdapter.InvokeJSMehtod("setSortColumns", new object[] { cols });
        }

        public void updateCell(int row, int cell)
        {
            this.ExecutableAdapter.InvokeJSMehtod("updateCell", new object[] { row, cell });
        }

        public void updateColumnHeader(string columnId, string title, string toolTip = null)
        {
            if (toolTip == null)
            {
                this.ExecutableAdapter.InvokeJSMehtod("updateColumnHeader", new object[] { columnId, title });
            }
            else
            {
                this.ExecutableAdapter.InvokeJSMehtod("updateColumnHeader", new object[] { columnId, title, toolTip });
            }
        }

        public void updateRow(int row)
        {
            this.ExecutableAdapter.InvokeJSMehtod("updateRow", new object[] { row });
        }

        public void updateRowCount()
        {
            this.ExecutableAdapter.InvokeJSMehtod("updateRowCount", new object[0]);
        }

        public override ExecutableObject ExecutableAdapter
        {
            get
            {
                return new ExecutableObject(this._dependedScript);
            }
        }
    }
}

