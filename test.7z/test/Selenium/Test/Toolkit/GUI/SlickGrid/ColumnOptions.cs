﻿namespace Selenium.Test.Toolkit.GUI.SlickGrid
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class ColumnOptions : JSOptions
    {
        public ColumnOptions() : base(null)
        {
        }

        internal ColumnOptions(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public CodeSnippet asyncPostRender
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("asyncPostRender", null), "asyncPostRenderFunc");
            }
            set
            {
                this.SetJSProperty("asyncPostRender", value);
            }
        }

        public CodeSnippet behavior
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("behavior", null), "behaviorFunc");
            }
            set
            {
                this.SetJSProperty("behavior", value);
            }
        }

        public bool cannotTriggerInsert
        {
            get
            {
                return this.GetJSProperty<bool>("cannotTriggerInsert");
            }
            set
            {
                this.SetJSProperty("cannotTriggerInsert", value);
            }
        }

        public string cssClass
        {
            get
            {
                return this.GetJSProperty<string>("cssClass");
            }
            set
            {
                this.SetJSProperty("cssClass", value);
            }
        }

        public bool defaultSortAsc
        {
            get
            {
                return this.GetJSProperty<bool>("defaultSortAsc");
            }
            set
            {
                this.SetJSProperty("defaultSortAsc", value);
            }
        }

        public CodeSnippet editor
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("editor", null), "editorFunc");
            }
            set
            {
                this.SetJSProperty("editor", value);
            }
        }

        public string field
        {
            get
            {
                return this.GetJSProperty<string>("field");
            }
            set
            {
                this.SetJSProperty("field", value);
            }
        }

        public bool focusable
        {
            get
            {
                return this.GetJSProperty<bool>("focusable");
            }
            set
            {
                this.SetJSProperty("focusable", value);
            }
        }

        public CodeSnippet formatter
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("formatter", null), "formatterFunc");
            }
            set
            {
                this.SetJSProperty("formatter", value);
            }
        }

        public CodeSnippet headerCssClass
        {
            get
            {
                return this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet("headerCssClass", null), "headerCssClassFunc");
            }
            set
            {
                this.SetJSProperty("headerCssClass", value);
            }
        }

        public string id
        {
            get
            {
                return this.GetJSProperty<string>("id");
            }
            set
            {
                this.SetJSProperty("id", value);
            }
        }

        public int maxWidth
        {
            get
            {
                return this.GetJSProperty<int>("maxWidth");
            }
            set
            {
                this.SetJSProperty("maxWidth", value);
            }
        }

        public int minWidth
        {
            get
            {
                return this.GetJSProperty<int>("minWidth");
            }
            set
            {
                this.SetJSProperty("minWidth", value);
            }
        }

        public string name
        {
            get
            {
                return this.GetJSProperty<string>("name");
            }
            set
            {
                this.SetJSProperty("name", value);
            }
        }

        public bool rerenderOnResize
        {
            get
            {
                return this.GetJSProperty<bool>("rerenderOnResize");
            }
            set
            {
                this.SetJSProperty("rerenderOnResize", value);
            }
        }

        public bool resizable
        {
            get
            {
                return this.GetJSProperty<bool>("resizable");
            }
            set
            {
                this.SetJSProperty("resizable", value);
            }
        }

        public bool selectable
        {
            get
            {
                return this.GetJSProperty<bool>("selectable");
            }
            set
            {
                this.SetJSProperty("selectable", value);
            }
        }

        public bool sortable
        {
            get
            {
                return this.GetJSProperty<bool>("sortable");
            }
            set
            {
                this.SetJSProperty("sortable", value);
            }
        }

        public string toolTip
        {
            get
            {
                return this.GetJSProperty<string>("toolTip");
            }
            set
            {
                this.SetJSProperty("toolTip", value);
            }
        }

        public int width
        {
            get
            {
                return this.GetJSProperty<int>("width");
            }
            set
            {
                this.SetJSProperty("width", value);
            }
        }
    }
}

