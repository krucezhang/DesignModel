﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Runtime.CompilerServices;

    public class HtmlSelectGUI : DomElementGUI
    {
        public HtmlSelectGUI(By by) : base(by)
        {
        }

        public HtmlSelectGUI(IWebElement element) : base(element)
        {
        }

        public HtmlSelectGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            this.FinderTextCondition = TextFindCondition.Equals;
            this.FinderTextComparison = TextComparison.IgnoreCase;
            this.UseResourceTextFinder = true;
            if (!element.get_TagName().Equals("select", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("InputElement must be a 'select' tag");
            }
            base.AssignElement(element);
        }

        public HtmlSelectGUI UISelectByIndex(int index)
        {
            this.UIHover();
            this.SelectElement.SelectByIndex(index);
            return this;
        }

        public HtmlSelectGUI UISelectByText(string text)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Firefox)
            {
                this.UIClick();
            }
            else
            {
                this.UIHover();
            }
            return this.UISelectOption(text);
        }

        protected virtual HtmlSelectGUI UISelectOption(string text)
        {
            IList<HtmlSelectOptionGUI> selectOptionsGUI = this.SelectOptionsGUI;
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Firefox)
            {
                HtmlSelectOptionGUI ngui = null;
                for (int i = 0; i < selectOptionsGUI.Count; i++)
                {
                    HtmlSelectOptionGUI ngui2 = selectOptionsGUI[i];
                    string elementText = ngui2.ElementText;
                    if (ByContentText.CompareText(text, elementText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                    {
                        if (selectOptionsGUI.Count > this.size)
                        {
                            ngui2.Selected = true;
                            Manager.Current.ActiveBrowser.WaitForAjax(0x1388);
                            if (ByContentText.CompareText(text, this.ElementText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                            {
                                this.UIClick();
                                return this;
                            }
                            if (ngui != null)
                            {
                                ngui.Selected = true;
                            }
                            else
                            {
                                selectOptionsGUI[i + 1].Selected = true;
                            }
                        }
                        ngui2.UIClick();
                        return this;
                    }
                    ngui = ngui2;
                }
                throw new InvalidOperationException(string.Format("Can't find option[Text : {0}] in Select DOM.", text));
            }
            foreach (HtmlSelectOptionGUI ngui3 in selectOptionsGUI)
            {
                string actualText = ngui3.ElementText;
                if (ByContentText.CompareText(text, actualText, this.FinderTextCondition, this.FinderTextComparison, this.UseResourceTextFinder))
                {
                    ngui3.WebElement.Click();
                    Manager.Current.ActiveBrowser.WaitForAjax(0x1388);
                    return this;
                }
            }
            throw new InvalidOperationException(string.Format("Can't find option[Text : {0}] in Select DOM.", text));
        }

        public bool Autofocus
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("autofocus");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("autofocus", value);
            }
        }

        public bool Disabled
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("disabled");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("disabled", value);
            }
        }

        public override string ElementText
        {
            get
            {
                int selectedIndex = this.selectedIndex;
                if (selectedIndex < 0)
                {
                    return string.Empty;
                }
                return this.Options[selectedIndex].ElementText;
            }
        }

        public TextComparison FinderTextComparison { get; set; }

        public TextFindCondition FinderTextCondition { get; set; }

        public int length
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("length");
            }
        }

        public bool Multiple
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("multiple");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("multiple", value);
            }
        }

        public string name
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("name");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("name", value);
            }
        }

        public ArrayObject<HtmlSelectOptionGUI> Options
        {
            get
            {
                return new ArrayObject<HtmlSelectOptionGUI>(this.ExecutableAdapter.GetJSPropertyJSSnippet("options", null));
            }
        }

        public int selectedIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("selectedIndex");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("selectedIndex", value);
            }
        }

        public int SelectedIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("selectedIndex");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("selectedIndex", value);
            }
        }

        public ArrayObject<HtmlSelectOptionGUI> SelectedOptions
        {
            get
            {
                return new ArrayObject<HtmlSelectOptionGUI>(this.ExecutableAdapter.GetJSPropertyJSSnippet("selectedOptions", null));
            }
        }

        public OpenQA.Selenium.Support.UI.SelectElement SelectElement
        {
            get
            {
                return new OpenQA.Selenium.Support.UI.SelectElement(this.WebElement);
            }
        }

        public IList<HtmlSelectOptionGUI> SelectOptionsGUI
        {
            get
            {
                return base.FindElementGUIs<HtmlSelectOptionGUI>(By.TagName("option"));
            }
        }

        public int size
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("size");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("size", value);
            }
        }

        public string value
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("value");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("value", value);
            }
        }
    }
}

