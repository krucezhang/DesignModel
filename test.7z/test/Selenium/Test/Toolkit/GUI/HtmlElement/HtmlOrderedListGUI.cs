﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Drawing;

    public class HtmlOrderedListGUI : DomElementGUI
    {
        public HtmlOrderedListGUI(By by) : base(by)
        {
        }

        public HtmlOrderedListGUI(IWebElement element) : base(element)
        {
        }

        public HtmlOrderedListGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("ol", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Ordered list must be a 'ol' tag");
            }
            base.AssignElement(element);
        }

        public ArrayObject<HtmlListItemGUI> ListItems
        {
            get
            {
                return new ArrayObject<HtmlListItemGUI>(this.ExecutableAdapter.GetInvokeJSSnippet("getElementsByTagName", string.Empty, new object[] { "li" }));
            }
        }

        public int Start
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("start");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("start", value);
            }
        }

        public string Type
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("type");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("type", value);
            }
        }
    }
}

