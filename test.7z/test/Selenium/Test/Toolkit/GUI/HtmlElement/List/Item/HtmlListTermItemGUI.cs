﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement.List.Item
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class HtmlListTermItemGUI : DomElementGUI
    {
        public HtmlListTermItemGUI(By by) : base(by)
        {
        }

        public HtmlListTermItemGUI(IWebElement element) : base(element)
        {
        }

        public HtmlListTermItemGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("dt", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Description term item must be a 'dt' tag");
            }
            base.AssignElement(element);
        }
    }
}

