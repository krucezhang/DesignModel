﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;

    public class HtmlInputGUI : DomElementGUI
    {
        public HtmlInputGUI(By by) : base(by)
        {
        }

        public HtmlInputGUI(IWebElement element) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("input", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("InputElement must be a 'input' tag");
            }
            base.AssignElement(element);
        }

        public override WebElementGUI UISendKeys(string keysToSend)
        {
            return this.UISendKeys(keysToSend, true);
        }

        public virtual HtmlInputGUI UISendKeys(string keysToSend, bool ovrride)
        {
            string str = this.Value;
            if (ovrride)
            {
                if (str == keysToSend)
                {
                    return this;
                }
                if (string.IsNullOrEmpty(str))
                {
                    this.UIClick();
                }
                else
                {
                    this.UIClearValue();
                }
            }
            else
            {
                this.UIClick();
                this.UIKeyHit(Keys.End, 1);
            }
            base.UISendKeys(keysToSend);
            if (string.IsNullOrEmpty(str) || ovrride)
            {
                str = string.Empty;
            }
            for (int i = 0; i < 2; i++)
            {
                string str2 = null;
                try
                {
                    str2 = this.Value;
                }
                catch
                {
                    break;
                }
                if (str2 == (str + keysToSend))
                {
                    break;
                }
                this.UIClearValue();
                base.UISendKeys(str + keysToSend);
            }
            return this;
        }

        public bool Checked
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("checked");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("checked", value);
            }
        }

        public bool Disabled
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("disabled");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("disabled", value);
            }
        }

        public override string ElementText
        {
            get
            {
                string str = this.Value;
                if (string.IsNullOrEmpty(str))
                {
                    return string.Empty;
                }
                return str.Trim();
            }
        }

        public int Max
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("max");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("max", value);
            }
        }

        public int Maxlength
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("maxlength");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("maxlength", value);
            }
        }

        public string Placeholder
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("placeholder");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("placeholder", value);
            }
        }

        public bool ReadonlyOption
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("readonly");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("readonly", value);
            }
        }

        public bool Required
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("required");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("required", value);
            }
        }

        public string Type
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("type");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("type", value);
            }
        }

        public string Value
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("value");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("value", value);
            }
        }
    }
}

