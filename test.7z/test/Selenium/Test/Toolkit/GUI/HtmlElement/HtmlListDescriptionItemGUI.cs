﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class HtmlListDescriptionItemGUI : DomElementGUI
    {
        public HtmlListDescriptionItemGUI(By by) : base(by)
        {
        }

        public HtmlListDescriptionItemGUI(IWebElement element) : base(element)
        {
        }

        public HtmlListDescriptionItemGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("dd", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("list item must be a 'dd' tag");
            }
            base.AssignElement(element);
        }
    }
}

