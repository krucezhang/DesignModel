﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using System;
    using System.Drawing;

    public class HtmlTableTBodyGUI : HtmlTableSectionGUI
    {
        public HtmlTableTBodyGUI(By by) : base(by)
        {
        }

        public HtmlTableTBodyGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableTBodyGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
        }

        protected override void CheckTargetHtmlTagName(string tagName)
        {
            if (!tagName.Equals("tbody", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("The element must be a 'tbody' tag");
            }
        }
    }
}

