﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class HtmlListItemGUI : DomElementGUI
    {
        public HtmlListItemGUI(By by) : base(by)
        {
        }

        public HtmlListItemGUI(IWebElement element) : base(element)
        {
        }

        public HtmlListItemGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("li", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("list item must be a 'li' tag");
            }
            base.AssignElement(element);
        }
    }
}

