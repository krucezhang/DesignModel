﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class HtmlSelectOptionGUI : DomElementGUI
    {
        public HtmlSelectOptionGUI(By by) : base(by)
        {
        }

        public HtmlSelectOptionGUI(IWebElement element) : base(element)
        {
        }

        public HtmlSelectOptionGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("option", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Table cell must be a 'option' tag");
            }
            base.AssignElement(element);
        }

        public bool defaultSelected
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("defaultSelected");
            }
        }

        public bool Disabled
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("disabled");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("disabled", value);
            }
        }

        public override string ElementText
        {
            get
            {
                return this.Label.Trim();
            }
        }

        public int index
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("index");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("index", value);
            }
        }

        public string Label
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("label");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("label", value);
            }
        }

        public bool Selected
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("selected");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("selected", value);
            }
        }

        public string text
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("text");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("text", value);
            }
        }

        public string value
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("value");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("value", value);
            }
        }
    }
}

