﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Reflection;

    public class HtmlTableSectionGUI : DomElementGUI
    {
        public HtmlTableSectionGUI(By by) : base(by)
        {
        }

        public HtmlTableSectionGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableSectionGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            this.CheckTargetHtmlTagName(element.get_TagName());
            base.AssignElement(element);
        }

        protected virtual void CheckTargetHtmlTagName(string tagName)
        {
            if ((!tagName.Equals("table", StringComparison.OrdinalIgnoreCase) && !tagName.Equals("tbody", StringComparison.OrdinalIgnoreCase)) && (!tagName.Equals("thead", StringComparison.OrdinalIgnoreCase) && !tagName.Equals("tfoot", StringComparison.OrdinalIgnoreCase)))
            {
                throw new ArgumentException("The element must be a 'table' or 'tbody' or 'thead' or 'tfoot' tag");
            }
        }

        public HtmlTableCellGUI this[int rowIndex, int colIndex]
        {
            get
            {
                return this.Rows[rowIndex].Cells[colIndex];
            }
        }

        public IList<HtmlTableRowGUI> RowGUIs
        {
            get
            {
                List<IWebElement> jSProperty = this.ExecutableAdapter.GetJSProperty<List<IWebElement>>("rows");
                List<HtmlTableRowGUI> list2 = new List<HtmlTableRowGUI>();
                foreach (IWebElement element in jSProperty)
                {
                    list2.Add(new HtmlTableRowGUI(element));
                }
                return list2;
            }
        }

        public ArrayObject<HtmlTableRowGUI> Rows
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<ArrayObject<HtmlTableRowGUI>>("rows");
            }
        }

        public List<IWebElement> WebRowElements
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<List<IWebElement>>("rows");
            }
        }
    }
}

