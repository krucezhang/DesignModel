﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class HtmlTableCellGUI : DomElementGUI
    {
        private string _elementTagName;

        public HtmlTableCellGUI(By by) : base(by)
        {
            this._elementTagName = "td";
        }

        public HtmlTableCellGUI(IWebElement element) : base(element)
        {
            this._elementTagName = "td";
        }

        public HtmlTableCellGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
            this._elementTagName = "td";
        }

        protected override void AssignElement(IWebElement element)
        {
            this._elementTagName = element.get_TagName();
            if (!this._elementTagName.Equals("td", StringComparison.OrdinalIgnoreCase) && !this._elementTagName.Equals("th", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Table cell must be a 'td' or 'th' tag");
            }
            base.AssignElement(element);
        }

        public int CellIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("cellIndex");
            }
        }

        public int ColSpan
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("colSpan");
            }
        }

        public bool IsHeadCell
        {
            get
            {
                return this._elementTagName.Equals("th", StringComparison.OrdinalIgnoreCase);
            }
        }

        public int RowSpan
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("rowSpan");
            }
        }
    }
}

