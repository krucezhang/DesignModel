﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Runtime.InteropServices;

    public class HtmlTextareaGUI : DomElementGUI
    {
        public HtmlTextareaGUI(By by) : base(by)
        {
        }

        public HtmlTextareaGUI(IWebElement element) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("textarea", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("InputElement must be a 'textarea' tag");
            }
            base.AssignElement(element);
        }

        protected void InnerUISendKeys(string inputStr, bool isBRwithAlt = false)
        {
            if (!string.IsNullOrEmpty(inputStr))
            {
                string[] strArray = inputStr.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                for (int i = 0; i < strArray.Length; i++)
                {
                    if (i > 0)
                    {
                        if (isBRwithAlt)
                        {
                            this.UIKeyHitWithAlt(Keys.Enter);
                        }
                        else
                        {
                            this.UIKeyHit(Keys.Enter, 1);
                        }
                    }
                    base.UISendKeys(strArray[i]);
                }
            }
        }

        public void Select()
        {
            this.ExecutableAdapter.InvokeJSMehtod("select", new object[0]);
        }

        public override WebElementGUI UIClearValue()
        {
            this.UIClick();
            this.UIKeyHitWithControl(Keys.Home);
            this.UIKeyHitWithControlShift(Keys.End);
            this.UIKeyHit(Keys.Backspace, 1);
            return this;
        }

        public override WebElementGUI UISendKeys(string keysToSend)
        {
            return this.UISendKeys(keysToSend, true);
        }

        public WebElementGUI UISendKeys(string inputStr, bool ovrride)
        {
            string str = this.Value;
            if (ovrride)
            {
                if (str == inputStr)
                {
                    return this;
                }
                if (string.IsNullOrEmpty(str))
                {
                    this.UIClick();
                }
                else
                {
                    this.UIClearValue();
                }
            }
            else
            {
                this.UIClick();
                this.UIKeyHitWithControl(Keys.End);
            }
            this.InnerUISendKeys(inputStr, false);
            if (string.IsNullOrEmpty(str) || ovrride)
            {
                str = string.Empty;
            }
            for (int i = 0; i < 2; i++)
            {
                string str2 = null;
                try
                {
                    str2 = this.Value;
                }
                catch
                {
                    break;
                }
                if (str2 == (str + inputStr))
                {
                    break;
                }
                if (string.IsNullOrEmpty(str))
                {
                    this.UIClearValue();
                    this.InnerUISendKeys(inputStr, false);
                }
                else
                {
                    this.UIKeyHit(Keys.Home, 1);
                    this.UIKeyHitWithShift(Keys.End);
                    this.UIKeyHit(Keys.Backspace, 1);
                    this.InnerUISendKeys(inputStr, false);
                }
            }
            return this;
        }

        public HtmlTextareaGUI UISendKeysWithAlt(string inputStr, bool ovrride = true)
        {
            string str = this.Value;
            if (ovrride)
            {
                if (string.IsNullOrEmpty(str))
                {
                    this.UIClick();
                }
                else
                {
                    this.UIClearValue();
                }
            }
            else
            {
                this.UIClick();
                this.UIKeyHitWithControl(Keys.End);
            }
            this.InnerUISendKeys(inputStr, true);
            if (string.IsNullOrEmpty(str) || ovrride)
            {
                str = string.Empty;
            }
            for (int i = 0; i < 2; i++)
            {
                string str2 = null;
                try
                {
                    str2 = this.Value;
                }
                catch
                {
                    break;
                }
                if (str2 == (str + inputStr))
                {
                    break;
                }
                if (string.IsNullOrEmpty(str))
                {
                    this.UIClearValue();
                    this.InnerUISendKeys(inputStr, true);
                }
                else
                {
                    this.UIKeyHit(Keys.Home, 1);
                    this.UIKeyHitWithShift(Keys.End);
                    this.UIKeyHit(Keys.Backspace, 1);
                    this.InnerUISendKeys(inputStr, true);
                }
            }
            return this;
        }

        public bool Disabled
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("disabled");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("disabled", value);
            }
        }

        public override string ElementText
        {
            get
            {
                string str = this.Value;
                if (string.IsNullOrEmpty(str))
                {
                    return string.Empty;
                }
                return str.Trim();
            }
        }

        public virtual bool Readonly
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<bool>("readonly");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("readonly", value);
            }
        }

        public string Type
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("type");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("type", value);
            }
        }

        public string Value
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<string>("value");
            }
            set
            {
                this.ExecutableAdapter.SetJSProperty("value", value);
            }
        }
    }
}

