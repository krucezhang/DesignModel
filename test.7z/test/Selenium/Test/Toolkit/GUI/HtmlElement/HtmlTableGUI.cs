﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Drawing;

    public class HtmlTableGUI : HtmlTableSectionGUI
    {
        public HtmlTableGUI(By by) : base(by)
        {
        }

        public HtmlTableGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("table", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Table must be a 'table' tag");
            }
            base.AssignElement(element);
        }

        public DomElementGUI Caption
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<DomElementGUI>("caption");
            }
        }

        public ArrayObject<HtmlTableTBodyGUI> TBodies
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<ArrayObject<HtmlTableTBodyGUI>>("tBodies");
            }
        }

        public HtmlTableTFootGUI TFoot
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<HtmlTableTFootGUI>("tFoot");
            }
        }

        public HtmlTableTHeadGUI THead
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<HtmlTableTHeadGUI>("tHead");
            }
        }
    }
}

