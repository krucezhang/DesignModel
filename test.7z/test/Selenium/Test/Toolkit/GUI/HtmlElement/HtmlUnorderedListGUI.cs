﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Drawing;

    public class HtmlUnorderedListGUI : DomElementGUI
    {
        public HtmlUnorderedListGUI(By by) : base(by)
        {
        }

        public HtmlUnorderedListGUI(IWebElement element) : base(element)
        {
        }

        public HtmlUnorderedListGUI(IWebElement element, Rectangle bounds) : base(element)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("ul", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Unordered list must be a 'ul' tag");
            }
            base.AssignElement(element);
        }

        public ArrayObject<HtmlListItemGUI> ListItems
        {
            get
            {
                return new ArrayObject<HtmlListItemGUI>(this.ExecutableAdapter.GetInvokeJSSnippet("getElementsByTagName", string.Empty, new object[] { "li" }));
            }
        }
    }
}

