﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using System;
    using System.Drawing;

    public class HtmlTableTHeadGUI : HtmlTableSectionGUI
    {
        public HtmlTableTHeadGUI(By by) : base(by)
        {
        }

        public HtmlTableTHeadGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableTHeadGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
        }

        protected override void CheckTargetHtmlTagName(string tagName)
        {
            if (!tagName.Equals("thead", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("The element must be a 'thead' tag");
            }
        }
    }
}

