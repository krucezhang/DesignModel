﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Reflection;

    public class HtmlTableRowGUI : DomElementGUI
    {
        public HtmlTableRowGUI(By by) : base(by)
        {
        }

        public HtmlTableRowGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableRowGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("tr", StringComparison.OrdinalIgnoreCase) && !element.get_TagName().Equals("th", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Table row must be a 'tr' tag");
            }
            base.AssignElement(element);
        }

        public IList<HtmlTableCellGUI> CellGUIs
        {
            get
            {
                List<IWebElement> jSProperty = this.ExecutableAdapter.GetJSProperty<List<IWebElement>>("cells");
                List<HtmlTableCellGUI> list2 = new List<HtmlTableCellGUI>();
                foreach (IWebElement element in jSProperty)
                {
                    list2.Add(new HtmlTableCellGUI(element));
                }
                return list2;
            }
        }

        public ArrayObject<HtmlTableCellGUI> Cells
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<ArrayObject<HtmlTableCellGUI>>("cells");
            }
        }

        public HtmlTableCellGUI this[int index]
        {
            get
            {
                return this.Cells[index];
            }
        }

        public int RowIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("rowIndex");
            }
        }

        public int SectionRowIndex
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<int>("sectionRowIndex");
            }
        }

        public List<IWebElement> WebCellElements
        {
            get
            {
                return this.ExecutableAdapter.GetJSProperty<List<IWebElement>>("cells");
            }
        }
    }
}

