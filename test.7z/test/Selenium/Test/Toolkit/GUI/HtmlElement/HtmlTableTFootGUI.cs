﻿namespace Selenium.Test.Toolkit.GUI.HtmlElement
{
    using OpenQA.Selenium;
    using System;
    using System.Drawing;

    public class HtmlTableTFootGUI : HtmlTableSectionGUI
    {
        public HtmlTableTFootGUI(By by) : base(by)
        {
        }

        public HtmlTableTFootGUI(IWebElement element) : base(element)
        {
        }

        public HtmlTableTFootGUI(IWebElement element, Rectangle bounds) : base(element, bounds)
        {
        }

        protected override void AssignElement(IWebElement element)
        {
            if (!element.get_TagName().Equals("tfoot", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("The element must be a 'tfoot' tag");
            }
            base.AssignElement(element);
        }
    }
}

