﻿namespace Selenium.Test.Toolkit.GUI
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;

    public abstract class PageGUI : IDisposable, IFindElementGUI
    {
        private static bool? _AutoAdjustPageNavigation = null;
        private static bool? _CheckElementEnabled = null;
        private Selenium.Test.Toolkit.Core.FinderBuffer _finderBuffer;
        private static int _PageFindElementTimeout = -1;
        private static int _PageLoadedTimeout = -1;
        private static int _PageUploadFileTimeout = -1;
        private bool _useFinderBuffer;
        internal static string CurrentPageTypeName = string.Empty;

        public PageGUI()
        {
            ComponentFactory.InitElements(this);
        }

        public virtual void AutoAdjustPageLoaded()
        {
            AutoAdjustPageLoaded(this, base.GetType().FullName);
        }

        internal static void AutoAdjustPageLoaded(IFindElementGUI page, string pageTypeName)
        {
            if ((CurrentPageTypeName != pageTypeName) && AutoAdjustPageNavigation)
            {
                PageGUI egui = page as PageGUI;
                if (egui != null)
                {
                    CurrentPageTypeName = pageTypeName;
                    egui.WaitPageLoaded();
                }
            }
        }

        public virtual void Dispose()
        {
            if (this._finderBuffer != null)
            {
                this._finderBuffer.Dispose();
                this._finderBuffer = null;
            }
        }

        public virtual bool ExistElement(IElementGUI element)
        {
            return ((element != null) && element.IsExistElement);
        }

        public DomElementGUI FindDisplayedElementGUI(By by)
        {
            return this.FindDisplayedElementGUI<DomElementGUI>(by);
        }

        public T FindDisplayedElementGUI<T>(By by)
        {
            return this.FindDisplayedElementGUI<T>(by, false);
        }

        public T FindDisplayedElementGUI<T>(By by, bool throwExpection)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.FindDisplayedElementGUI<T>(by, throwExpection);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public IList<DomElementGUI> FindDisplayedElementGUIs(By by)
        {
            return this.FindDisplayedElementGUIs<DomElementGUI>(by);
        }

        public IList<T> FindDisplayedElementGUIs<T>(By by)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase))
            {
                return (IList<T>) obj2;
            }
            IList<T> list = this.ActiveBrowser.FindDisplayedElementGUIs<T>(by);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, list, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return list;
        }

        public DomElementGUI FindElementGUI(By by)
        {
            return this.FindElementGUI<DomElementGUI>(by);
        }

        public T FindElementGUI<T>(By by)
        {
            return this.FindElementGUI<T>(by, true);
        }

        public T FindElementGUI<T>(By by, bool throwExpection)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.FindElementGUI<T>(by, throwExpection);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public IList<DomElementGUI> FindElementGUIs(By by)
        {
            return this.FindElementGUIs<DomElementGUI>(by);
        }

        public IList<T> FindElementGUIs<T>(By by)
        {
            object obj2;
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase))
            {
                return (IList<T>) obj2;
            }
            IList<T> list = this.ActiveBrowser.FindElementGUIs<T>(by);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, list, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return list;
        }

        protected virtual double InnerWaitPageLoaded(int dwellTime, int timeout, Func<bool> waitCallback = null)
        {
            bool isCurrentPage = false;
            bool flag2 = false;
            bool flag3 = false;
            DateTime now = DateTime.Now;
            while (DateTime.Now.Subtract(now) < TimeSpan.FromMilliseconds((double) timeout))
            {
                if (!isCurrentPage)
                {
                    isCurrentPage = this.IsCurrentPage;
                }
                if (isCurrentPage && !flag2)
                {
                    try
                    {
                        flag2 = !this.ExistElement(this.LoadingDomElement);
                    }
                    catch
                    {
                    }
                }
                if (flag2 && !flag3)
                {
                    flag3 = (waitCallback == null) ? true : waitCallback();
                }
                if (flag3)
                {
                    if (dwellTime > 0)
                    {
                        return 0.0;
                    }
                    return this.ActiveBrowser.BOMWindow.performance.now();
                }
                Thread.Sleep(dwellTime);
            }
            if (!isCurrentPage)
            {
                throw new InvalidProgramException(string.Format("Wait navigation to {0} is timeout[{1}s].", base.GetType().Name, timeout / 0x3e8));
            }
            if (!flag2)
            {
                throw new InvalidProgramException(string.Format("Wait {0} Loading DOM Element disappearance is timeout[{1}s].", base.GetType().Name, timeout / 0x3e8));
            }
            throw new InvalidProgramException(string.Format("Wait {0} custom callback is timeout[{1}s].", base.GetType().Name, timeout / 0x3e8));
        }

        public double PerformanceWaitPageLoaded()
        {
            return this.PerformanceWaitPageLoaded(PageLoadedTimeout, null);
        }

        public double PerformanceWaitPageLoaded(Func<bool> waitCallback)
        {
            return this.PerformanceWaitPageLoaded(PageLoadedTimeout, waitCallback);
        }

        public virtual double PerformanceWaitPageLoaded(int timeout, Func<bool> waitCallback = null)
        {
            return this.InnerWaitPageLoaded(0, timeout, waitCallback);
        }

        public DomElementGUI WaitFindDisplayedElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindDisplayedElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindDisplayedElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, text, condition, comparison) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.WaitFindDisplayedElementGUI<T>(new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, text, condition, comparison);
            return local;
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.WaitFindDisplayedElementGUI<T>(by, throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.Display, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public DomElementGUI WaitFindElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, text, condition, comparison) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.WaitFindElementGUI<T>(new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, text, condition, comparison);
            return local;
        }

        public DomElementGUI WaitFindElementGUI(By by, int timeout)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            object obj2;
            if (timeout < 0)
            {
                timeout = PageFindElementTimeout;
            }
            if (this.FinderBuffer.TryGetElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, out obj2, "", TextFindCondition.Equals, TextComparison.IgnoreCase) && (obj2 is T))
            {
                return (T) obj2;
            }
            T local = this.ActiveBrowser.WaitFindElementGUI<T>(by, throwExpection, timeout);
            this.FinderBuffer.UpdateElement(by, Selenium.Test.Toolkit.Core.FinderBuffer.ElementVisibility.UnKnow, local, "", TextFindCondition.Equals, TextComparison.IgnoreCase);
            return local;
        }

        public virtual void WaitPageLoaded()
        {
            this.WaitPageLoaded(PageLoadedTimeout, null);
        }

        public virtual void WaitPageLoaded(Func<bool> waitCallback)
        {
            this.WaitPageLoaded(PageLoadedTimeout, waitCallback);
        }

        public virtual void WaitPageLoaded(int timeout, Func<bool> waitCallback = null)
        {
            this.ActiveBrowser.WaitForAjax(timeout);
            this.InnerWaitPageLoaded(300, timeout, waitCallback);
        }

        protected Browser ActiveBrowser
        {
            get
            {
                return Manager.Current.ActiveBrowser;
            }
        }

        public static bool AutoAdjustPageNavigation
        {
            get
            {
                if (!_AutoAdjustPageNavigation.HasValue)
                {
                    _AutoAdjustPageNavigation = true;
                    try
                    {
                        string str = ConfigurationManager.AppSettings["AutoAdjustPageNavigation"];
                        if (!string.IsNullOrWhiteSpace(str))
                        {
                            _AutoAdjustPageNavigation = new bool?(Convert.ToBoolean(str));
                        }
                    }
                    catch
                    {
                    }
                }
                return _AutoAdjustPageNavigation.Value;
            }
            set
            {
                _AutoAdjustPageNavigation = new bool?(value);
            }
        }

        public static bool CheckElementEnabled
        {
            get
            {
                if (!_CheckElementEnabled.HasValue)
                {
                    _CheckElementEnabled = true;
                    try
                    {
                        string str = ConfigurationManager.AppSettings["CheckElementEnabled"];
                        if (!string.IsNullOrWhiteSpace(str))
                        {
                            _CheckElementEnabled = new bool?(Convert.ToBoolean(str));
                        }
                    }
                    catch
                    {
                    }
                }
                return _CheckElementEnabled.Value;
            }
            set
            {
                _CheckElementEnabled = new bool?(value);
            }
        }

        protected Selenium.Test.Toolkit.Core.FinderBuffer FinderBuffer
        {
            get
            {
                if (this._finderBuffer == null)
                {
                    this._finderBuffer = new Selenium.Test.Toolkit.Core.FinderBuffer();
                    this._finderBuffer.Enable = this.UseFinderBuffer;
                }
                return this._finderBuffer;
            }
        }

        public virtual bool IsCurrentPage
        {
            get
            {
                try
                {
                    this.ActiveBrowser.WaitForAjax(PageLoadedTimeout);
                    return this.ExistElement(this.PageIdentifier);
                }
                catch
                {
                    return false;
                }
            }
        }

        public virtual DomElementGUI LoadingDomElement { get; set; }

        public static int PageFindElementTimeout
        {
            get
            {
                if (_PageFindElementTimeout < 0)
                {
                    _PageFindElementTimeout = 0x1388;
                    try
                    {
                        string str = ConfigurationManager.AppSettings["PageFindElementTimeout"];
                        if (!string.IsNullOrWhiteSpace(str))
                        {
                            _PageFindElementTimeout = Convert.ToInt32(str);
                        }
                    }
                    catch
                    {
                    }
                }
                return _PageFindElementTimeout;
            }
            set
            {
                _PageFindElementTimeout = value;
            }
        }

        public virtual DomElementGUI PageIdentifier { get; set; }

        public static int PageLoadedTimeout
        {
            get
            {
                if (_PageLoadedTimeout < 0)
                {
                    _PageLoadedTimeout = 0xea60;
                    try
                    {
                        string str = ConfigurationManager.AppSettings["PageLoadedTimeout"];
                        if (!string.IsNullOrWhiteSpace(str))
                        {
                            _PageLoadedTimeout = Convert.ToInt32(str);
                        }
                    }
                    catch
                    {
                    }
                }
                return _PageLoadedTimeout;
            }
            set
            {
                _PageLoadedTimeout = value;
            }
        }

        public static int PageUploadFileTimeout
        {
            get
            {
                if (_PageUploadFileTimeout < 0)
                {
                    _PageUploadFileTimeout = 0x7530;
                    try
                    {
                        string str = ConfigurationManager.AppSettings["PageUploadFileTimeout"];
                        if (!string.IsNullOrWhiteSpace(str))
                        {
                            _PageUploadFileTimeout = Convert.ToInt32(str);
                        }
                    }
                    catch
                    {
                    }
                }
                return _PageUploadFileTimeout;
            }
            set
            {
                _PageUploadFileTimeout = value;
            }
        }

        public bool UseFinderBuffer
        {
            get
            {
                return this._useFinderBuffer;
            }
            set
            {
                this._useFinderBuffer = value;
                this.FinderBuffer.Enable = this._useFinderBuffer;
            }
        }

        public virtual bool UseResourceTextFinder { get; set; }
    }
}

