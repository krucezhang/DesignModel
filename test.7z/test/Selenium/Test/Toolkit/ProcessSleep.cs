﻿namespace Selenium.Test.Toolkit
{
    using System;
    using System.Threading;
    using System.Windows.Forms;

    public static class ProcessSleep
    {
        private static bool flag = false;
        private static Timer timer = new Timer();

        public static void WaitAWhile(float seconds)
        {
            timer.Tick += new EventHandler(ProcessSleep.Waiting);
            timer.Interval = Convert.ToInt32((float) (seconds * 1000f));
            timer.Enabled = true;
            flag = true;
            timer.Start();
            while (flag)
            {
                Thread.Sleep(10);
                Application.DoEvents();
            }
            timer.Tick -= new EventHandler(ProcessSleep.Waiting);
        }

        private static void Waiting(object sender, EventArgs e)
        {
            timer.Stop();
            timer.Enabled = false;
            flag = false;
        }
    }
}

