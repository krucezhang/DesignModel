﻿namespace Selenium.Test.Toolkit.Desktop
{
    using System;

    public enum OffsetReference
    {
        TopLeftCorner,
        BottomLeftCorner,
        TopRightCorner,
        BottomRightCorner,
        TopCenter,
        RightCenter,
        LeftCenter,
        BottomCenter,
        AbsoluteCenter
    }
}

