﻿namespace Selenium.Test.Toolkit.Desktop
{
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class KeyBoard : IDisposable
    {
        private Browser _browser;
        private const short altCode = 0x12;
        private const short ctrlCode = 0x11;
        private const int KEYEVENTF_EXTENDEDKEY = 1;
        private const int KEYEVENTF_KEYUP = 2;
        private const int KEYEVENTF_UNICODE = 4;
        private static int s_keyDownDelay = 50;
        private const short shiftCode = 0x10;

        internal KeyBoard(Browser browser)
        {
            this._browser = browser;
        }

        public void Dispose()
        {
            this._browser = null;
        }

        private void DoKeyDown(Keys code, bool delay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                Win32NativeMethods.INPUT[] inputData = new Win32NativeMethods.INPUT[1];
                InitializeNonUnicodeKeyBoardEvent(ref inputData[0], code, true);
                Win32NativeMethods.SendInputInternal(inputData);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        private void DoKeyPressDelay()
        {
            Thread.Sleep(KeyDownDelay);
        }

        private void DoKeyUp(Keys code, bool delay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                Win32NativeMethods.INPUT[] inputData = new Win32NativeMethods.INPUT[1];
                InitializeNonUnicodeKeyBoardEvent(ref inputData[0], code, false);
                Win32NativeMethods.SendInputInternal(inputData);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        private static void InitializeNonUnicodeKeyBoardEvent(ref Win32NativeMethods.INPUT inputEvent, Keys key, bool down)
        {
            inputEvent.type = 1;
            inputEvent.union.keyboardInput.wVk = (short) key;
            inputEvent.union.keyboardInput.dwFlags = down ? 0 : 2;
        }

        private static void InitializeUnicodeKeyBoardEvent(ref Win32NativeMethods.INPUT inputEvent, short key, bool down)
        {
            inputEvent.type = 1;
            inputEvent.union.keyboardInput.wVk = 0;
            inputEvent.union.keyboardInput.wScan = key;
            inputEvent.union.keyboardInput.dwFlags = down ? 4 : 6;
            inputEvent.union.keyboardInput.time = 0;
            inputEvent.union.keyboardInput.dwExtraInfo = IntPtr.Zero;
            if ((key & 0xff00) == 0xe000)
            {
                inputEvent.union.keyboardInput.dwFlags |= 1;
            }
        }

        public void KeyDown(Keys key)
        {
            this.KeyDown(key, true);
        }

        private void KeyDown(Keys code, bool delay)
        {
            if ((code & Keys.Alt) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.Menu, false);
            }
            if ((code & Keys.Control) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.LControlKey, false);
            }
            if ((code & Keys.Shift) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.LShiftKey, false);
            }
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                this.PressOrReleaseKey(code, false);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
            }
        }

        public void KeyPress(Keys code)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                this.KeyDown(code);
                this.KeyUp(code);
            }
        }

        public void KeyPress(Keys code, int holdFor)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                this.KeyDown(code, false);
                Thread.Sleep(holdFor);
                this.KeyUp(code, false);
            }
        }

        public void KeyPress(Keys code, int holdFor, int repeatCount)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                for (int i = 0; i < repeatCount; i++)
                {
                    this.KeyPress(code, holdFor);
                }
            }
        }

        public static Keys KeysFromString(string keyCombination)
        {
            KeysConverter converter = new KeysConverter();
            if (converter.IsValid(keyCombination))
            {
                return (Keys) converter.ConvertFromString(keyCombination);
            }
            return Keys.None;
        }

        public void KeyUp(Keys key)
        {
            this.KeyUp(key, true);
        }

        private void KeyUp(Keys code, bool delay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                this.PressOrReleaseKey(code, true);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
            }
            if ((code & Keys.Alt) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.Menu, true);
            }
            if ((code & Keys.Control) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.LControlKey, true);
            }
            if ((code & Keys.Shift) != Keys.None)
            {
                this.PressOrReleaseKey(Keys.LShiftKey, true);
            }
        }

        private void PressOrReleaseKey(Keys key, bool release = false)
        {
            uint num;
            if (((key & Keys.Shift) != Keys.None) || ((key & Keys.ShiftKey) != Keys.None))
            {
                key ^= Keys.Shift;
            }
            if ((key & Keys.Control) != Keys.None)
            {
                key ^= Keys.Control;
            }
            if ((key & Keys.Alt) != Keys.None)
            {
                key ^= Keys.Alt;
            }
            if (!release)
            {
                if (key == Keys.LControlKey)
                {
                    num = 0;
                }
                else if (key == Keys.LMenu)
                {
                    num = 8;
                }
                else
                {
                    num = 1;
                }
            }
            else if ((key == Keys.LControlKey) || (key == Keys.LMenu))
            {
                num = 2;
            }
            else
            {
                num = 3;
            }
            Win32NativeMethods.keybd_event((byte) key, 0, num, IntPtr.Zero);
        }

        [Obsolete]
        internal void SendPreservedString(string strText)
        {
            StringBuilder builder = new StringBuilder();
            foreach (char ch in strText)
            {
                if ("()[]{}+^%~".IndexOf(ch) != -1)
                {
                    builder.Append("{" + ch + "}");
                }
                else if (ch == '\t')
                {
                    builder.Append("{TAB}");
                }
                else if (ch == '\n')
                {
                    builder.Append("{ENTER}");
                }
                else
                {
                    builder.Append(ch);
                }
            }
            this.SendString(builder.ToString());
        }

        [Obsolete("SendString has reliability issues. Please use TypeText instead, or KeyPress for special keys.")]
        public void SendString(string strText)
        {
            SendKeys.SendWait(strText);
            SendKeys.Flush();
            this._browser.AutoRefreshDomIfNeeded();
        }

        public void TypeText(string text, int delayBetweenKeypresses = 10)
        {
            this.TypeText(text, delayBetweenKeypresses, KeyDownDelay);
        }

        public void TypeText(string text, int delayBetweenKeypresses, int keyHoldTime)
        {
            this.TypeText(text, delayBetweenKeypresses, keyHoldTime, true);
        }

        public void TypeText(string text, int delayBetweenKeypresses, int keyHoldTime, bool supportUnicode)
        {
            if (supportUnicode)
            {
                this.TypeTextUnicodeInt(text, delayBetweenKeypresses, keyHoldTime);
            }
            else
            {
                this.TypeTextNU(text, delayBetweenKeypresses, keyHoldTime);
            }
        }

        private void TypeTextNU(string text, int delayBetweenKeypresses, int keyHoldTime)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                foreach (char ch in text)
                {
                    short num = Win32NativeMethods.VkKeyScan(ch);
                    Keys code = (Keys) num;
                    if ((num & 0x100) != 0)
                    {
                        code |= Keys.Shift;
                    }
                    if ((num & 0x200) != 0)
                    {
                        code |= Keys.Control;
                    }
                    Thread.Sleep(delayBetweenKeypresses);
                    this.KeyPress(code, keyHoldTime);
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        private void TypeTextUnicodeInt(string text, int delayBetweenKeypresses, int keyHoldTime)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                foreach (char ch in text)
                {
                    short code = (short) char.ConvertToUtf32(ch.ToString(), 0);
                    Thread.Sleep(delayBetweenKeypresses);
                    this.UnicodeKeyPress(code, keyHoldTime);
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        private void UnicodeKeyDown(short code, bool delay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                Win32NativeMethods.INPUT[] inputData = new Win32NativeMethods.INPUT[1];
                InitializeUnicodeKeyBoardEvent(ref inputData[0], code, true);
                Win32NativeMethods.SendInputInternal(inputData);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        private void UnicodeKeyPress(short code, int holdFor)
        {
            this.UnicodeKeyDown(code, false);
            Thread.Sleep(holdFor);
            this.UnicodeKeyUp(code, false);
        }

        private void UnicodeKeyUp(short code, bool delay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                Win32NativeMethods.INPUT[] inputData = new Win32NativeMethods.INPUT[1];
                InitializeUnicodeKeyBoardEvent(ref inputData[0], code, false);
                Win32NativeMethods.SendInputInternal(inputData);
                if (delay)
                {
                    this.DoKeyPressDelay();
                }
                this._browser.AutoRefreshDomIfNeeded();
            }
        }

        public static int KeyDownDelay
        {
            get
            {
                return s_keyDownDelay;
            }
            set
            {
                s_keyDownDelay = value;
            }
        }
    }
}

