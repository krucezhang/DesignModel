﻿namespace Selenium.Test.Toolkit.Desktop
{
    using System;

    public enum MouseWheelTurnDirection
    {
        Backward,
        Forward
    }
}

