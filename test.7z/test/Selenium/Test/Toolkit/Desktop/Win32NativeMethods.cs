﻿namespace Selenium.Test.Toolkit.Desktop
{
    using System;
    using System.ComponentModel;
    using System.Runtime.InteropServices;

    internal static class Win32NativeMethods
    {
        public const int PM_NOREMOVE = 0;
        public const int PM_REMOVE = 1;

        [DllImport("user32.dll")]
        public static extern bool GetCursorInfo(out CURSORINFO pci);
        [DllImport("user32.dll", SetLastError=true)]
        public static extern IntPtr GetDlgItem(IntPtr hWnd, int nIDDlgItem);
        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();
        public static int GetLastWin32Error()
        {
            return Marshal.GetLastWin32Error();
        }

        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, IntPtr dwExtraInfo);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("User32.dll", CharSet=CharSet.Auto, SetLastError=true)]
        public static extern bool PeekMessage(ref MSG lpMsg, IntPtr hwnd, int wMsgFilterMin, int wMsgFilterMax, int wRemoveMsg);
        [DllImport("User32.dll", SetLastError=true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, uint cbSize);
        public static void SendInputInternal(INPUT[] inputData)
        {
            if (SendInput((uint) inputData.Length, inputData, (uint) Marshal.SizeOf(typeof(INPUT))) != inputData.Length)
            {
                throw new Win32Exception("SendInput: Failed. Win32Error: " + Win32Error.LastErrorString);
            }
        }

        [DllImport("user32.dll", SetLastError=true)]
        public static extern bool SetDlgItemText(IntPtr hDlg, int nIDDlgItem, string lpString);
        [DllImport("User32.dll")]
        public static extern short VkKeyScan(char ch);
        [DllImport("user32.dll")]
        public static extern short VkKeyScanEx(char ch, IntPtr dwhkl);

        [StructLayout(LayoutKind.Sequential)]
        internal struct CURSORINFO
        {
            public int cbSize;
            public int flags;
            public IntPtr hCursor;
            public Win32NativeMethods.POINT ptScreenPos;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT
        {
            public uint uMsg;
            public short wParamL;
            public short wParamH;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public Win32NativeMethods.INPUTUNION union;
        }

        internal enum INPUTTYPE
        {
            MOUSE,
            KEYBOARD,
            HARDWARE
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct INPUTUNION
        {
            [FieldOffset(0)]
            public Win32NativeMethods.HARDWAREINPUT hardwareInput;
            [FieldOffset(0)]
            public Win32NativeMethods.KEYBDINPUT keyboardInput;
            [FieldOffset(0)]
            public Win32NativeMethods.MOUSEINPUT mouseInput;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public short wVk;
            public short wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [Flags]
        internal enum KEYEVENTF
        {
            EXTENDEDKEY = 1,
            KEYUP = 2,
            SCANCODE = 8,
            UNICODE = 4
        }

        [Flags]
        internal enum MOUSEEVENTF
        {
            ABSOLUTE = 0x8000,
            HORIZONTALWHEEL = 0x1000,
            LEFTDOWN = 2,
            LEFTUP = 4,
            MIDDLEDOWN = 0x20,
            MIDDLEUP = 0x40,
            MOVE = 1,
            RIGHTDOWN = 8,
            RIGHTUP = 0x10,
            VERTICALWHEEL = 0x800,
            VIRTUALDESK = 0x4000,
            XDOWN = 0x80,
            XUP = 0x100
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public int mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MSG
        {
            public IntPtr hwnd;
            public int message;
            public IntPtr wParam;
            public IntPtr lParam;
            public int time;
            public int pt_x;
            public int pt_y;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct POINT
        {
            public int x;
            public int y;
        }
    }
}

