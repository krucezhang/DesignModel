﻿namespace Selenium.Test.Toolkit.Desktop
{
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Windows.Forms;

    public class Mouse : IDisposable
    {
        private Browser _browser;
        private int _mouseMoveIntervalTime = 15;
        private const int CLICK_DELAY = 50;
        internal static bool FreezeMode;
        internal static int FreezeModeClientX;
        internal static int FreezeModeClientY;
        private static int Global_ExecutionDelay = 500;
        private static float Global_SimulatedMouseMoveSpeed = 0.5f;
        private const int WHEEL_DELTA = 120;

        internal Mouse(Browser browser)
        {
            this._browser = browser;
        }

        private static Point AdjustXYToScreen(int x, int y)
        {
            Rectangle bounds = Screen.PrimaryScreen.Bounds;
            return new Point(((0xffff * x) / bounds.Width) + 1, ((0xffff * y) / bounds.Height) + 1);
        }

        private List<Point> BuildPointList(Rectangle area, int range)
        {
            List<Point> list = new List<Point>();
            Point item = CalculateOffset(area, new Point(0, 0), OffsetReference.AbsoluteCenter);
            list.Add(item);
            new Point(item.X + range, item.Y + range);
            for (float i = 0f; i < 31.400000000000002; i += 0.1f)
            {
                double num2 = i * Math.Cos((double) i);
                double num3 = i * Math.Sin((double) i);
                PointF tf = new PointF(item.X + ((float) num2), item.Y + ((float) num3));
                Point point2 = Point.Round(tf);
                list.Add(point2);
                if (this.GetDistance(item, point2) > range)
                {
                    return list;
                }
            }
            return list;
        }

        public static Point CalculateOffset(Rectangle rectangle, Point offset, OffsetReference reference)
        {
            Point point = new Point();
            switch (reference)
            {
                case OffsetReference.TopLeftCorner:
                    point = new Point(rectangle.X, rectangle.Y);
                    break;

                case OffsetReference.BottomLeftCorner:
                    point = new Point(rectangle.X, rectangle.Bottom);
                    break;

                case OffsetReference.TopRightCorner:
                    point = new Point(rectangle.Right, rectangle.Y);
                    break;

                case OffsetReference.BottomRightCorner:
                    point = new Point(rectangle.Right, rectangle.Bottom);
                    break;

                case OffsetReference.TopCenter:
                    point = new Point(rectangle.X + (rectangle.Width / 2), rectangle.Top);
                    break;

                case OffsetReference.RightCenter:
                    point = new Point(rectangle.Right, rectangle.Top + (rectangle.Height / 2));
                    break;

                case OffsetReference.LeftCenter:
                    point = new Point(rectangle.X, rectangle.Top + (rectangle.Height / 2));
                    break;

                case OffsetReference.BottomCenter:
                    point = new Point(rectangle.X + (rectangle.Width / 2), rectangle.Bottom);
                    break;

                case OffsetReference.AbsoluteCenter:
                    point = new Point(rectangle.X + (rectangle.Width / 2), rectangle.Y + (rectangle.Height / 2));
                    break;
            }
            point.Offset(offset);
            return point;
        }

        public void Click(MouseClickType clickType, Point pointToClick)
        {
            this.Click(clickType, pointToClick.X, pointToClick.Y);
        }

        public void Click(MouseClickType clickType, Rectangle target)
        {
            this.Click(clickType, target, new Point(0, 0), OffsetReference.AbsoluteCenter);
        }

        public void Click(MouseClickType clickType, int x, int y)
        {
            this.Click(clickType, x, y, 0);
        }

        public void Click(MouseClickType clickType, Rectangle target, Point offset, OffsetReference reference)
        {
            Point pointToClick = CalculateOffset(target, offset, reference);
            this.Click(clickType, pointToClick);
        }

        private void Click(MouseClickType clickType, int x, int y, int wheelDelta)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                if (SystemInformation.MouseButtonsSwapped)
                {
                    switch (clickType)
                    {
                        case MouseClickType.LeftClick:
                            clickType = MouseClickType.RightClick;
                            break;

                        case MouseClickType.RightClick:
                            clickType = MouseClickType.LeftClick;
                            break;
                    }
                }
                Win32NativeMethods.INPUT[] inputData = null;
                Point point = AdjustXYToScreen(x, y);
                int num = point.X;
                int num2 = point.Y;
                int num3 = Global_ExecutionDelay;
                bool flag = false;
                switch (clickType)
                {
                    case MouseClickType.LeftClick:
                        Global_ExecutionDelay = 0;
                        this.Click(MouseClickType.LeftDown, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.LeftUp, x, y, wheelDelta);
                        Global_ExecutionDelay = num3;
                        flag = true;
                        break;

                    case MouseClickType.RightClick:
                        Global_ExecutionDelay = 0;
                        this.Click(MouseClickType.RightDown, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.RightUp, x, y, wheelDelta);
                        Global_ExecutionDelay = num3;
                        flag = true;
                        break;

                    case MouseClickType.MiddleClick:
                        Global_ExecutionDelay = 0;
                        this.Click(MouseClickType.MiddleDown, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.MiddleUp, x, y, wheelDelta);
                        Global_ExecutionDelay = num3;
                        flag = true;
                        break;

                    case MouseClickType.LeftDoubleClick:
                        Global_ExecutionDelay = 0;
                        this.Click(MouseClickType.LeftDown, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.LeftUp, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.LeftDown, x, y, wheelDelta);
                        Thread.Sleep(50);
                        this.Click(MouseClickType.LeftUp, x, y, wheelDelta);
                        Global_ExecutionDelay = num3;
                        flag = true;
                        break;

                    case MouseClickType.LeftDown:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.LEFTDOWN, true);
                        break;

                    case MouseClickType.LeftUp:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.LEFTUP, true);
                        break;

                    case MouseClickType.RightDown:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.RIGHTDOWN, true);
                        break;

                    case MouseClickType.RightUp:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.RIGHTUP, true);
                        break;

                    case MouseClickType.MiddleDown:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.MIDDLEDOWN, true);
                        break;

                    case MouseClickType.MiddleUp:
                        inputData = new Win32NativeMethods.INPUT[1];
                        InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.MIDDLEUP, true);
                        break;

                    case MouseClickType.Wheel:
                        if (Math.Abs(wheelDelta) > 120)
                        {
                            Global_ExecutionDelay = 0;
                            for (int i = 0; i < (Math.Abs(wheelDelta) / 120); i++)
                            {
                                this.Click(MouseClickType.Wheel, x, y, (wheelDelta > 0) ? 120 : -120);
                                Thread.Sleep(50);
                            }
                            if ((Math.Abs(wheelDelta) % 120) > 0)
                            {
                                this.Click(MouseClickType.Wheel, x, y, (wheelDelta > 0) ? 120 : -120);
                            }
                            Global_ExecutionDelay = num3;
                            flag = true;
                            break;
                        }
                        inputData = new Win32NativeMethods.INPUT[1];
                        inputData[0].union.mouseInput.mouseData = wheelDelta;
                        inputData[0].union.mouseInput.dwFlags = 0x800;
                        inputData[0].union.mouseInput.dx = 0;
                        inputData[0].union.mouseInput.dy = 0;
                        inputData[0].type = 0;
                        break;
                }
                if (Global_ExecutionDelay > 0)
                {
                    Thread.Sleep(Global_ExecutionDelay);
                }
                if (!flag)
                {
                    Win32NativeMethods.SendInputInternal(inputData);
                    this._browser.AutoRefreshDomIfNeeded();
                }
            }
        }

        public Point DetectHotSpot(Rectangle rectangle, Cursor hotSpotCursor, int radius)
        {
            if (!this._browser.EnsureBrowserOnFocusIfPossible())
            {
                return Point.Empty;
            }
            IntPtr handle = Cursors.Default.Handle;
            int num = Global_ExecutionDelay;
            Global_ExecutionDelay = 0;
            Point empty = Point.Empty;
            foreach (Point point2 in this.BuildPointList(rectangle, radius))
            {
                this.HoverOver(point2);
                Thread.Sleep(5);
                if (hotSpotCursor == null)
                {
                    if (this.MatchCursor(handle))
                    {
                        continue;
                    }
                    empty = point2;
                    break;
                }
                if (this.MatchCursor(hotSpotCursor.Handle))
                {
                    empty = point2;
                    break;
                }
            }
            Global_ExecutionDelay = num;
            if (empty == Point.Empty)
            {
                throw new Exception("Unable to determine a hot spot within the supplied rectangle!");
            }
            return empty;
        }

        public void Dispose()
        {
            this._browser = null;
        }

        public void DragDrop(Point start, Point end)
        {
            this.DragDrop(start, end, this.GetRelativeNumOfMouseMoveIntervals(start, end), this._mouseMoveIntervalTime);
        }

        public void DragDrop(Rectangle start, Rectangle end)
        {
            this.DragDrop(start, end, this.GetRelativeNumOfMouseMoveIntervals(start, end), this._mouseMoveIntervalTime);
        }

        public void DragDrop(Point start, Point end, int intervals, int intervalDelay)
        {
            this.DragDrop(start.X, start.Y, end.X, end.Y, intervals, intervalDelay);
        }

        public void DragDrop(Rectangle startTarget, Rectangle endTarget, int intervals, int intervalDelay)
        {
            Point start = CalculateOffset(startTarget, new Point(0, 0), OffsetReference.AbsoluteCenter);
            Point end = CalculateOffset(endTarget, new Point(0, 0), OffsetReference.AbsoluteCenter);
            this.DragDrop(start, end, intervals, intervalDelay);
        }

        public void DragDrop(int startX, int startY, int endX, int endY)
        {
            this.DragDrop(startX, startY, endX, endY, this.GetRelativeNumOfMouseMoveIntervals(new Point(startX, startY), new Point(endX, endY)), this._mouseMoveIntervalTime);
        }

        public void DragDrop(Rectangle startTarget, Point startOffset, OffsetReference startReference, Rectangle endTarget, Point endOffset, OffsetReference endReference)
        {
            this.DragDrop(startTarget, startOffset, startReference, endTarget, endOffset, endReference, this.GetRelativeNumOfMouseMoveIntervals(startTarget, startOffset, startReference, endTarget, endOffset, endReference), this._mouseMoveIntervalTime);
        }

        public void DragDrop(int startX, int startY, int endX, int endY, int intervals, int intervalDelay)
        {
            Point pointToHoverOver = new Point(startX, startY);
            Point end = new Point(endX, endY);
            this.HoverOver(pointToHoverOver);
            Thread.Sleep(50);
            this.Click(MouseClickType.LeftDown, pointToHoverOver);
            Thread.Sleep(50);
            this.Move(pointToHoverOver, end, intervals, intervalDelay);
            Thread.Sleep(50);
            this.Click(MouseClickType.LeftUp, end);
        }

        public void DragDrop(Rectangle startTarget, Point startOffset, OffsetReference startReference, Rectangle endTarget, Point endOffset, OffsetReference endReference, int intervals, int intervalDelay)
        {
            Point start = CalculateOffset(startTarget, startOffset, startReference);
            Point end = CalculateOffset(endTarget, endOffset, endReference);
            this.DragDrop(start, end, intervals, intervalDelay);
        }

        public void DragDrop(Rectangle startTarget, int startOffsetX, int startOffsetY, OffsetReference startReference, Rectangle endTarget, int endOffsetX, int endOffsetY, OffsetReference endReference)
        {
            this.DragDrop(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference, this.GetRelativeNumOfMouseMoveIntervals(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference), this._mouseMoveIntervalTime);
        }

        public void DragDrop(Rectangle startTarget, int startOffsetX, int startOffsetY, OffsetReference startReference, Rectangle endTarget, int endOffsetX, int endOffsetY, OffsetReference endReference, int intervals, int intervalDelay)
        {
            this.DragDrop(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference, intervals, intervalDelay);
        }

        public IntPtr GetCursorHandle()
        {
            Win32NativeMethods.CURSORINFO cursorinfo;
            cursorinfo.cbSize = Marshal.SizeOf(typeof(Win32NativeMethods.CURSORINFO));
            Win32NativeMethods.GetCursorInfo(out cursorinfo);
            return cursorinfo.hCursor;
        }

        protected float GetDistance(Point start, Point end)
        {
            ValidateNonNegativePoint(ref start);
            ValidateNonNegativePoint(ref end);
            int num = Math.Abs((int) (start.X - end.X));
            int num2 = Math.Abs((int) (start.Y - end.Y));
            return (float) Math.Sqrt(Math.Pow((double) num, 2.0) + Math.Pow((double) num2, 2.0));
        }

        protected int GetRelativeNumOfMouseMoveIntervals(int distanceInPixels)
        {
            float num = ((float) distanceInPixels) / (Global_SimulatedMouseMoveSpeed * this._mouseMoveIntervalTime);
            return (int) Math.Ceiling((double) num);
        }

        protected int GetRelativeNumOfMouseMoveIntervals(Point start, Point end)
        {
            float distance = this.GetDistance(start, end);
            return this.GetRelativeNumOfMouseMoveIntervals((int) distance);
        }

        protected int GetRelativeNumOfMouseMoveIntervals(Rectangle start, Rectangle end)
        {
            Point point = CalculateOffset(start, new Point(0, 0), OffsetReference.AbsoluteCenter);
            Point point2 = CalculateOffset(end, new Point(0, 0), OffsetReference.AbsoluteCenter);
            return this.GetRelativeNumOfMouseMoveIntervals(point, point2);
        }

        protected int GetRelativeNumOfMouseMoveIntervals(Rectangle startTarget, Point startOffset, OffsetReference startReference, Rectangle endTarget, Point endOffset, OffsetReference endReference)
        {
            Point start = CalculateOffset(startTarget, startOffset, startReference);
            Point end = CalculateOffset(endTarget, endOffset, endReference);
            return this.GetRelativeNumOfMouseMoveIntervals(start, end);
        }

        public void HoverOver(Point pointToHoverOver)
        {
            this.HoverOver(pointToHoverOver.X, pointToHoverOver.Y);
        }

        public void HoverOver(Rectangle target)
        {
            this.HoverOver(target, new Point(0, 0), OffsetReference.AbsoluteCenter);
        }

        public void HoverOver(int x, int y)
        {
            this.HoverOver(x, y, true);
        }

        public void HoverOver(Rectangle target, Point offset, OffsetReference reference)
        {
            Point pointToHoverOver = CalculateOffset(target, offset, reference);
            this.HoverOver(pointToHoverOver);
        }

        internal void HoverOver(int x, int y, bool useExecutionDelay)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                Win32NativeMethods.INPUT[] inputData = new Win32NativeMethods.INPUT[1];
                Point point = AdjustXYToScreen(x, y);
                int num = point.X;
                int num2 = point.Y;
                InitializeMouseEvent(ref inputData[0], num, num2, Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.MOVE, false);
                if (useExecutionDelay && (Global_ExecutionDelay > 0))
                {
                    Thread.Sleep(Global_ExecutionDelay);
                }
                Win32NativeMethods.SendInputInternal(inputData);
            }
        }

        private static void InitializeMouseEvent(ref Win32NativeMethods.INPUT inputEvent, int x, int y, Win32NativeMethods.MOUSEEVENTF flag, bool absoluteMove)
        {
            inputEvent.type = 0;
            inputEvent.union.mouseInput.dx = x;
            inputEvent.union.mouseInput.dy = y;
            if (absoluteMove)
            {
                inputEvent.union.mouseInput.dwFlags = (uint) ((Win32NativeMethods.MOUSEEVENTF.ABSOLUTE | Win32NativeMethods.MOUSEEVENTF.MOVE) | flag);
            }
            else
            {
                inputEvent.union.mouseInput.dwFlags = (uint) flag;
            }
        }

        public bool MatchCursor(IntPtr handle)
        {
            if (!(handle == IntPtr.Zero))
            {
                return (this.GetCursorHandle() == handle);
            }
            return true;
        }

        public void Move(Point start, Point end)
        {
            this.Move(start, end, this.GetRelativeNumOfMouseMoveIntervals(start, end), this._mouseMoveIntervalTime);
        }

        public void Move(Rectangle start, Rectangle end)
        {
            this.Move(start, end, this.GetRelativeNumOfMouseMoveIntervals(start, end), this._mouseMoveIntervalTime);
        }

        public void Move(Point start, Point end, int intervals, int intervalDelay)
        {
            ValidateNonNegativePoint(ref start);
            ValidateNonNegativePoint(ref end);
            int num = Math.Abs((int) (end.X - start.X));
            int num2 = Math.Abs((int) (end.Y - start.Y));
            int num3 = Math.Max(num, num2);
            if (num3 == 0)
            {
                num3 = 1;
            }
            int num4 = intervals * intervalDelay;
            int millisecondsTimeout = num4 / num3;
            float num6 = num3;
            float num7 = ((float) (end.X - start.X)) / num6;
            float num8 = ((float) (end.Y - start.Y)) / num6;
            PointF tf = new PointF((float) start.X, (float) start.Y);
            for (int i = 0; i <= num3; i++)
            {
                this.HoverOver((int) tf.X, (int) tf.Y, false);
                Thread.Sleep(millisecondsTimeout);
                tf.X += num7;
                tf.Y += num8;
            }
            this.HoverOver(end);
        }

        public void Move(Rectangle start, Rectangle end, int intervals, int intervalDelay)
        {
            this.Move(CalculateOffset(start, new Point(0, 0), OffsetReference.AbsoluteCenter), CalculateOffset(end, new Point(0, 0), OffsetReference.AbsoluteCenter), intervals, intervalDelay);
        }

        public void Move(int startX, int startY, int endX, int endY)
        {
            this.Move(startX, startY, endX, endY, this.GetRelativeNumOfMouseMoveIntervals(new Point(startX, startY), new Point(endX, endY)), this._mouseMoveIntervalTime);
        }

        public void Move(Rectangle startTarget, Point startOffset, OffsetReference startReference, Rectangle endTarget, Point endOffset, OffsetReference endReference)
        {
            this.Move(startTarget, startOffset, startReference, endTarget, endOffset, endReference, this.GetRelativeNumOfMouseMoveIntervals(startTarget, startOffset, startReference, endTarget, endOffset, endReference), this._mouseMoveIntervalTime);
        }

        public void Move(int startX, int startY, int endX, int endY, int intervals, int intervalDelay)
        {
            this.Move(new Point(startX, startY), new Point(endX, endY), intervals, intervalDelay);
        }

        public void Move(Rectangle startTarget, Point startOffset, OffsetReference startReference, Rectangle endTarget, Point endOffset, OffsetReference endReference, int intervals, int intervalDelay)
        {
            Point start = CalculateOffset(startTarget, startOffset, startReference);
            Point end = CalculateOffset(endTarget, endOffset, endReference);
            this.Move(start, end, intervals, intervalDelay);
        }

        public void Move(Rectangle startTarget, int startOffsetX, int startOffsetY, OffsetReference startReference, Rectangle endTarget, int endOffsetX, int endOffsetY, OffsetReference endReference)
        {
            this.Move(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference, this.GetRelativeNumOfMouseMoveIntervals(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference), this._mouseMoveIntervalTime);
        }

        public void Move(Rectangle startTarget, int startOffsetX, int startOffsetY, OffsetReference startReference, Rectangle endTarget, int endOffsetX, int endOffsetY, OffsetReference endReference, int intervals, int intervalDelay)
        {
            this.Move(startTarget, new Point(startOffsetX, startOffsetY), startReference, endTarget, new Point(endOffsetX, endOffsetY), endReference, intervals, intervalDelay);
        }

        public void TurnWheel(int delta, MouseWheelTurnDirection direction)
        {
            if (this._browser.EnsureBrowserOnFocusIfPossible())
            {
                int wheelDelta = Math.Abs(delta);
                wheelDelta = (direction == MouseWheelTurnDirection.Backward) ? (wheelDelta * -1) : wheelDelta;
                this.Click(MouseClickType.Wheel, 0, 0, wheelDelta);
            }
        }

        public static void ValidateNonNegativePoint(ref Point point)
        {
            if (point.X < 0)
            {
                point.X = 0;
            }
            if (point.Y < 0)
            {
                point.Y = 0;
            }
        }

        public int MouseMoveIntervalTime
        {
            get
            {
                return this._mouseMoveIntervalTime;
            }
            set
            {
                this._mouseMoveIntervalTime = value;
            }
        }
    }
}

