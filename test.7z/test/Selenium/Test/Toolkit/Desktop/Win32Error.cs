﻿namespace Selenium.Test.Toolkit.Desktop
{
    using System;
    using System.ComponentModel;
    using System.Runtime.InteropServices;

    public static class Win32Error
    {
        private static string _lastErrorString = string.Empty;

        public static void SetLastWin32Error()
        {
            int error = Marshal.GetLastWin32Error();
            if (error != 0)
            {
                string str = new Win32Exception(error).ToString();
                _lastErrorString = string.Format("Win32 Error Code '{0}' : {1}", error, str);
            }
            else
            {
                _lastErrorString = string.Empty;
            }
        }

        public static string LastErrorString
        {
            get
            {
                return _lastErrorString;
            }
            set
            {
                _lastErrorString = value;
            }
        }
    }
}

