﻿namespace Selenium.Test.Toolkit.Desktop
{
    using System;

    public enum MouseClickType
    {
        LeftClick,
        RightClick,
        MiddleClick,
        LeftDoubleClick,
        LeftDown,
        LeftUp,
        RightDown,
        RightUp,
        MiddleDown,
        MiddleUp,
        Wheel
    }
}

