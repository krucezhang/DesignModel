﻿namespace Selenium.Test.Toolkit
{
    using System;

    public sealed class EnumStringAttribute : Attribute
    {
    }
}

