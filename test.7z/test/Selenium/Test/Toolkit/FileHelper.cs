﻿namespace Selenium.Test.Toolkit
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;

    public static class FileHelper
    {
        private static string _assemblyName;
        private static string _currentAssemblyPath;

        public static string GetAssemblyPath(Assembly assembly)
        {
            string directoryName = Path.GetDirectoryName(assembly.Location);
            if (AppDomain.CurrentDomain.ShadowCopyFiles)
            {
                Uri uri = new Uri(assembly.CodeBase);
                directoryName = Path.GetDirectoryName(uri.LocalPath);
            }
            return directoryName;
        }

        public static string GetBase64StringFromImage(string imageFile)
        {
            string str = string.Empty;
            using (Image image = Image.FromFile(imageFile))
            {
                using (MemoryStream stream = new MemoryStream())
                {
                    image.Save(stream, image.RawFormat);
                    str = Convert.ToBase64String(stream.ToArray());
                }
            }
            return str;
        }

        internal static string GetJSFromResourcesFile(string fileName)
        {
            return GetJSFromResourcesFile(Assembly.GetExecutingAssembly(), ".Resource.JS." + fileName, false);
        }

        public static string GetJSFromResourcesFile(Assembly assembly, string filePath, bool isContainsNamespace = false)
        {
            Func<string, bool> predicate = null;
            string str = string.Empty;
            string name = assembly.GetName().Name;
            string str3 = name + filePath;
            if (isContainsNamespace)
            {
                str3 = filePath;
            }
            using (Stream stream = assembly.GetManifestResourceStream(str3))
            {
                if (stream == null)
                {
                    if (predicate == null)
                    {
                        predicate = p => p.EndsWith(filePath);
                    }
                    str3 = assembly.GetManifestResourceNames().Single<string>(predicate);
                    if (string.IsNullOrEmpty(str3))
                    {
                        throw new InvalidCastException(string.Format("Can't get expected resource[EndWisth:{0}] in assembly[{1}].", filePath, name));
                    }
                    return GetJSFromResourcesFile(assembly, str3, true);
                }
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    str = reader.ReadToEnd();
                }
            }
            return str.Replace("\r\n", "").Replace("\n", "");
        }

        internal static Stream GetStreamFromResource(string FileName)
        {
            return Assembly.GetExecutingAssembly().GetManifestResourceStream(AssemblyName + ".Resource." + FileName);
        }

        internal static string AssemblyName
        {
            get
            {
                if (string.IsNullOrEmpty(_assemblyName))
                {
                    _assemblyName = Assembly.GetExecutingAssembly().GetName().Name;
                }
                return _assemblyName;
            }
        }

        internal static string CurrentAssemblyPath
        {
            get
            {
                if (string.IsNullOrEmpty(_currentAssemblyPath))
                {
                    _currentAssemblyPath = GetAssemblyPath(Assembly.GetExecutingAssembly());
                }
                return _currentAssemblyPath;
            }
        }
    }
}

