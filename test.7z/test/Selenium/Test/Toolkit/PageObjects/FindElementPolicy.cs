﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;

    public enum FindElementPolicy
    {
        Normal,
        UseSequence,
        UseAll
    }
}

