﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;
    using System.Reflection;
    using System.Runtime.Remoting.Messaging;
    using System.Runtime.Remoting.Proxies;

    internal abstract class WebObjectProxy : RealProxy
    {
        private readonly FindByContext _byContext;
        private readonly bool _cache;
        private readonly IElementGUILocator _locator;

        protected WebObjectProxy(Type classToProxy, IElementGUILocator locator, FindByContext byContext, bool cache) : base(classToProxy)
        {
            this._locator = locator;
            this._byContext = byContext;
            this._cache = cache;
        }

        protected static ReturnMessage InvokeMethod(IMethodCallMessage msg, object representedValue)
        {
            if (msg == null)
            {
                throw new ArgumentNullException("msg", "The message containing invocation information cannot be null");
            }
            MethodInfo methodBase = msg.MethodBase as MethodInfo;
            return new ReturnMessage(methodBase.Invoke(representedValue, msg.Args), null, 0, msg.LogicalCallContext, msg);
        }

        protected FindByContext ByContext
        {
            get
            {
                return this._byContext;
            }
        }

        protected bool Cache
        {
            get
            {
                return this._cache;
            }
        }

        protected IElementGUILocator Locator
        {
            get
            {
                return this._locator;
            }
        }
    }
}

