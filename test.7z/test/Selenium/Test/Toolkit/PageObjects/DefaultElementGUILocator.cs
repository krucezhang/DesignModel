﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.CompilerServices;

    public class DefaultElementGUILocator : IElementGUILocator, IDisposable
    {
        public DefaultElementGUILocator(IFindElementGUI findContext)
        {
            this.FindElementContext = findContext;
            this.PageTypeName = null;
            if (this.FindElementContext is PageGUI)
            {
                this.PageTypeName = this.FindElementContext.GetType().FullName;
            }
        }

        private bool ApplyComponentFinders(IElementGUI elementGUI, FindByContext byContext)
        {
            bool flag = false;
            if (byContext.ComponentFinders != null)
            {
                foreach (KeyValuePair<string, By> pair in byContext.ComponentFinders)
                {
                    flag = true;
                    if (elementGUI.Finders.ContainsKey(pair.Key))
                    {
                        elementGUI.Finders[pair.Key] = pair.Value;
                    }
                    else
                    {
                        elementGUI.Finders.Add(pair.Key, pair.Value);
                    }
                }
            }
            return flag;
        }

        public virtual void Dispose()
        {
            this.FindElementContext = null;
        }

        private T FindElement<T>(IFindElementGUI findElementContext, FindByAttribute attribute)
        {
            if (attribute.WaitFind)
            {
                if (attribute.OnlyFindDisplay)
                {
                    return findElementContext.WaitFindDisplayedElementGUI<T>(attribute.Finder, attribute.WaitTimeout);
                }
                return findElementContext.WaitFindElementGUI<T>(attribute.Finder, attribute.WaitTimeout);
            }
            if (attribute.OnlyFindDisplay)
            {
                return findElementContext.FindDisplayedElementGUI<T>(attribute.Finder, true);
            }
            return findElementContext.FindElementGUI<T>(attribute.Finder);
        }

        private IList<T> FindElements<T>(IFindElementGUI findElementContext, FindByAttribute attribute)
        {
            if (attribute.OnlyFindDisplay)
            {
                return findElementContext.FindDisplayedElementGUIs<T>(attribute.Finder);
            }
            return findElementContext.FindElementGUIs<T>(attribute.Finder);
        }

        public T LocateElement<T>(FindByContext byContext)
        {
            if (byContext == null)
            {
                throw new ArgumentNullException("byContext", "List of criteria may not be null");
            }
            if ((this.PageTypeName != null) && byContext.AutoAdjustPageLoaded)
            {
                PageGUI.AutoAdjustPageLoaded(this.FindElementContext, this.PageTypeName);
            }
            if ((byContext.FindPolicy == FindElementPolicy.UseSequence) || (byContext.FindPolicy == FindElementPolicy.UseAll))
            {
                IList<T> list = this.LocateElements<T>(byContext);
                if (list.Count == 0)
                {
                    throw new NoSuchElementException("Cannot locate an element using " + this.ToString());
                }
                T local = list[0];
                this.ApplyComponentFinders(local as IElementGUI, byContext);
                return local;
            }
            string str = null;
            foreach (FindByAttribute attribute in byContext.FindsByAttributes)
            {
                try
                {
                    T local2 = this.FindElement<T>(this.FindElementContext, attribute);
                    this.ApplyComponentFinders(local2 as IElementGUI, byContext);
                    return local2;
                }
                catch (NoSuchElementException)
                {
                    str = ((str == null) ? "Could not find element by: " : (str + ", or: ")) + attribute.Finder;
                }
            }
            throw new NoSuchElementException(str);
        }

        public IList<T> LocateElements<T>(FindByContext byContext)
        {
            if (byContext == null)
            {
                throw new ArgumentNullException("byContext", "List of criteria may not be null");
            }
            if ((this.PageTypeName != null) && byContext.AutoAdjustPageLoaded)
            {
                PageGUI.AutoAdjustPageLoaded(this.FindElementContext, this.PageTypeName);
            }
            List<T> list = new List<T>();
            if (byContext.FindsByAttributes.Count > 0)
            {
                if (byContext.FindPolicy == FindElementPolicy.UseSequence)
                {
                    List<DomElementGUI> list2 = null;
                    foreach (FindByAttribute attribute in byContext.FindsByAttributes)
                    {
                        List<DomElementGUI> list3 = new List<DomElementGUI>();
                        if (list2 == null)
                        {
                            list3.AddRange(this.FindElements<DomElementGUI>(this.FindElementContext, attribute));
                        }
                        else
                        {
                            foreach (DomElementGUI tgui in list2)
                            {
                                list3.AddRange(this.FindElements<DomElementGUI>(tgui, attribute));
                            }
                        }
                        list2 = list3;
                    }
                    bool flag = true;
                    foreach (DomElementGUI tgui2 in list2)
                    {
                        T item = tgui2.AsTo<T>();
                        if (flag)
                        {
                            flag = this.ApplyComponentFinders(item as IElementGUI, byContext);
                        }
                        list.Add(item);
                    }
                    return list;
                }
                if (byContext.FindPolicy == FindElementPolicy.UseAll)
                {
                    IList<DomElementGUI> first = null;
                    foreach (FindByAttribute attribute2 in byContext.FindsByAttributes)
                    {
                        IList<DomElementGUI> second = this.FindElements<DomElementGUI>(this.FindElementContext, attribute2);
                        if (second.Count == 0)
                        {
                            return list;
                        }
                        if (first == null)
                        {
                            first = second;
                        }
                        else
                        {
                            first = (IList<DomElementGUI>) first.Intersect<DomElementGUI>(second);
                        }
                    }
                    bool flag2 = true;
                    foreach (DomElementGUI tgui3 in first)
                    {
                        T local2 = tgui3.AsTo<T>();
                        if (flag2)
                        {
                            flag2 = this.ApplyComponentFinders(local2 as IElementGUI, byContext);
                        }
                        list.Add(local2);
                    }
                    return list;
                }
                foreach (FindByAttribute attribute3 in byContext.FindsByAttributes)
                {
                    IList<T> collection = this.FindElements<T>(this.FindElementContext, attribute3);
                    list.AddRange(collection);
                    foreach (T local3 in list)
                    {
                        if (!this.ApplyComponentFinders(local3 as IElementGUI, byContext))
                        {
                            break;
                        }
                    }
                }
            }
            return list;
        }

        public IFindElementGUI FindElementContext { get; private set; }

        private string PageTypeName { get; set; }
    }
}

