﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using OpenQA.Selenium;
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple=true)]
    public sealed class FindByAttribute : FindByBaseAttribute, IComparable
    {
        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("obj", "Object to compare cannot be null");
            }
            FindByAttribute attribute = obj as FindByAttribute;
            if (attribute == null)
            {
                throw new ArgumentException("Object to compare must be a FindsByAttribute", "obj");
            }
            if (base.Priority != attribute.Priority)
            {
                return (base.Priority - attribute.Priority);
            }
            return 0;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            FindByAttribute attribute = obj as FindByAttribute;
            if (attribute == null)
            {
                return false;
            }
            if (attribute.Priority != base.Priority)
            {
                return false;
            }
            if (attribute.Finder != base.Finder)
            {
                return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            By finder = base.Finder;
            if (finder == null)
            {
                return base.GetHashCode();
            }
            return finder.GetHashCode();
        }

        public static bool operator ==(FindByAttribute one, FindByAttribute two)
        {
            return (object.ReferenceEquals(one, two) || (((one != null) && (two != null)) && one.Equals(two)));
        }

        public static bool operator >(FindByAttribute one, FindByAttribute two)
        {
            if (one == null)
            {
                throw new ArgumentNullException("one", "Object to compare cannot be null");
            }
            return (one.CompareTo(two) > 0);
        }

        public static bool operator !=(FindByAttribute one, FindByAttribute two)
        {
            return !(one == two);
        }

        public static bool operator <(FindByAttribute one, FindByAttribute two)
        {
            if (one == null)
            {
                throw new ArgumentNullException("one", "Object to compare cannot be null");
            }
            return (one.CompareTo(two) < 0);
        }
    }
}

