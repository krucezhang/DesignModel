﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Collections.Generic;

    public interface IElementGUILocator : IDisposable
    {
        T LocateElement<T>(FindByContext byContext);
        IList<T> LocateElements<T>(FindByContext byContext);

        IFindElementGUI FindElementContext { get; }
    }
}

