﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;
    using System.Runtime.CompilerServices;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple=true)]
    public class FindPolicyAttribute : Attribute
    {
        public FindPolicyAttribute()
        {
            this.Policy = FindElementPolicy.Normal;
            this.Override = true;
        }

        public bool Override { get; set; }

        public FindElementPolicy Policy { get; set; }
    }
}

