﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;
    using System.Reflection;

    public interface IComponentObjectMemberDecorator
    {
        object Decorate(MemberInfo member, IElementGUILocator locator);
    }
}

