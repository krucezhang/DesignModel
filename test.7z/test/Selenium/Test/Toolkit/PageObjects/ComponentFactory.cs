﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public sealed class ComponentFactory
    {
        private ComponentFactory()
        {
        }

        public static void InitElements(IFindElementGUI findContext)
        {
            InitElements(findContext, new DefaultElementGUILocator(findContext));
        }

        public static void InitElements(IFindElementGUI findContext, IComponentObjectMemberDecorator decorator)
        {
            InitElements(findContext, new DefaultElementGUILocator(findContext), decorator);
        }

        public static void InitElements(IFindElementGUI findContext, IElementGUILocator locator)
        {
            InitElements(findContext, locator, new DefaultComponentObjectMemberDecorator());
        }

        public static void InitElements(IFindElementGUI page, IElementGUILocator locator, IComponentObjectMemberDecorator decorator)
        {
            if (page == null)
            {
                throw new ArgumentNullException("page", "page cannot be null");
            }
            if (locator == null)
            {
                throw new ArgumentNullException("locator", "locator cannot be null");
            }
            if (decorator == null)
            {
                throw new ArgumentNullException("locator", "decorator cannot be null");
            }
            if (locator.FindElementContext == null)
            {
                throw new ArgumentException("The FindElementContext of the locator object cannot be null", "locator");
            }
            Type baseType = page.GetType();
            List<MemberInfo> list = new List<MemberInfo>();
            list.AddRange(baseType.GetFields(BindingFlags.Public | BindingFlags.Instance));
            list.AddRange(baseType.GetProperties(BindingFlags.Public | BindingFlags.Instance));
            while (baseType != null)
            {
                list.AddRange(baseType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance));
                list.AddRange(baseType.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance));
                baseType = baseType.BaseType;
            }
            foreach (MemberInfo info in list)
            {
                object obj2 = decorator.Decorate(info, locator);
                if (obj2 != null)
                {
                    FieldInfo info2 = info as FieldInfo;
                    PropertyInfo info3 = info as PropertyInfo;
                    if (info2 != null)
                    {
                        info2.SetValue(page, obj2);
                    }
                    else if (info3 != null)
                    {
                        info3.SetValue(page, obj2, null);
                    }
                }
            }
        }
    }
}

