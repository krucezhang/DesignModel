﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public sealed class FindByContext
    {
        public FindByContext()
        {
            this.FindPolicy = FindElementPolicy.Normal;
            this.AutoAdjustPageLoaded = true;
            this.FinderOverride = true;
            this.FindsByAttributes = new List<FindByAttribute>();
        }

        public bool AutoAdjustPageLoaded { get; set; }

        public Dictionary<string, By> ComponentFinders { get; set; }

        public bool FinderOverride { get; set; }

        public FindElementPolicy FindPolicy { get; set; }

        public List<FindByAttribute> FindsByAttributes { get; set; }
    }
}

