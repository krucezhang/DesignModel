﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Reflection;
    using System.Runtime.Remoting.Messaging;

    internal sealed class WebElementGUIProxy<T> : WebObjectProxy where T: IElementGUI
    {
        private T cachedElement;

        private WebElementGUIProxy(Type classToProxy, IElementGUILocator locator, FindByContext byContext, bool cache) : base(classToProxy, locator, byContext, cache)
        {
        }

        public static object CreateProxy<ET>(Type classToProxy, IElementGUILocator locator, FindByContext byContext, bool cacheLookups) where ET: IElementGUI
        {
            return new WebElementGUIProxy<ET>(classToProxy, locator, byContext, cacheLookups).GetTransparentProxy();
        }

        public override IMessage Invoke(IMessage msg)
        {
            Func<bool> action = null;
            Func<bool> func2 = null;
            IMethodCallMessage mcm = msg as IMethodCallMessage;
            string methodName = mcm.MethodName;
            switch (methodName)
            {
                case "get_IsExistElement":
                    return new ReturnMessage(this.CheckExistElement != null, null, 0, mcm.LogicalCallContext, mcm);

                case "get_IsExistDisplayedElement":
                    return new ReturnMessage((this.CheckExistElement == null) ? ((object) 0) : ((object) this.CheckExistElement.Visible), null, 0, mcm.LogicalCallContext, mcm);

                case "WaitForElementVisible":
                {
                    int pageFindElementTimeout = PageGUI.PageFindElementTimeout;
                    if (mcm.ArgCount > 0)
                    {
                        pageFindElementTimeout = (int) mcm.Args[0];
                    }
                    if (action == null)
                    {
                        action = () => (base.CheckExistElement != null) && base.CheckExistElement.Visible;
                    }
                    TestUtility.WaitFunc(action, pageFindElementTimeout, true, "Wait element display is timeout[{0}s]");
                    return new ReturnMessage(this.CheckExistElement, null, 0, mcm.LogicalCallContext, mcm);
                }
                case "WaitForElementEnabled":
                {
                    int timeout = PageGUI.PageFindElementTimeout;
                    if (mcm.ArgCount > 0)
                    {
                        timeout = (int) mcm.Args[0];
                    }
                    if (func2 == null)
                    {
                        func2 = () => (base.CheckExistElement != null) && base.CheckExistElement.Enabled;
                    }
                    TestUtility.WaitFunc(func2, timeout, true, "Wait element enabled is timeout[{0}s]");
                    return new ReturnMessage(this.CheckExistElement, null, 0, mcm.LogicalCallContext, mcm);
                }
                case "WaitForElementDisappeared":
                {
                    int num3 = PageGUI.PageFindElementTimeout;
                    if (mcm.ArgCount > 0)
                    {
                        num3 = (int) mcm.Args[0];
                    }
                    if (this.CheckExistElement != null)
                    {
                        this.CheckExistElement.WaitForElementDisappeared(num3);
                    }
                    return new ReturnMessage(this.CheckExistElement, null, 0, mcm.LogicalCallContext, mcm);
                }
            }
            T element = this.Element;
            switch (methodName)
            {
                case "get_Self":
                    return new ReturnMessage(element, null, 0, mcm.LogicalCallContext, mcm);

                case "get_IsNull":
                    return new ReturnMessage(element == null, null, 0, mcm.LogicalCallContext, mcm);

                case "FieldGetter":
                {
                    FieldInfo field = typeof(T).GetField(mcm.Args[1] as string, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
                    object[] objArray2 = new object[3];
                    objArray2[2] = Convert.ChangeType(field.GetValue(element), field.FieldType);
                    object[] outArgs = objArray2;
                    return new ReturnMessage(null, outArgs, outArgs.Length, mcm.LogicalCallContext, mcm);
                }
            }
            return WebObjectProxy.InvokeMethod(mcm, element);
        }

        private T CheckExistElement
        {
            get
            {
                if (!base.Cache || (this.cachedElement == null))
                {
                    FindByContext byContext = new FindByContext {
                        AutoAdjustPageLoaded = false,
                        FindPolicy = base.ByContext.FindPolicy
                    };
                    foreach (FindByAttribute attribute in base.ByContext.FindsByAttributes)
                    {
                        FindByAttribute item = attribute;
                        if (item.WaitFind)
                        {
                            item = (FindByAttribute) attribute.Clone();
                            item.WaitFind = false;
                        }
                        byContext.FindsByAttributes.Add(item);
                    }
                    try
                    {
                        this.cachedElement = base.Locator.LocateElement<T>(byContext);
                    }
                    catch (NoSuchElementException)
                    {
                        this.cachedElement = default(T);
                    }
                }
                return this.cachedElement;
            }
        }

        private T Element
        {
            get
            {
                if (!base.Cache || (this.cachedElement == null))
                {
                    this.cachedElement = base.Locator.LocateElement<T>(base.ByContext);
                }
                return this.cachedElement;
            }
        }
    }
}

