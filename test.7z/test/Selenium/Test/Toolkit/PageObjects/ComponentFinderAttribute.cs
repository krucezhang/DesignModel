﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using Selenium.Test.Toolkit.Finder;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Class, AllowMultiple=true)]
    public sealed class ComponentFinderAttribute : FindByBaseAttribute
    {
        public ComponentFinderAttribute()
        {
            base.TextCondition = TextFindCondition.None;
        }

        public static Dictionary<string, By> BuildFinders(params Attribute[] attributes)
        {
            Dictionary<string, By> dictionary = new Dictionary<string, By>();
            foreach (Attribute attribute in attributes)
            {
                ComponentFinderAttribute attribute2 = attribute as ComponentFinderAttribute;
                if ((attribute2 != null) && !dictionary.ContainsKey(attribute2.FinderKey))
                {
                    dictionary.Add(attribute2.FinderKey, attribute2.Finder);
                }
            }
            return dictionary;
        }

        public string FinderKey { get; set; }
    }
}

