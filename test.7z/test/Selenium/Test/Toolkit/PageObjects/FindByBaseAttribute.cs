﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using System;
    using System.ComponentModel;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public abstract class FindByBaseAttribute : Attribute, ICloneable
    {
        private bool _useTextMap = true;
        private By finder;

        public FindByBaseAttribute()
        {
            this.Priority = 0;
            this.TextCondition = TextFindCondition.Equals;
            this.TextComparison = Selenium.Test.Toolkit.Finder.TextComparison.IgnoreCase;
            this.OnlyFindDisplay = true;
            this.WaitFind = true;
            this.WaitTimeout = -1;
        }

        public object Clone()
        {
            return base.MemberwiseClone();
        }

        internal By From(FindByBaseAttribute attribute)
        {
            if (string.IsNullOrEmpty(attribute.ContentText))
            {
                return attribute.FromBuildInBy(attribute);
            }
            By baseFinder = attribute.FromBuildInBy(attribute);
            if (baseFinder == null)
            {
                throw new ArgumentException("ContentText finder type must combine with other finder.");
            }
            return new ByContentText(baseFinder, attribute.ContentText, attribute.TextCondition, attribute.TextComparison, attribute.UseTextMap);
        }

        internal By FromBuildInBy(FindByBaseAttribute attribute)
        {
            if (!string.IsNullOrEmpty(attribute.Id))
            {
                return By.Id(attribute.Id);
            }
            if (!string.IsNullOrEmpty(attribute.Name))
            {
                return By.Name(attribute.Name);
            }
            if (!string.IsNullOrEmpty(attribute.ClassName))
            {
                return By.ClassName(attribute.ClassName);
            }
            if (!string.IsNullOrEmpty(attribute.CssSelector))
            {
                return By.CssSelector(attribute.CssSelector);
            }
            if (!string.IsNullOrEmpty(attribute.TagName))
            {
                return By.TagName(attribute.TagName);
            }
            if (!string.IsNullOrEmpty(attribute.PartialLinkText))
            {
                return By.PartialLinkText(attribute.PartialLinkText);
            }
            if (!string.IsNullOrEmpty(attribute.LinkText))
            {
                return By.LinkText(attribute.LinkText);
            }
            if (!string.IsNullOrEmpty(attribute.XPath))
            {
                return By.XPath(attribute.XPath);
            }
            if (!string.IsNullOrEmpty(attribute.Image))
            {
                return new ByImage(attribute.Image);
            }
            if (string.IsNullOrEmpty(attribute.Custom))
            {
                return null;
            }
            if (attribute.CustomFinderType == null)
            {
                throw new ArgumentException("Cannot use How.Custom without supplying a custom finder type");
            }
            if (!attribute.CustomFinderType.IsSubclassOf(typeof(By)))
            {
                throw new ArgumentException("Custom finder type must be a descendent of the By class");
            }
            ConstructorInfo constructor = attribute.CustomFinderType.GetConstructor(new Type[] { typeof(string) });
            if (constructor == null)
            {
                throw new ArgumentException("Custom finder type must expose a public constructor with a string argument");
            }
            return (constructor.Invoke(new object[] { attribute.Custom }) as By);
        }

        public string ClassName { get; set; }

        public string ContentText { get; set; }

        public string CssSelector { get; set; }

        public string Custom { get; set; }

        public Type CustomFinderType { get; set; }

        internal By Finder
        {
            get
            {
                if (this.finder == null)
                {
                    this.finder = this.From(this);
                }
                return this.finder;
            }
            set
            {
                this.finder = value;
            }
        }

        public string Id { get; set; }

        public string Image { get; set; }

        public string LinkText { get; set; }

        public string Name { get; set; }

        [DefaultValue(true)]
        public bool OnlyFindDisplay { get; set; }

        public string PartialLinkText { get; set; }

        [DefaultValue(0)]
        public int Priority { get; set; }

        public string TagName { get; set; }

        [DefaultValue(1)]
        public Selenium.Test.Toolkit.Finder.TextComparison TextComparison { get; set; }

        [DefaultValue(1)]
        public TextFindCondition TextCondition { get; set; }

        public bool TextIgnoreCase
        {
            get
            {
                return (this.TextComparison != Selenium.Test.Toolkit.Finder.TextComparison.None);
            }
            set
            {
                this.TextComparison = value ? Selenium.Test.Toolkit.Finder.TextComparison.IgnoreCase : Selenium.Test.Toolkit.Finder.TextComparison.None;
            }
        }

        [DefaultValue(true)]
        public bool UseTextMap
        {
            get
            {
                return this._useTextMap;
            }
            set
            {
                this._useTextMap = value;
                this.finder = null;
            }
        }

        [DefaultValue(true)]
        public bool WaitFind { get; set; }

        [DefaultValue(-1)]
        public int WaitTimeout { get; set; }

        public string XPath { get; set; }
    }
}

