﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using OpenQA.Selenium.Support.PageObjects;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public class DefaultComponentObjectMemberDecorator : IComponentObjectMemberDecorator
    {
        protected static FindByContext CreateFindByContext(MemberInfo member)
        {
            if (member == null)
            {
                throw new ArgumentNullException("member", "memeber cannot be null");
            }
            FindByContext context = new FindByContext();
            Attribute attribute = Attribute.GetCustomAttribute(member, typeof(FindPolicyAttribute), true);
            if (attribute != null)
            {
                FindPolicyAttribute attribute2 = (FindPolicyAttribute) attribute;
                context.FindPolicy = attribute2.Policy;
                context.FinderOverride = attribute2.Override;
            }
            Attribute[] array = Attribute.GetCustomAttributes(member, typeof(FindByAttribute), !context.FinderOverride);
            if (array.Length > 0)
            {
                Array.Sort<Attribute>(array);
                foreach (Attribute attribute3 in array)
                {
                    FindByAttribute item = (FindByAttribute) attribute3;
                    if (item.Finder == null)
                    {
                        item.Id = member.Name;
                    }
                    context.FindsByAttributes.Add(item);
                }
                Attribute[] attributes = Attribute.GetCustomAttributes(member, typeof(ComponentFinderAttribute), true);
                if (attributes.Length > 0)
                {
                    context.ComponentFinders = ComponentFinderAttribute.BuildFinders(attributes);
                }
            }
            return context;
        }

        private static object CreateProxyObject(Type memberType, IElementGUILocator locator, FindByContext byContext, bool cache)
        {
            object obj2 = null;
            if (memberType.IsGenericType && typeof(IList<>).IsAssignableFrom(memberType.GetGenericTypeDefinition()))
            {
                Type c = memberType.GetGenericArguments()[0];
                if (typeof(IElementGUI).IsAssignableFrom(c))
                {
                    obj2 = typeof(WebElementGUIListProxy<IElementGUI>).GetMethod("CreateProxy").MakeGenericMethod(new Type[] { c }).Invoke(null, new object[] { memberType, locator, byContext, cache });
                }
            }
            else if (typeof(IElementGUI).IsAssignableFrom(memberType))
            {
                obj2 = typeof(WebElementGUIProxy<IElementGUI>).GetMethod("CreateProxy").MakeGenericMethod(new Type[] { memberType }).Invoke(null, new object[] { memberType, locator, byContext, cache });
            }
            if (obj2 == null)
            {
                throw new ArgumentException("Type of member '" + memberType.Name + "' is not IElementGUI or IList<IElementGUI>");
            }
            return obj2;
        }

        public object Decorate(MemberInfo member, IElementGUILocator locator)
        {
            FieldInfo info = member as FieldInfo;
            PropertyInfo info2 = member as PropertyInfo;
            Type memberType = null;
            if (info != null)
            {
                memberType = info.FieldType;
            }
            bool canWrite = false;
            if (info2 != null)
            {
                canWrite = info2.CanWrite;
                memberType = info2.PropertyType;
            }
            if (!((info == null) & ((info2 == null) || !canWrite)))
            {
                FindByContext byContext = CreateFindByContext(member);
                if (byContext.FindsByAttributes.Count > 0)
                {
                    bool cache = ShouldCacheLookup(member);
                    return CreateProxyObject(memberType, locator, byContext, cache);
                }
            }
            return null;
        }

        protected static bool ShouldCacheLookup(MemberInfo member)
        {
            if (member == null)
            {
                throw new ArgumentNullException("member", "memeber cannot be null");
            }
            Type attributeType = typeof(CacheLookupAttribute);
            return ((member.GetCustomAttributes(attributeType, true).Length != 0) || (member.DeclaringType.GetCustomAttributes(attributeType, true).Length != 0));
        }
    }
}

