﻿namespace Selenium.Test.Toolkit.PageObjects
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Remoting.Messaging;

    internal class WebElementGUIListProxy<T> : WebObjectProxy where T: IElementGUI
    {
        private IList<T> collection;

        private WebElementGUIListProxy(Type typeToBeProxied, IElementGUILocator locator, FindByContext byContext, bool cache) : base(typeToBeProxied, locator, byContext, cache)
        {
        }

        public static object CreateProxy<ET>(Type classToProxy, IElementGUILocator locator, FindByContext byContext, bool cacheLookups) where ET: IElementGUI
        {
            return new WebElementGUIListProxy<ET>(classToProxy, locator, byContext, cacheLookups).GetTransparentProxy();
        }

        public override IMessage Invoke(IMessage msg)
        {
            IList<T> elementList = this.ElementList;
            return WebObjectProxy.InvokeMethod(msg as IMethodCallMessage, elementList);
        }

        private IList<T> ElementList
        {
            get
            {
                if (!base.Cache || (this.collection == null))
                {
                    this.collection = base.Locator.LocateElements<T>(base.ByContext);
                }
                return this.collection;
            }
        }
    }
}

