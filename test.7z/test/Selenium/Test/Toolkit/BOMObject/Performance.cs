﻿namespace Selenium.Test.Toolkit.BOMObject
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class Performance : JSObject
    {
        internal Performance(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public double now()
        {
            return this.InvokeJSMehtod<double>("now", new object[0]);
        }

        public double PerformanceEvlution(CodeSnippet code)
        {
            CodeSnippet snippet = this.GetInvokeJSSnippet("now", "startTime", new object[0]);
            CodeSnippet snippet2 = this.GetInvokeJSSnippet("now", "endTime", new object[0]);
            string str = snippet.Snippet + code.Snippet + snippet2.Snippet + string.Format("return {1} - {0};", snippet.CodeHeader, snippet2.CodeHeader);
            CodeSnippet executeCode = new CodeSnippet(code.CodeHeader, str, code.Args.ToArray());
            return Convert.ToDouble(this.ExecuteJS(executeCode));
        }

        public double PerformanceEvlution(Action action)
        {
            double num = this.now();
            action();
            return (this.now() - num);
        }

        public PerformanceTiming timing
        {
            get
            {
                return this.GetJSProperty<PerformanceTiming>("timing");
            }
        }
    }
}

