﻿namespace Selenium.Test.Toolkit.BOMObject
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class PerformanceTiming : JSObject
    {
        internal PerformanceTiming(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public double connectEnd
        {
            get
            {
                return this.GetJSProperty<double>("connectEnd");
            }
        }

        public double connectStart
        {
            get
            {
                return this.GetJSProperty<double>("connectStart");
            }
        }

        public double domainLookupEnd
        {
            get
            {
                return this.GetJSProperty<double>("domainLookupEnd");
            }
        }

        public double domainLookupStart
        {
            get
            {
                return this.GetJSProperty<double>("domainLookupStart");
            }
        }

        public double domComplete
        {
            get
            {
                return this.GetJSProperty<double>("domComplete");
            }
        }

        public double domContentLoadedEventEnd
        {
            get
            {
                return this.GetJSProperty<double>("domContentLoadedEventEnd");
            }
        }

        public double domContentLoadedEventStart
        {
            get
            {
                return this.GetJSProperty<double>("domContentLoadedEventStart");
            }
        }

        public double domInteractive
        {
            get
            {
                return this.GetJSProperty<double>("domInteractive");
            }
        }

        public double domLoading
        {
            get
            {
                return this.GetJSProperty<double>("domLoading");
            }
        }

        public double fetchStart
        {
            get
            {
                return this.GetJSProperty<double>("fetchStart");
            }
        }

        public double loadEventEnd
        {
            get
            {
                return this.GetJSProperty<double>("loadEventEnd");
            }
        }

        public double loadEventStart
        {
            get
            {
                return this.GetJSProperty<double>("loadEventStart");
            }
        }

        public double navigationStart
        {
            get
            {
                return this.GetJSProperty<double>("navigationStart");
            }
        }

        public double redirectEnd
        {
            get
            {
                return this.GetJSProperty<double>("redirectEnd");
            }
        }

        public double redirectStart
        {
            get
            {
                return this.GetJSProperty<double>("redirectStart");
            }
        }

        public double requestStart
        {
            get
            {
                return this.GetJSProperty<double>("requestStart");
            }
        }

        public double responseEnd
        {
            get
            {
                return this.GetJSProperty<double>("responseEnd");
            }
        }

        public double responseStart
        {
            get
            {
                return this.GetJSProperty<double>("responseStart");
            }
        }

        public double secureConnectionStart
        {
            get
            {
                return this.GetJSProperty<double>("secureConnectionStart");
            }
        }

        public double unloadEventEnd
        {
            get
            {
                return this.GetJSProperty<double>("unloadEventEnd");
            }
        }

        public double unloadEventStart
        {
            get
            {
                return this.GetJSProperty<double>("unloadEventStart");
            }
        }
    }
}

