﻿namespace Selenium.Test.Toolkit.BOMObject
{
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using System.Runtime.InteropServices;

    public class Style : ExecutableObject
    {
        private DomElementGUI _domElementGUI;

        public Style() : base(null)
        {
        }

        public Style(CodeSnippet dependedScript, DomElementGUI domElementGUI = null) : base(dependedScript)
        {
            this._domElementGUI = domElementGUI;
        }

        public override void Dispose()
        {
            this._domElementGUI = null;
            base.Dispose();
        }

        internal static Style GetComputedStyle(DomElementGUI domGUI, string pseudoElement)
        {
            List<object> list = new List<object> {
                domGUI
            };
            if (!string.IsNullOrWhiteSpace(pseudoElement))
            {
                list.Add(pseudoElement);
            }
            ExecutableObject obj2 = new ExecutableObject(new CodeSnippet("window", string.Empty, new object[0]));
            return new Style(obj2.GetInvokeJSSnippet("getComputedStyle", "computedStyle", list.ToArray()), domGUI);
        }

        protected override CodeSnippet GetDependedScript()
        {
            CodeSnippet dependedScript = base.GetDependedScript();
            if (dependedScript == null)
            {
                CodeSnippet executeCode = new CodeSnippet("domStyle", "var domStyle = document.createElement('STYLE');", new object[0]);
                dependedScript = this.GetExecutedJSSnippet(executeCode, "domStyle");
                base.DependedScript = dependedScript;
            }
            return dependedScript;
        }

        internal static Style GetDomStyle(DomElementGUI domGUI)
        {
            return new Style(domGUI.ExecutableAdapter.GetJSPropertyJSSnippet("style", "domStyle"), domGUI);
        }

        internal static Style GetIECurrentStyle(DomElementGUI domGUI)
        {
            return new Style(domGUI.ExecutableAdapter.GetJSPropertyJSSnippet("currentStyle", "domCurrentStyle"), domGUI);
        }

        public T getPropertyValue<T>(string property)
        {
            return this.InvokeJSMehtod<T>("getPropertyValue", new object[] { property });
        }

        public string background
        {
            get
            {
                return this.GetJSProperty<string>("background");
            }
            set
            {
                this.SetJSProperty("background", value);
            }
        }

        public Color backgroundColor
        {
            get
            {
                return this.GetJSProperty<Color>("backgroundColor");
            }
            set
            {
                this.SetJSProperty("backgroundColor", value);
            }
        }

        public string backgroundPosition
        {
            get
            {
                string jSProperty = this.GetJSProperty<string>("backgroundPosition");
                if (this._domElementGUI == null)
                {
                    return jSProperty;
                }
                if ((jSProperty != null) && jSProperty.Contains<char>(' '))
                {
                    return jSProperty;
                }
                Style iECurrentStyle = GetIECurrentStyle(this._domElementGUI);
                return (iECurrentStyle.backgroundPositionX + " " + iECurrentStyle.backgroundPositionY);
            }
            set
            {
                this.SetJSProperty("backgroundPosition", value);
            }
        }

        private string backgroundPositionX
        {
            get
            {
                string jSProperty = this.GetJSProperty<string>("backgroundPositionX");
                if (string.IsNullOrWhiteSpace(jSProperty) || (jSProperty.Trim().ToLower() == "left"))
                {
                    return "0%";
                }
                if (jSProperty.Trim().ToLower() == "center")
                {
                    return "50%";
                }
                if (jSProperty.Trim().ToLower() == "right")
                {
                    return "100%";
                }
                return jSProperty;
            }
        }

        private string backgroundPositionY
        {
            get
            {
                string jSProperty = this.GetJSProperty<string>("backgroundPositionY");
                if (string.IsNullOrWhiteSpace(jSProperty) || (jSProperty.Trim().ToLower() == "top"))
                {
                    return "0%";
                }
                if (jSProperty.Trim().ToLower() == "center")
                {
                    return "50%";
                }
                if (jSProperty.Trim().ToLower() == "bottom")
                {
                    return "100%";
                }
                return jSProperty;
            }
        }

        public string backgroundRepeat
        {
            get
            {
                return this.GetJSProperty<string>("backgroundRepeat");
            }
            set
            {
                this.SetJSProperty("backgroundRepeat", value);
            }
        }

        public string border
        {
            get
            {
                return this.GetJSProperty<string>("border");
            }
            set
            {
                this.SetJSProperty("border", value);
            }
        }

        public string borderBottom
        {
            get
            {
                return this.GetJSProperty<string>("borderBottom");
            }
            set
            {
                this.SetJSProperty("borderBottom", value);
            }
        }

        public Color borderBottomColor
        {
            get
            {
                return this.GetJSProperty<Color>("borderBottomColor");
            }
            set
            {
                this.SetJSProperty("borderBottomColor", value);
            }
        }

        public string borderBottomStyle
        {
            get
            {
                return this.GetJSProperty<string>("borderBottomStyle");
            }
            set
            {
                this.SetJSProperty("borderBottomStyle", value);
            }
        }

        public string borderBottomWidth
        {
            get
            {
                return this.GetJSProperty<string>("borderBottomWidth");
            }
            set
            {
                this.SetJSProperty("borderBottomWidth", value);
            }
        }

        public string borderLeft
        {
            get
            {
                return this.GetJSProperty<string>("borderLeft");
            }
            set
            {
                this.SetJSProperty("borderLeft", value);
            }
        }

        public Color borderLeftColor
        {
            get
            {
                return this.GetJSProperty<Color>("borderLeftColor");
            }
            set
            {
                this.SetJSProperty("borderLeftColor", value);
            }
        }

        public string borderLeftStyle
        {
            get
            {
                return this.GetJSProperty<string>("borderLeftStyle");
            }
            set
            {
                this.SetJSProperty("borderLeftStyle", value);
            }
        }

        public string borderLeftWidth
        {
            get
            {
                return this.GetJSProperty<string>("borderLeftWidth");
            }
            set
            {
                this.SetJSProperty("borderLeftWidth", value);
            }
        }

        public string borderRight
        {
            get
            {
                return this.GetJSProperty<string>("borderRight");
            }
            set
            {
                this.SetJSProperty("borderRight", value);
            }
        }

        public Color borderRightColor
        {
            get
            {
                return this.GetJSProperty<Color>("borderRightColor");
            }
            set
            {
                this.SetJSProperty("borderRightColor", value);
            }
        }

        public string borderRightStyle
        {
            get
            {
                return this.GetJSProperty<string>("borderRightStyle");
            }
            set
            {
                this.SetJSProperty("borderRightStyle", value);
            }
        }

        public string borderRightWidth
        {
            get
            {
                return this.GetJSProperty<string>("borderRightWidth");
            }
            set
            {
                this.SetJSProperty("borderRightWidth", value);
            }
        }

        public string borderTop
        {
            get
            {
                return this.GetJSProperty<string>("borderTop");
            }
            set
            {
                this.SetJSProperty("borderTop", value);
            }
        }

        public Color borderTopColor
        {
            get
            {
                return this.GetJSProperty<Color>("borderTopColor");
            }
            set
            {
                this.SetJSProperty("borderTopColor", value);
            }
        }

        public string borderTopStyle
        {
            get
            {
                return this.GetJSProperty<string>("borderTopStyle");
            }
            set
            {
                this.SetJSProperty("borderTopStyle", value);
            }
        }

        public string borderTopWidth
        {
            get
            {
                return this.GetJSProperty<string>("borderTopWidth");
            }
            set
            {
                this.SetJSProperty("borderTopWidth", value);
            }
        }

        public Color color
        {
            get
            {
                return this.GetJSProperty<Color>("color");
            }
            set
            {
                this.SetJSProperty("color", value);
            }
        }

        public string cursor
        {
            get
            {
                return this.GetJSProperty<string>("cursor");
            }
            set
            {
                this.SetJSProperty("cursor", value);
            }
        }

        public string direction
        {
            get
            {
                return this.GetJSProperty<string>("direction");
            }
            set
            {
                this.SetJSProperty("direction", value);
            }
        }

        public string display
        {
            get
            {
                return this.GetJSProperty<string>("display");
            }
            set
            {
                this.SetJSProperty("display", value);
            }
        }

        public string font
        {
            get
            {
                return this.GetJSProperty<string>("font");
            }
            set
            {
                this.SetJSProperty("font", value);
            }
        }

        public string fontFamily
        {
            get
            {
                string jSProperty = this.GetJSProperty<string>("fontFamily");
                if (!string.IsNullOrEmpty(jSProperty))
                {
                    jSProperty = jSProperty.Replace("'", string.Empty);
                    if (jSProperty.StartsWith("\"") && jSProperty.EndsWith("\""))
                    {
                        jSProperty = jSProperty.Substring(1, jSProperty.Length - 2);
                    }
                }
                return jSProperty;
            }
            set
            {
                this.SetJSProperty("fontFamily", value);
            }
        }

        public string fontSize
        {
            get
            {
                return this.GetJSProperty<string>("fontSize");
            }
            set
            {
                this.SetJSProperty("fontSize", value);
            }
        }

        public string fontStyle
        {
            get
            {
                return this.GetJSProperty<string>("fontStyle");
            }
            set
            {
                this.SetJSProperty("fontStyle", value);
            }
        }

        public string fontWeight
        {
            get
            {
                string jSProperty = this.GetJSProperty<string>("fontWeight");
                switch (jSProperty)
                {
                    case "400":
                        return "normal";

                    case "700":
                        return "bold";
                }
                return jSProperty;
            }
            set
            {
                this.SetJSProperty("fontWeight", value);
            }
        }

        public string margin
        {
            get
            {
                return this.GetJSProperty<string>("margin");
            }
            set
            {
                this.SetJSProperty("margin", value);
            }
        }

        public string marginBottom
        {
            get
            {
                return this.GetJSProperty<string>("marginBottom");
            }
            set
            {
                this.SetJSProperty("marginBottom", value);
            }
        }

        public string marginLeft
        {
            get
            {
                return this.GetJSProperty<string>("marginLeft");
            }
            set
            {
                this.SetJSProperty("marginLeft", value);
            }
        }

        public string marginRight
        {
            get
            {
                return this.GetJSProperty<string>("marginRight");
            }
            set
            {
                this.SetJSProperty("marginRight", value);
            }
        }

        public string marginTop
        {
            get
            {
                return this.GetJSProperty<string>("marginTop");
            }
            set
            {
                this.SetJSProperty("marginTop", value);
            }
        }

        public string outlineStyle
        {
            get
            {
                return this.GetJSProperty<string>("outlineStyle");
            }
            set
            {
                this.SetJSProperty("outlineStyle", value);
            }
        }

        public string overflow
        {
            get
            {
                return this.GetJSProperty<string>("overflow");
            }
            set
            {
                this.SetJSProperty("overflow", value);
            }
        }

        public string overflowX
        {
            get
            {
                return this.GetJSProperty<string>("overflowX");
            }
            set
            {
                this.SetJSProperty("overflowX", value);
            }
        }

        public string overflowY
        {
            get
            {
                return this.GetJSProperty<string>("overflowY");
            }
            set
            {
                this.SetJSProperty("overflowY", value);
            }
        }

        public string padding
        {
            get
            {
                return this.GetJSProperty<string>("padding");
            }
            set
            {
                this.SetJSProperty("padding", value);
            }
        }

        public string paddingBottom
        {
            get
            {
                return this.GetJSProperty<string>("paddingBottom");
            }
            set
            {
                this.SetJSProperty("paddingBottom", value);
            }
        }

        public string paddingLeft
        {
            get
            {
                return this.GetJSProperty<string>("paddingLeft");
            }
            set
            {
                this.SetJSProperty("paddingLeft", value);
            }
        }

        public string paddingRight
        {
            get
            {
                return this.GetJSProperty<string>("paddingRight");
            }
            set
            {
                this.SetJSProperty("paddingRight", value);
            }
        }

        public string paddingTop
        {
            get
            {
                return this.GetJSProperty<string>("paddingTop");
            }
            set
            {
                this.SetJSProperty("paddingTop", value);
            }
        }

        public string position
        {
            get
            {
                return this.GetJSProperty<string>("position");
            }
            set
            {
                this.SetJSProperty("position", value);
            }
        }

        public string textAlign
        {
            get
            {
                return this.GetJSProperty<string>("textAlign");
            }
            set
            {
                this.SetJSProperty("textAlign", value);
            }
        }

        public string textDecoration
        {
            get
            {
                return this.GetJSProperty<string>("textDecoration");
            }
            set
            {
                this.SetJSProperty("textDecoration", value);
            }
        }

        public string verticalAlign
        {
            get
            {
                return this.GetJSProperty<string>("verticalAlign");
            }
            set
            {
                this.SetJSProperty("verticalAlign", value);
            }
        }

        public string whiteSpace
        {
            get
            {
                return this.GetJSProperty<string>("whiteSpace");
            }
            set
            {
                this.SetJSProperty("whiteSpace", value);
            }
        }

        public string wordWrap
        {
            get
            {
                return this.GetJSProperty<string>("wordWrap");
            }
            set
            {
                this.SetJSProperty("wordWrap", value);
            }
        }

        public int zIndex
        {
            get
            {
                return this.GetJSProperty<int>("zIndex");
            }
            set
            {
                this.SetJSProperty("zIndex", value.ToString());
            }
        }
    }
}

