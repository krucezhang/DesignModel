﻿namespace Selenium.Test.Toolkit.BOMObject
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.InteropServices;

    public class Window : JSObject
    {
        public Window() : base(null)
        {
        }

        internal Window(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public void eval(object str)
        {
            this.InvokeJSMehtod("eval", new object[] { str });
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            return new CodeSnippet("window", string.Empty, new object[0]);
        }

        public void saveAs(ExecutableObject blob, string fileName = null)
        {
            this.FileSaver.saveAs(blob, fileName);
        }

        public void scrollBy(int x, int y)
        {
            this.InvokeJSMehtod("scrollBy", new object[] { x, y });
        }

        public void scrollTo(int x, int y)
        {
            this.InvokeJSMehtod("scrollTo", new object[] { x, y });
        }

        public Document document
        {
            get
            {
                return this.GetJSProperty<Document>("document");
            }
        }

        public FileSaverObject FileSaver
        {
            get
            {
                return new FileSaverObject(base.DependedScript);
            }
        }

        public Performance performance
        {
            get
            {
                return this.GetJSProperty<Performance>("performance");
            }
        }
    }
}

