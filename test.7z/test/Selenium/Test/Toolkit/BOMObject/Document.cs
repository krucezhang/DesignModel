﻿namespace Selenium.Test.Toolkit.BOMObject
{
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class Document : JSObject
    {
        public Document() : base(null)
        {
        }

        internal Document(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            return new CodeSnippet("window.document", string.Empty, new object[0]);
        }

        public DomElementGUI body
        {
            get
            {
                return this.GetJSProperty<DomElementGUI>("body");
            }
        }

        public DomElementGUI documentElement
        {
            get
            {
                return this.GetJSProperty<DomElementGUI>("documentElement");
            }
        }
    }
}

