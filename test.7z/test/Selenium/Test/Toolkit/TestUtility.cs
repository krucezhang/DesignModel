﻿namespace Selenium.Test.Toolkit
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Reflection;
    using System.Threading;

    public class TestUtility
    {
        private static int SleepWaitTime = 200;

        public static void CloseAllBrowsers()
        {
            CloseAllBrowsersWith(true, new string[0]);
        }

        public static void CloseAllBrowsersWith(bool isCloseAllBrowser, params string[] processNames)
        {
            try
            {
                if (isCloseAllBrowser || (processNames.Length != 0))
                {
                    Process[] processes = Process.GetProcesses();
                    for (int i = 0; i < processes.Length; i++)
                    {
                        try
                        {
                            Process process = processes[i];
                            if ((process != null) && !process.HasExited)
                            {
                                string processName = process.ProcessName;
                                if (isCloseAllBrowser)
                                {
                                    string str2 = processName.ToLower();
                                    if (((str2.Contains("chrome") || str2.Contains("firefox")) || (str2.Contains("opera") || str2.Contains("safari"))) || ((str2.Contains("iexplore") || str2.Contains("microsoftedge")) || (str2.Contains("internet explorer") || str2.Contains("360se"))))
                                    {
                                        KillProcess(process);
                                        continue;
                                    }
                                }
                                foreach (string str3 in processNames)
                                {
                                    if (processName.Trim().Equals(str3.Trim(), StringComparison.OrdinalIgnoreCase))
                                    {
                                        KillProcess(process);
                                        continue;
                                    }
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }
        }

        internal static T CreateInstance<T>(CodeSnippet dependedCode, IWebElement webElement, IElementGUI parentGUI, params object[] args)
        {
            ArrayList list = new ArrayList();
            if (typeof(ExecutableObject).IsAssignableFrom(typeof(T)))
            {
                if (dependedCode == null)
                {
                    throw new InvalidCastException(string.Format("Can't create instance from specify type[{0}].", typeof(T).Name));
                }
                list.Add(dependedCode);
            }
            if (typeof(WebElementGUI).IsAssignableFrom(typeof(T)))
            {
                if ((dependedCode == null) && (webElement == null))
                {
                    throw new InvalidCastException(string.Format("Can't create instance from specify type[{0}].", typeof(T).Name));
                }
                list.Add(webElement);
                if (dependedCode != null)
                {
                    list.Add(dependedCode);
                    if (parentGUI != null)
                    {
                        list.Add(parentGUI);
                    }
                }
            }
            if (args != null)
            {
                list.AddRange(args);
            }
            return (T) Activator.CreateInstance(typeof(T), BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, list.ToArray(), CultureInfo.CurrentCulture);
        }

        public static T FindDisplayedElementGUI<T>(ISearchContext webContext, By by, bool throwExpection)
        {
            IList<T> list = null;
            try
            {
                list = FindElementGUIs<T>(webContext, by);
            }
            catch
            {
            }
            if (list != null)
            {
                foreach (T local in list)
                {
                    IElementGUI tgui = local as IElementGUI;
                    if (tgui != null)
                    {
                        try
                        {
                            if (tgui.Visible)
                            {
                                return local;
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            if (throwExpection)
            {
                throw new NoSuchElementException(string.Format("Could not find displayed element by:[{0}].", by));
            }
            return default(T);
        }

        public static IList<T> FindDisplayedElementGUIs<T>(ISearchContext webContext, By by)
        {
            IList<T> list = null;
            try
            {
                list = FindElementGUIs<T>(webContext, by);
            }
            catch
            {
            }
            List<T> list2 = new List<T>();
            if (list != null)
            {
                foreach (T local in list)
                {
                    IElementGUI tgui = local as IElementGUI;
                    if (tgui != null)
                    {
                        try
                        {
                            if (tgui.Visible)
                            {
                                list2.Add(local);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            return list2;
        }

        public static T FindElementGUI<T>(ISearchContext webContext, By by, bool throwExpection)
        {
            IWebElement webElement = null;
            try
            {
                webElement = webContext.FindElement(by);
            }
            catch (Exception exception)
            {
                if (throwExpection)
                {
                    throw exception;
                }
            }
            if (webElement != null)
            {
                return CreateInstance<T>(null, webElement, null, new object[0]);
            }
            return default(T);
        }

        public static IList<T> FindElementGUIs<T>(ISearchContext webContext, By by)
        {
            IList<IWebElement> list = webContext.FindElements(by);
            List<T> list2 = new List<T>();
            if (list != null)
            {
                foreach (IWebElement element in list)
                {
                    T item = CreateInstance<T>(null, element, null, new object[0]);
                    list2.Add(item);
                }
            }
            return list2;
        }

        public static void KillProcess(Process process)
        {
            try
            {
                TimeSpan timeout = TimeSpan.FromMilliseconds(100.0);
                if ((process != null) && !process.HasExited)
                {
                    for (int i = 0; i < 30; i++)
                    {
                        try
                        {
                            if (((process != null) && !process.HasExited) && (process.MainWindowHandle != IntPtr.Zero))
                            {
                                for (int j = 0; j < 30; j++)
                                {
                                    try
                                    {
                                        if ((process == null) || process.HasExited)
                                        {
                                            break;
                                        }
                                        process.CloseMainWindow();
                                    }
                                    catch
                                    {
                                    }
                                    Thread.Sleep(timeout);
                                }
                            }
                            if ((process != null) && !process.HasExited)
                            {
                                process.Kill();
                            }
                        }
                        catch
                        {
                        }
                        Thread.Sleep(timeout);
                    }
                }
            }
            catch
            {
            }
        }

        public static void KillProcess(params string[] processNames)
        {
            try
            {
                Process[] processes = Process.GetProcesses();
                for (int i = 0; i < processes.Length; i++)
                {
                    try
                    {
                        Process process = processes[i];
                        if ((process != null) && !process.HasExited)
                        {
                            string processName = process.ProcessName;
                            foreach (string str2 in processNames)
                            {
                                if (processName.Trim().Equals(str2.Trim(), StringComparison.OrdinalIgnoreCase))
                                {
                                    KillProcess(process);
                                    continue;
                                }
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        public static T WaitFindDisplayElementGUI<T>(IWebDriver webDriver, ISearchContext webContext, By by, int timeout)
        {
            return WaitFindDisplayElementGUI<T>(webDriver, webContext, by, true, timeout);
        }

        public static T WaitFindDisplayElementGUI<T>(IWebDriver webDriver, ISearchContext webContext, By by, bool throwExpection, int timeout)
        {
            Func<IWebDriver, T> func = null;
            T local = default(T);
            try
            {
                if (!Manager.IgnoreAssertAlertDialog)
                {
                    try
                    {
                        IAlert alert = webDriver.SwitchTo().Alert();
                        throw new UnhandledAlertException("Find unexpected Alert dialog. The alert text is: \"" + alert.get_Text() + "\"");
                    }
                    catch (Exception exception)
                    {
                        if (exception is UnhandledAlertException)
                        {
                            throw exception;
                        }
                    }
                }
                local = FindDisplayedElementGUI<T>(webContext, by, false);
            }
            catch (Exception exception2)
            {
                if (exception2 is UnhandledAlertException)
                {
                    throw exception2;
                }
            }
            if (local == null)
            {
                try
                {
                    WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromMilliseconds((double) timeout));
                    if (func == null)
                    {
                        func = delegate (IWebDriver d) {
                            try
                            {
                                if (!Manager.IgnoreAssertAlertDialog)
                                {
                                    try
                                    {
                                        IAlert alert = webDriver.SwitchTo().Alert();
                                        throw new UnhandledAlertException("Find unexpected Alert dialog. The alert text is: \"" + alert.get_Text() + "\"");
                                    }
                                    catch (Exception exception)
                                    {
                                        if (exception is UnhandledAlertException)
                                        {
                                            throw exception;
                                        }
                                    }
                                }
                                T local = FindDisplayedElementGUI<T>(webContext, by, false);
                                if (local == null)
                                {
                                    Thread.Sleep(SleepWaitTime);
                                }
                                return local;
                            }
                            catch (Exception exception2)
                            {
                                if (exception2 is UnhandledAlertException)
                                {
                                    throw exception2;
                                }
                                Thread.Sleep(SleepWaitTime);
                                return default(T);
                            }
                        };
                    }
                    local = wait.Until<T>(func);
                }
                catch (Exception exception3)
                {
                    if (!throwExpection)
                    {
                        return local;
                    }
                    if (exception3 is WebDriverTimeoutException)
                    {
                        throw new NoSuchElementException(string.Format("Could not find displayed element by:[{0}] is timeout[{1}s].", by, timeout / 0x3e8));
                    }
                    throw exception3;
                }
            }
            return local;
        }

        public static T WaitFindElementGUI<T>(IWebDriver webDriver, ISearchContext webContext, By by, int timeout)
        {
            return WaitFindDisplayElementGUI<T>(webDriver, webContext, by, true, timeout);
        }

        public static T WaitFindElementGUI<T>(IWebDriver webDriver, ISearchContext webContext, By by, bool throwExpection, int timeout)
        {
            Func<IWebDriver, T> func = null;
            T local = default(T);
            try
            {
                if (!Manager.IgnoreAssertAlertDialog)
                {
                    try
                    {
                        IAlert alert = webDriver.SwitchTo().Alert();
                        throw new UnhandledAlertException("Find unexpected Alert dialog. The alert text is: \"" + alert.get_Text() + "\"");
                    }
                    catch (Exception exception)
                    {
                        if (exception is UnhandledAlertException)
                        {
                            throw exception;
                        }
                    }
                }
                local = FindElementGUI<T>(webContext, by, true);
            }
            catch (Exception exception2)
            {
                if (exception2 is UnhandledAlertException)
                {
                    throw exception2;
                }
            }
            if (local == null)
            {
                try
                {
                    WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromMilliseconds((double) timeout));
                    if (func == null)
                    {
                        func = delegate (IWebDriver d) {
                            try
                            {
                                if (!Manager.IgnoreAssertAlertDialog)
                                {
                                    try
                                    {
                                        IAlert alert = webDriver.SwitchTo().Alert();
                                        throw new UnhandledAlertException("Find unexpected Alert dialog. The alert text is: \"" + alert.get_Text() + "\"");
                                    }
                                    catch (Exception exception)
                                    {
                                        if (exception is UnhandledAlertException)
                                        {
                                            throw exception;
                                        }
                                    }
                                }
                                return FindElementGUI<T>(webContext, by, true);
                            }
                            catch (Exception exception2)
                            {
                                if (exception2 is UnhandledAlertException)
                                {
                                    throw exception2;
                                }
                                Thread.Sleep(SleepWaitTime);
                                return default(T);
                            }
                        };
                    }
                    local = wait.Until<T>(func);
                }
                catch (Exception exception3)
                {
                    if (!throwExpection)
                    {
                        return local;
                    }
                    if (exception3 is WebDriverTimeoutException)
                    {
                        throw new NoSuchElementException(string.Format("Could not find element by:[{0}] is timeout[{1}s].", by, timeout / 0x3e8));
                    }
                    throw exception3;
                }
            }
            return local;
        }

        public static void WaitFunc(Func<bool> action, int timeout, bool throwException, string message)
        {
            DateTime now = DateTime.Now;
            while (DateTime.Now.Subtract(now) <= TimeSpan.FromMilliseconds((double) timeout))
            {
                if (action())
                {
                    return;
                }
            }
            if (throwException)
            {
                if (string.IsNullOrWhiteSpace(message))
                {
                    message = "Wait function is timeout[{0}s].";
                }
                throw new InvalidProgramException(string.Format(message, timeout / 0x3e8));
            }
        }
    }
}

