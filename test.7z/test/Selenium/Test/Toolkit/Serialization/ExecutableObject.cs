﻿namespace Selenium.Test.Toolkit.Serialization
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.BOMObject;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization.Converter;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class ExecutableObject : IExecutable, IDisposable
    {
        private CodeSnippet _dependedScript;
        private static List<string> _refCodeHeaderNameList;
        private static int _tempCodeHeaderNameID;
        protected const string InjectionDependencyMark = "InjectDP";

        public ExecutableObject(CodeSnippet dependedScript)
        {
            this._dependedScript = dependedScript;
            this.Initization();
        }

        public virtual T AsTo<T>()
        {
            return TestUtility.CreateInstance<T>(this.DependedScript, null, null, new object[0]);
        }

        public static void ClearCodeHeaderManager()
        {
            _tempCodeHeaderNameID = 0;
            if (_refCodeHeaderNameList != null)
            {
                _refCodeHeaderNameList.Clear();
                _refCodeHeaderNameList = null;
            }
        }

        public virtual void Dispose()
        {
            if (this._dependedScript != null)
            {
                this._dependedScript.Dispose();
                this._dependedScript = null;
            }
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ExecutableObject))
            {
                return false;
            }
            ExecutableObject obj2 = (ExecutableObject) obj;
            CodeSnippet snippet = new CodeSnippet("left1", this.DependedScript.Snippet + "var left1 = " + this.DependedScript.CodeHeader + ";", new object[0]);
            CodeSnippet snippet2 = new CodeSnippet("right1", obj2.DependedScript.Snippet + "var right1 = " + obj2.DependedScript.CodeHeader + ";", new object[0]);
            string str2 = snippet.Snippet + snippet2.Snippet;
            string str = str2 + "return (" + snippet.CodeHeader + " === " + snippet2.CodeHeader + ");";
            return (bool) this.ExecuteJS(new CodeSnippet(string.Empty, str, new object[0]));
        }

        public virtual object ExecuteJS(CodeSnippet executeCode)
        {
            string str2;
            DependencyInjectionContext context;
            string script = this.InjectDPDetection() + executeCode.Snippet;
            object[] args = executeCode.Args.ToArray();
            do
            {
                object obj2 = ExecuteScript(script, args);
                if ((obj2 == null) || !(obj2 is string))
                {
                    return obj2;
                }
                str2 = (string) obj2;
                if (!str2.StartsWith("InjectDP", StringComparison.OrdinalIgnoreCase))
                {
                    return obj2;
                }
                context = new DependencyInjectionContext(str2);
                this.InjectionDependency(context);
            }
            while (context.InjectSucess);
            throw new InvalidProgramException(string.Format("The [{0}] dependency injection is failed, or not inject.", str2.Substring("InjectDP".Length)));
        }

        public static object ExecuteScript(string script, params object[] args)
        {
            return (Manager.Current.ActiveBrowser.WebDriver as IJavaScriptExecutor).ExecuteScript(script, args);
        }

        public CodeSnippet GetCtorJSSnippet(string typeFullName, string header = null, params object[] args)
        {
            return InnerGetCtorJSSnippet(typeFullName, header, args);
        }

        protected virtual CodeSnippet GetDependedScript()
        {
            return this._dependedScript;
        }

        protected CodeSnippet GetEmptyCtorJSSnippet(string typeFullName, string header = null)
        {
            return InnerGetEmptyCtorJSSnippet(typeFullName, header);
        }

        public virtual CodeSnippet GetExecutedJSSnippet(CodeSnippet executeCode, string header = null)
        {
            string newCodeHeader = GetNewCodeHeader(header);
            string str2 = executeCode.Snippet + string.Format("{0} = {1};", newCodeHeader, executeCode.CodeHeader);
            CodeSnippet snippet = new CodeSnippet(newCodeHeader, str2, executeCode.Args.ToArray());
            this.ExecuteJS(snippet);
            return new CodeSnippet(newCodeHeader, string.Empty, new object[0]);
        }

        internal static CodeSnippet GetGetPropertyJSSnippet(CodeSnippet dependedScript, string property, Type returnType, string header = null)
        {
            string str = dependedScript.Snippet;
            string expectedHeader = string.IsNullOrEmpty(header) ? "propertyValue" : header;
            expectedHeader = GetTempNewCodeHeader(expectedHeader);
            string str3 = str;
            str = str3 + "var " + expectedHeader + " = " + dependedScript.CodeHeader + "." + property + ";";
            if (returnType != null)
            {
                CodeSnippet formatCode = JSConverterBase.GetTypeConverter(returnType).GetFormatCode(expectedHeader);
                str = (str + formatCode.Snippet) + "return " + formatCode.CodeHeader + ";";
            }
            return new CodeSnippet(expectedHeader, str, dependedScript.Args.ToArray());
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public virtual CodeSnippet GetInvokeJSSnippet(string method, string header = null, params object[] args)
        {
            return GetInvokeJSSnippet(this.DependedScript, method, null, header, args);
        }

        internal static CodeSnippet GetInvokeJSSnippet(CodeSnippet dependedScript, string method, Type returnType, string header, params object[] args)
        {
            List<object> list = new List<object>();
            list.AddRange(dependedScript.Args);
            string str = dependedScript.Snippet;
            List<IJSConverter> list2 = new List<IJSConverter>();
            if (args != null)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    list2.Add(JSConverterBase.GetTypeConverter(args[i]));
                }
            }
            string str2 = string.Empty;
            if (list2.Count > 0)
            {
                for (int j = 0; j < list2.Count; j++)
                {
                    CodeSnippet snippet = list2[j].ConvertToJavaScript(args[j], "param" + (j + 1));
                    str2 = str2 + (string.IsNullOrEmpty(str2) ? string.Empty : ", ") + snippet.CodeHeader;
                    str = str + snippet.Snippet;
                    list.AddRange(snippet.Args);
                }
            }
            string expectedHeader = string.IsNullOrEmpty(header) ? "returnValue" : header;
            expectedHeader = GetTempNewCodeHeader(expectedHeader);
            string str4 = string.IsNullOrWhiteSpace(method) ? string.Empty : ("." + method);
            string str5 = str;
            str = str5 + "var " + expectedHeader + " = " + dependedScript.CodeHeader + str4 + "(" + str2 + ");";
            if (returnType != null)
            {
                CodeSnippet formatCode = JSConverterBase.GetTypeConverter(returnType).GetFormatCode(expectedHeader);
                str = (str + formatCode.Snippet) + "return " + formatCode.CodeHeader + ";";
            }
            return new CodeSnippet(expectedHeader, str, list.ToArray());
        }

        public virtual T GetJSProperty<T>(string property)
        {
            if (typeof(DomElementGUI).IsAssignableFrom(typeof(T)))
            {
                object obj2 = this.GetJSProperty(property, typeof(IWebElement));
                if (obj2 != null)
                {
                    return TestUtility.CreateInstance<T>(null, obj2 as IWebElement, null, new object[0]);
                }
                return default(T);
            }
            if (typeof(ExecutableObject).IsAssignableFrom(typeof(T)))
            {
                return TestUtility.CreateInstance<T>(this.GetJSPropertyJSSnippet(property, null), null, null, new object[0]);
            }
            if (typeof(CodeSnippet).IsAssignableFrom(typeof(T)))
            {
                return (T) this.GetExecutedJSSnippet(this.GetJSPropertyJSSnippet(property, null), null);
            }
            Type propertyType = typeof(T);
            object jSProperty = this.GetJSProperty(property, propertyType);
            if (typeof(IList).IsAssignableFrom(propertyType) && !JSConverterBase.HasTypeConverter(propertyType))
            {
                return (JSConverterBase.GetTypeConverter(typeof(IList)) as IListJSConverter).AsTo<T>(jSProperty);
            }
            return (T) jSProperty;
        }

        protected virtual object GetJSProperty(string property, Type propertyType)
        {
            CodeSnippet executeCode = GetGetPropertyJSSnippet(this.DependedScript, property, propertyType, string.Empty);
            object obj2 = this.ExecuteJS(executeCode);
            return JSConverterBase.GetTypeConverter(propertyType).ConvertToCShapeType(obj2);
        }

        public virtual CodeSnippet GetJSPropertyJSSnippet(string property, string header = null)
        {
            return GetGetPropertyJSSnippet(this.DependedScript, property, null, header);
        }

        internal static string GetNewCodeHeader(string expectedHeader = null)
        {
            string item = string.IsNullOrEmpty(expectedHeader) ? "refObject" : expectedHeader;
            if (_refCodeHeaderNameList == null)
            {
                bool isNullValue = Manager.Current.ActiveBrowser.BuildInTestObj.IsNullValue;
                _refCodeHeaderNameList = new List<string>();
            }
            item = item + ((_refCodeHeaderNameList.Count + 1)).ToString();
            _refCodeHeaderNameList.Add(item);
            return ("window.GrapeCityAutoTest.TestObjects." + item);
        }

        internal static CodeSnippet GetSetPropertyJSSnippet(CodeSnippet dependedScript, string property, object value)
        {
            string str = dependedScript.Snippet;
            CodeSnippet snippet = JSConverterBase.GetTypeConverter(value).ConvertToJavaScript(value, "value1");
            string str2 = string.IsNullOrWhiteSpace(property) ? string.Empty : ("." + property);
            string str3 = str + snippet.Snippet;
            return new CodeSnippet(dependedScript.CodeHeader, str3 + dependedScript.CodeHeader + str2 + " = " + snippet.CodeHeader + ";", dependedScript.Args.ToArray());
        }

        private static string GetTempNewCodeHeader(string expectedHeader = null)
        {
            string str = string.IsNullOrEmpty(expectedHeader) ? "refObject" : expectedHeader;
            _tempCodeHeaderNameID++;
            int num = _tempCodeHeaderNameID + 1;
            return (str + num.ToString());
        }

        protected virtual void Initization()
        {
        }

        protected virtual string InjectDPDetection()
        {
            return string.Format("if(!window.GrapeCityAutoTest)return '{0}:ATTestCore';", "InjectDP");
        }

        protected virtual void InjectionDependency(DependencyInjectionContext context)
        {
            if (context.InjectDP.Contains("ATTestCore"))
            {
                ClearCodeHeaderManager();
                string jSFromResourcesFile = FileHelper.GetJSFromResourcesFile("Web.test.core.js");
                if (Manager.IgnoreAssertAlertDialog)
                {
                    jSFromResourcesFile = jSFromResourcesFile + (MockAlert.IsAcceptAlert ? MockAlert.MockAlertScript : MockAlert.MockDismissAlertScript);
                }
                ExecuteScript(jSFromResourcesFile, new object[0]);
                context.InjectSucess = true;
                if (Manager.WatchJavaScriptError)
                {
                    Manager.Current.ErrorWatcher.StartWatchError();
                }
            }
        }

        internal static void InjectJS(string src)
        {
            if (!string.IsNullOrWhiteSpace(src))
            {
                int length = src.Length;
                int startIndex = 0;
                List<string> list = new List<string>();
                while ((length - startIndex) > 0)
                {
                    int num3 = 0xc350;
                    if ((startIndex + num3) > length)
                    {
                        list.Add(src.Substring(startIndex));
                    }
                    else
                    {
                        list.Add(src.Substring(startIndex, num3));
                    }
                    startIndex += num3;
                }
                ExecutableObject str = new ExecutableObject(new CodeSnippet(GetNewCodeHeader("jsStr"), string.Empty, new object[0]));
                CodeSnippet dependedScript = str.DependedScript;
                for (int i = 0; i < list.Count; i++)
                {
                    CodeSnippet snippet2 = JSConverterBase.GetTypeConverter(typeof(string)).ConvertToJavaScript(list[i], "jsTempStr" + i);
                    string snippet = snippet2.Snippet + string.Format("{0} = {0} + {1};", dependedScript.CodeHeader, snippet2.CodeHeader);
                    if (i == 0)
                    {
                        snippet = string.Format("{0} = '';", dependedScript.CodeHeader) + snippet;
                    }
                    str.ExecuteJS(new CodeSnippet(dependedScript.CodeHeader, snippet, new object[0]));
                }
                new Window().eval(str);
                str.ReleaseJSObject();
            }
        }

        internal static CodeSnippet InnerGetCtorJSSnippet(string typeFullName, string header = null, params object[] args)
        {
            List<object> list = new List<object>();
            string str = string.Empty;
            List<IJSConverter> list2 = new List<IJSConverter>();
            if (args != null)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    list2.Add(JSConverterBase.GetTypeConverter(args[i]));
                }
            }
            string str2 = string.Empty;
            if (list2.Count > 0)
            {
                for (int j = 0; j < list2.Count; j++)
                {
                    CodeSnippet snippet = list2[j].ConvertToJavaScript(args[j], "param" + (j + 1));
                    str2 = str2 + (string.IsNullOrEmpty(str2) ? string.Empty : ", ") + snippet.CodeHeader;
                    str = str + snippet.Snippet;
                    list.AddRange(snippet.Args);
                }
            }
            string newCodeHeader = GetNewCodeHeader(header);
            str = str + string.Format("{0} = new {1}({2});", newCodeHeader, typeFullName, str2);
            new ExecutableObject(null).ExecuteJS(new CodeSnippet(newCodeHeader, str, new object[] { list }));
            return new CodeSnippet(newCodeHeader, string.Empty, new object[0]);
        }

        internal static CodeSnippet InnerGetEmptyCtorJSSnippet(string typeFullName, string header = null)
        {
            return InnerGetCtorJSSnippet(typeFullName, header, new object[0]);
        }

        public virtual void InvokeJSMehtod(string method, params object[] args)
        {
            this.InvokeJSMehtod(method, null, args);
        }

        public virtual T InvokeJSMehtod<T>(string method, params object[] args)
        {
            if (typeof(DomElementGUI).IsAssignableFrom(typeof(T)))
            {
                object obj2 = this.InvokeJSMehtod(method, typeof(IWebElement), args);
                if (obj2 != null)
                {
                    return TestUtility.CreateInstance<T>(null, obj2 as IWebElement, null, new object[0]);
                }
                return default(T);
            }
            if (typeof(ExecutableObject).IsAssignableFrom(typeof(T)))
            {
                return TestUtility.CreateInstance<T>(this.GetInvokeJSSnippet(method, string.Empty, args), null, null, new object[0]);
            }
            if (typeof(CodeSnippet).IsAssignableFrom(typeof(T)))
            {
                return (T) this.GetExecutedJSSnippet(this.GetInvokeJSSnippet(method, null, args), null);
            }
            Type returnType = typeof(T);
            object obj3 = this.InvokeJSMehtod(method, returnType, args);
            if (typeof(IList).IsAssignableFrom(returnType) && !JSConverterBase.HasTypeConverter(returnType))
            {
                return (JSConverterBase.GetTypeConverter(typeof(IList)) as IListJSConverter).AsTo<T>(obj3);
            }
            return (T) obj3;
        }

        protected virtual object InvokeJSMehtod(string method, Type returnType, params object[] args)
        {
            CodeSnippet executeCode = GetInvokeJSSnippet(this.DependedScript, method, returnType, string.Empty, args);
            object obj2 = this.ExecuteJS(executeCode);
            if (returnType != null)
            {
                return JSConverterBase.GetTypeConverter(returnType).ConvertToCShapeType(obj2);
            }
            return obj2;
        }

        public virtual bool IsNullJSObject(CodeSnippet code)
        {
            return IsNullReturnValue(code);
        }

        internal static bool IsNullReturnValue(CodeSnippet code)
        {
            return Manager.Current.ActiveBrowser.BuildInTestObj.InvokeJSMehtod<bool>("isNullOrUndefined", new object[] { code });
        }

        public static bool operator ==(ExecutableObject left, ExecutableObject right)
        {
            return object.Equals(left, right);
        }

        public static bool operator !=(ExecutableObject left, ExecutableObject right)
        {
            return !object.Equals(left, right);
        }

        public virtual void Perform()
        {
            this.ExecuteJS(this.DependedScript);
        }

        public virtual void ReleaseJSObject()
        {
            if (string.IsNullOrEmpty(this.DependedScript.Snippet))
            {
                this.SetJSProperty("", null);
            }
        }

        public virtual void SetJSProperty(string property, object value)
        {
            CodeSnippet executeCode = GetSetPropertyJSSnippet(this.DependedScript, property, value);
            this.ExecuteJS(executeCode);
        }

        public CodeSnippet DependedScript
        {
            get
            {
                return this.GetDependedScript();
            }
            set
            {
                this._dependedScript = value;
            }
        }

        public bool IsNullValue
        {
            get
            {
                return this.IsNullJSObject(this.DependedScript);
            }
        }

        public ShouldJSObject should
        {
            get
            {
                ShouldJSObject jSProperty = this.GetJSProperty<ShouldJSObject>("should");
                if ((jSProperty != null) && !jSProperty.IsNullValue)
                {
                    return jSProperty;
                }
                return new ShouldJSObject(this);
            }
        }

        protected IWebDriver WebDriver
        {
            get
            {
                return Manager.Current.ActiveBrowser.WebDriver;
            }
        }

        protected class DependencyInjectionContext
        {
            public DependencyInjectionContext(string injectDP)
            {
                this.InjectDP = injectDP;
            }

            public string InjectDP { get; set; }

            public bool InjectSucess { get; set; }
        }
    }
}

