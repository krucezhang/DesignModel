﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit;
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class FileSaverObject : ExecutableObject
    {
        public FileSaverObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        protected override string InjectDPDetection()
        {
            return (base.InjectDPDetection() + string.Format("if(!window.saveAs)return '{0}:FileSaverJS';", "InjectDP"));
        }

        protected override void InjectionDependency(ExecutableObject.DependencyInjectionContext context)
        {
            base.InjectionDependency(context);
            if (context.InjectDP.Contains("FileSaverJS"))
            {
                ExecutableObject.ExecuteScript(FileHelper.GetJSFromResourcesFile("FileSaver.min.js"), new object[0]);
                context.InjectSucess = true;
            }
        }

        public void saveAs(ExecutableObject blob, string fileName = null)
        {
            List<object> list = new List<object> {
                blob
            };
            if (!string.IsNullOrEmpty(fileName))
            {
                list.Add(fileName);
            }
            this.InvokeJSMehtod("saveAs", list.ToArray());
        }
    }
}

