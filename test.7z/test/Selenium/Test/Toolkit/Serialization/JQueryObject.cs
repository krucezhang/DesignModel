﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit;
    using System;
    using System.Drawing;

    public class JQueryObject : ExecutableObject
    {
        public JQueryObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public JQueryObject append(string content)
        {
            return this.InvokeJSMehtod<JQueryObject>("append", new object[] { content });
        }

        public string attr(string attributeName)
        {
            return this.InvokeJSMehtod<string>("attr", new object[] { attributeName });
        }

        public T attr<T>(string attributeName)
        {
            return this.InvokeJSMehtod<T>("attr", new object[] { attributeName });
        }

        public void attr(string attributeName, object value)
        {
            this.InvokeJSMehtod("attr", new object[] { attributeName, value });
        }

        public void click()
        {
            this.InvokeJSMehtod("click", new object[0]);
        }

        public JQueryObject css(string propertyName, object value)
        {
            return this.InvokeJSMehtod<JQueryObject>("css", new object[] { propertyName, value });
        }

        public JQueryObject empty()
        {
            return this.InvokeJSMehtod<JQueryObject>("empty", new object[0]);
        }

        public JQueryObject find(string selector)
        {
            return this.InvokeJSMehtod<JQueryObject>("find", new object[] { selector });
        }

        public void focus()
        {
            this.InvokeJSMehtod("focus", new object[0]);
        }

        protected override CodeSnippet GetDependedScript()
        {
            CodeSnippet dependedScript = base.GetDependedScript();
            if (dependedScript != null)
            {
                dependedScript = new CodeSnippet("jQElement1", dependedScript.Snippet + string.Format("var jQElement1 = $({0});", dependedScript.CodeHeader), dependedScript.Args.ToArray());
            }
            return dependedScript;
        }

        public int height()
        {
            return this.InvokeJSMehtod<int>("height", new object[0]);
        }

        public JQueryObject height(double value)
        {
            return this.InvokeJSMehtod<JQueryObject>("height", new object[] { value });
        }

        public string html()
        {
            return this.InvokeJSMehtod<string>("html", new object[0]);
        }

        protected override string InjectDPDetection()
        {
            return (base.InjectDPDetection() + string.Format("if(!window.jQuery)return '{0}:JQueryJS';", "InjectDP"));
        }

        protected override void InjectionDependency(ExecutableObject.DependencyInjectionContext context)
        {
            base.InjectionDependency(context);
            if (context.InjectDP.Contains("JQueryJS"))
            {
                ExecutableObject.ExecuteScript(FileHelper.GetJSFromResourcesFile("jquery.min.js"), new object[0]);
                context.InjectSucess = true;
            }
        }

        public int innerHeight()
        {
            return this.InvokeJSMehtod<int>("innerHeight", new object[0]);
        }

        public int innerWidth()
        {
            return this.InvokeJSMehtod<int>("innerWidth", new object[0]);
        }

        public bool Is(string selector)
        {
            return this.InvokeJSMehtod<bool>("is", new object[0]);
        }

        public ArrayObject<DomElementGUI> next()
        {
            return this.InvokeJSMehtod<ArrayObject<DomElementGUI>>("next", new object[0]);
        }

        public Point offset()
        {
            return this.InvokeJSMehtod<Point>("offset", new object[0]);
        }

        public int outerHeight()
        {
            return this.InvokeJSMehtod<int>("outerHeight", new object[0]);
        }

        public int outerHeight(bool includeMargin)
        {
            return this.InvokeJSMehtod<int>("outerHeight", new object[] { includeMargin });
        }

        public int outerWidth()
        {
            return this.InvokeJSMehtod<int>("outerWidth", new object[0]);
        }

        public int outerWidth(bool includeMargin)
        {
            return this.InvokeJSMehtod<int>("outerWidth", new object[] { includeMargin });
        }

        public Point position()
        {
            return this.InvokeJSMehtod<Point>("position", new object[0]);
        }

        public ArrayObject<DomElementGUI> prev()
        {
            return this.InvokeJSMehtod<ArrayObject<DomElementGUI>>("prev", new object[0]);
        }

        public void remove()
        {
            this.InvokeJSMehtod("remove", new object[0]);
        }

        public int scrollLeft()
        {
            return this.InvokeJSMehtod<int>("scrollLeft", new object[0]);
        }

        public void scrollLeft(int value)
        {
            this.InvokeJSMehtod("scrollLeft", new object[] { value });
        }

        public int scrollTop()
        {
            return this.InvokeJSMehtod<int>("scrollTop", new object[0]);
        }

        public void scrollTop(int value)
        {
            this.InvokeJSMehtod("scrollTop", new object[] { value });
        }

        public string text()
        {
            return this.InvokeJSMehtod<string>("text", new object[0]);
        }

        public void trigger(string eventType)
        {
            this.InvokeJSMehtod("trigger", new object[] { eventType });
        }

        public void triggerHandler(string eventType)
        {
            this.InvokeJSMehtod("triggerHandler", new object[] { eventType });
        }

        public int width()
        {
            return this.InvokeJSMehtod<int>("width", new object[0]);
        }

        public JQueryObject width(double value)
        {
            return this.InvokeJSMehtod<JQueryObject>("width", new object[] { value });
        }
    }
}

