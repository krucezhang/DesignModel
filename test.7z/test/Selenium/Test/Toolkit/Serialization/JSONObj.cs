﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;
    using System.Runtime.CompilerServices;

    public class JSONObj
    {
        public JSONObj(string jsonString)
        {
            this.JSONString = jsonString;
        }

        public string JSONString { get; private set; }
    }
}

