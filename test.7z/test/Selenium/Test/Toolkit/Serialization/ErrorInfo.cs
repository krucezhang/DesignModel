﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;

    public class ErrorInfo : JSObject
    {
        public ErrorInfo(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public int Column
        {
            get
            {
                return this.GetJSProperty<int>("Column");
            }
        }

        public Selenium.Test.Toolkit.Serialization.ErrorObject ErrorObject
        {
            get
            {
                return this.GetJSProperty<Selenium.Test.Toolkit.Serialization.ErrorObject>("ErrorObject");
            }
        }

        public int Line
        {
            get
            {
                return this.GetJSProperty<int>("Line");
            }
        }

        public string Message
        {
            get
            {
                return this.GetJSProperty<string>("Message");
            }
        }

        public string URL
        {
            get
            {
                return this.GetJSProperty<string>("URL");
            }
        }
    }
}

