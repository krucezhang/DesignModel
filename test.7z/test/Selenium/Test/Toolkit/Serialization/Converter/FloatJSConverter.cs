﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class FloatJSConverter : DoubleJSConverter
    {
        public override object ConvertToCShapeType(object value)
        {
            return Convert.ToSingle(base.ConvertToCShapeType(value));
        }

        public override Type TargetType
        {
            get
            {
                return typeof(float);
            }
        }
    }
}

