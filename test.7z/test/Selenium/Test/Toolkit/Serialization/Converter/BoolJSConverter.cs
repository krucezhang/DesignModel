﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class BoolJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            if (value == null)
            {
                return false;
            }
            return base.ConvertToCShapeType(value);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(bool);
            }
        }
    }
}

