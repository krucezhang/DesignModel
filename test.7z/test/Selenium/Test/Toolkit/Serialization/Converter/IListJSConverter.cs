﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class IListJSConverter : JSConverterBase
    {
        public T AsTo<T>(object value)
        {
            if (value == null)
            {
                return default(T);
            }
            if (value is T)
            {
                return (T) value;
            }
            if (!typeof(IList).IsAssignableFrom(value.GetType()) || !typeof(IList).IsAssignableFrom(typeof(T)))
            {
                throw new InvalidProgramException(string.Format("Can't convert object[{0}] to specify type[{1}].", value.GetType().FullName, typeof(T).FullName));
            }
            Type conversionType = typeof(object);
            if (typeof(T).IsGenericType)
            {
                conversionType = typeof(T).GetGenericArguments()[0];
            }
            IList list = (IList) value;
            IList list2 = (IList) Activator.CreateInstance(typeof(T));
            bool flag = false;
            Type c = null;
            foreach (object obj2 in list)
            {
                if (c == null)
                {
                    c = obj2.GetType();
                    if (conversionType.IsAssignableFrom(c))
                    {
                        flag = true;
                    }
                }
                list2.Add(flag ? obj2 : Convert.ChangeType(obj2, conversionType));
            }
            return (T) list2;
        }

        public override object ConvertToCShapeType(object value)
        {
            IList ownerlist = new List<object>();
            this.SerlizationListObject(value, ownerlist);
            return ownerlist;
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "ArrayList1" : header;
            IList list = value as IList;
            if (list == null)
            {
                return JSConverterBase.GetTypeConverter(list).ConvertToJavaScript(list, str);
            }
            string str2 = null;
            string str3 = null;
            for (int i = 0; i < list.Count; i++)
            {
                string str4 = "item" + (i + 1);
                object obj2 = list[i];
                IJSConverter typeConverter = JSConverterBase.GetTypeConverter(obj2);
                if (typeConverter is IListJSConverter)
                {
                    str4 = "childArray" + (i + 1);
                }
                CodeSnippet snippet = typeConverter.ConvertToJavaScript(obj2, str4);
                str3 = str3 + (string.IsNullOrEmpty(str3) ? string.Empty : ", ") + snippet.CodeHeader;
                str2 = str2 + snippet.Snippet;
            }
            string str5 = str2;
            return new CodeSnippet(str, str5 + "var " + str + " = [" + str3 + "];", new object[0]);
        }

        protected virtual void SerlizationListObject(object value, IList ownerlist)
        {
            IList list = value as IList;
            if (list != null)
            {
                IList list2 = ownerlist;
                for (int i = 1; i < list.Count; i++)
                {
                    if (list[i] is IList)
                    {
                        IList list3 = new List<object>();
                        list2.Add(list3);
                        this.SerlizationListObject(list[i], list3);
                    }
                    else
                    {
                        IJSConverter typeConverter = null;
                        try
                        {
                            typeConverter = JSConverterBase.GetTypeConverter(list[i]);
                        }
                        catch
                        {
                        }
                        if (typeConverter != null)
                        {
                            list2.Add(typeConverter.ConvertToCShapeType(list[i]));
                        }
                        else
                        {
                            list2.Add(list[i]);
                        }
                    }
                }
            }
        }

        public override Type TargetType
        {
            get
            {
                return typeof(IList);
            }
        }
    }
}

