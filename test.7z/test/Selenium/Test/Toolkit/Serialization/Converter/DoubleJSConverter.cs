﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class DoubleJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            return Convert.ToDouble(base.ConvertToCShapeType(value));
        }

        public override Type TargetType
        {
            get
            {
                return typeof(double);
            }
        }
    }
}

