﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class KeyValuePairJSConverter : JSConverterBase
    {
        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            Type[] keyVlueType = this.KeyVlueType;
            string str = string.IsNullOrEmpty(header) ? "keyValuePair1" : header;
            string str2 = null;
            CodeSnippet snippet = JSConverterBase.GetTypeConverter(keyVlueType[0]).ConvertToJavaScript(this.OriginalType.GetProperty("Key").GetValue(value, null), "key1");
            str2 = str2 + snippet.Snippet;
            CodeSnippet snippet2 = JSConverterBase.GetTypeConverter(keyVlueType[1]).ConvertToJavaScript(this.OriginalType.GetProperty("Value").GetValue(value, null), "value1");
            return new CodeSnippet(str, str2 + snippet2.Snippet + string.Format("var {0} = {1};", str, "{" + string.Format("key:{0}, value:{1}", snippet.CodeHeader, snippet2.CodeHeader) + "}"), new object[0]);
        }

        public Type[] KeyVlueType
        {
            get
            {
                if (this.OriginalType == null)
                {
                    throw new InvalidProgramException("OriginalType is Null.");
                }
                if (this.OriginalType.IsGenericType)
                {
                    Type[] genericArguments = this.OriginalType.GetGenericArguments();
                    if (genericArguments.Length >= 2)
                    {
                        return genericArguments;
                    }
                }
                return new Type[] { typeof(object), typeof(object) };
            }
        }

        public override Type TargetType
        {
            get
            {
                return typeof(KeyValuePair<,>);
            }
        }
    }
}

