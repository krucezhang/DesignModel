﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;

    public class ObjectJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            if (value is IList)
            {
                IList list = value as IList;
                if ((list.Count > 0) && (list[0].ToString().ToLower() == typeof(DateTime).FullName.ToLower()))
                {
                    return new DateTimeJSConverter().ConvertToCShapeType(value);
                }
            }
            return base.ConvertToCShapeType(value);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            if (value is DateTime)
            {
                return new DateTimeJSConverter().ConvertToJavaScript(value, header);
            }
            return base.ConvertToJavaScript(value, header);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(object);
            }
        }
    }
}

