﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class DecimalJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            return Convert.ToDecimal(base.ConvertToCShapeType(value));
        }

        public override Type TargetType
        {
            get
            {
                return typeof(decimal);
            }
        }
    }
}

