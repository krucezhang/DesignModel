﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class Int32JSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            return Convert.ToInt32(base.ConvertToCShapeType(value));
        }

        public override Type TargetType
        {
            get
            {
                return typeof(int);
            }
        }
    }
}

