﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Drawing;
    using System.Runtime.InteropServices;

    public class RectangleJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            IList list = value as IList;
            object[] args = new object[list.Count - 1];
            for (int i = 1; i < list.Count; i++)
            {
                args[i - 1] = Convert.ToInt32(list[i]);
            }
            return Activator.CreateInstance(this.TargetType, args);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "rect1" : header;
            Rectangle rectangle = (Rectangle) value;
            return new CodeSnippet(str, string.Format("\r\n                    var {0} = {1};\r\n                ", str, "{" + string.Format("x:{0},y:{1},width:{2},height:{3}", new object[] { rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height }) + "}"), new object[0]);
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            return new CodeSnippet("formatObj", "var formatObj = window.GrapeCityAutoTest.parseRect(" + codeHeader + ");", new object[0]);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(Rectangle);
            }
        }
    }
}

