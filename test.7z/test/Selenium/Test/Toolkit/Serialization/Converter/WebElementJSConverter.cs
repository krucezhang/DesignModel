﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.InteropServices;

    public class WebElementJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            return value;
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            ExecutableObject obj2 = new ExecutableObject(null);
            string newCodeHeader = ExecutableObject.GetNewCodeHeader(header);
            string str2 = string.Format("{0} = arguments[0];", newCodeHeader);
            CodeSnippet executeCode = new CodeSnippet(newCodeHeader, str2, new object[] { value });
            obj2.ExecuteJS(executeCode);
            return new CodeSnippet(executeCode.CodeHeader, string.Empty, new object[0]);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(IWebElement);
            }
        }
    }
}

