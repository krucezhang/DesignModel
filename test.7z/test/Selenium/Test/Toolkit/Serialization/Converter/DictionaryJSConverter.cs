﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;

    public class DictionaryJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            if (value == null)
            {
                return null;
            }
            IDictionary dictionary = (IDictionary) Activator.CreateInstance(this.OriginalType);
            IList list = value as IList;
            if (list != null)
            {
                Type[] keyVlueType = this.KeyVlueType;
                Func<object, object> func = new Func<object, object>(this.ConvertToCShapeType);
                Func<object, object> func2 = new Func<object, object>(this.ConvertToCShapeType);
                try
                {
                    IJSConverter typeConverter = JSConverterBase.GetTypeConverter(keyVlueType[0]);
                    func = new Func<object, object>(typeConverter.ConvertToCShapeType);
                }
                catch
                {
                }
                try
                {
                    IJSConverter converter2 = JSConverterBase.GetTypeConverter(keyVlueType[1]);
                    func2 = new Func<object, object>(converter2.ConvertToCShapeType);
                }
                catch
                {
                }
                for (int i = 1; i < list.Count; i++)
                {
                    IDictionary dictionary2 = list[i] as IDictionary;
                    object key = func(dictionary2["key"]);
                    if (!dictionary.Contains(key))
                    {
                        dictionary.Add(key, func2(dictionary2["value"]));
                    }
                }
            }
            return dictionary;
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            throw new NotImplementedException("Not implement Dictionary to javescript converter.");
        }

        public Type[] KeyVlueType
        {
            get
            {
                if (this.OriginalType == null)
                {
                    throw new InvalidProgramException("OriginalType is Null.");
                }
                if (this.OriginalType.IsGenericType)
                {
                    Type[] genericArguments = this.OriginalType.GetGenericArguments();
                    if (genericArguments.Length >= 2)
                    {
                        return genericArguments;
                    }
                }
                return new Type[] { typeof(object), typeof(object) };
            }
        }

        public override Type TargetType
        {
            get
            {
                return typeof(IDictionary);
            }
        }

        public Type ValueType
        {
            get
            {
                if (this.OriginalType == null)
                {
                    throw new InvalidProgramException("OriginalType is Null.");
                }
                if (this.OriginalType.IsGenericType)
                {
                    Type[] genericArguments = this.OriginalType.GetGenericArguments();
                    if (genericArguments.Length >= 2)
                    {
                        return genericArguments[1];
                    }
                }
                return typeof(object);
            }
        }
    }
}

