﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public abstract class JSConverterBase : IJSConverter
    {
        private static bool IsInitializeBasicTypeConverter;
        private static Dictionary<Type, IJSConverter> JSConverterDic;

        protected JSConverterBase()
        {
        }

        public virtual object ConvertToCShapeType(object value)
        {
            if ((value is int) || (value is short))
            {
                return Convert.ToInt32(value);
            }
            if ((value != null) && (value is string))
            {
                string str = value as string;
                if (str.StartsWith("GCATString_"))
                {
                    return str.Replace("GCATString_", string.Empty);
                }
            }
            return value;
        }

        public virtual CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "value1" : header;
            if (value == null)
            {
                return new CodeSnippet(str, "var " + str + " = null;", new object[0]);
            }
            if (((value is int) || (value is double)) || ((value is decimal) || (value is float)))
            {
                return new CodeSnippet(str, "var " + str + " = " + value.ToString() + ";", new object[0]);
            }
            if ((value is string) || (value is Enum))
            {
                return new CodeSnippet(str, "var " + str + " = '" + parserString(value.ToString()) + "';", new object[0]);
            }
            if (!(value is bool))
            {
                throw new NotSupportedException(string.Format("Don't support convert the [{0}] type to JavaScript.", value.GetType().FullName));
            }
            return new CodeSnippet(str, "var " + str + " = " + value.ToString().ToLower() + ";", new object[0]);
        }

        public virtual CodeSnippet GetFormatCode(string codeHeader)
        {
            return new CodeSnippet("formatObj", "var formatObj = window.GrapeCityAutoTest.parser(" + codeHeader + ");", new object[0]);
        }

        public static CodeSnippet GetJSCodeSnippet(object value, string header = null)
        {
            return GetTypeConverter(value).ConvertToJavaScript(value, header);
        }

        public static IJSConverter GetTypeConverter(object value)
        {
            Type type = typeof(Nullable);
            if (value != null)
            {
                type = value.GetType();
            }
            if (value is IWebElement)
            {
                type = typeof(IWebElement);
            }
            if (value is IExecutable)
            {
                type = typeof(CodeSnippet);
            }
            return GetTypeConverter(type);
        }

        public static IJSConverter GetTypeConverter(Type type)
        {
            IJSConverter converter;
            if (type == null)
            {
                throw new ArgumentNullException("GetTypeConverter args is null.");
            }
            Type type2 = type;
            if (!IsInitializeBasicTypeConverter)
            {
                SearchConverterFromAssembly(typeof(IJSConverter).Assembly);
                IsInitializeBasicTypeConverter = true;
            }
            if (type.IsEnum && !HasTypeConverter(type))
            {
                type = typeof(Enum);
            }
            if (type.IsGenericType && (type.GetGenericTypeDefinition() == typeof(Nullable<>)))
            {
                type = typeof(Nullable<>);
            }
            if ((type.IsGenericType && type.IsValueType) && (type.GetGenericTypeDefinition() == typeof(KeyValuePair<,>)))
            {
                type = typeof(KeyValuePair<,>);
            }
            if (typeof(IList).IsAssignableFrom(type) && !HasTypeConverter(type))
            {
                type = typeof(IList);
            }
            if (typeof(IDictionary).IsAssignableFrom(type) && !HasTypeConverter(type))
            {
                type = typeof(IDictionary);
            }
            if (!JSConverterDic.TryGetValue(type, out converter))
            {
                throw new NotSupportedException(string.Format("Don't find JSConverter for the [{0}] type.", type.FullName));
            }
            converter.OriginalType = type2;
            return converter;
        }

        public static bool HasTypeConverter(Type type)
        {
            if (!IsInitializeBasicTypeConverter)
            {
                GetTypeConverter(typeof(int));
            }
            return JSConverterDic.ContainsKey(type);
        }

        public static string parserString(string str)
        {
            string str2 = str;
            return str2.Replace(@"\", @"\\").Replace("\"", "\\\"").Replace("'", @"\'").Replace("\r", @"\r").Replace("\n", @"\n");
        }

        internal static void SearchConverterFromAssembly(Assembly assembly)
        {
            if (JSConverterDic == null)
            {
                JSConverterDic = new Dictionary<Type, IJSConverter>();
            }
            foreach (Type type in assembly.GetTypes())
            {
                if ((type.IsClass && typeof(IJSConverter).IsAssignableFrom(type)) && (!type.IsAbstract && (type.GetConstructor(new Type[0]) != null)))
                {
                    IJSConverter converter = Activator.CreateInstance(type) as IJSConverter;
                    if (JSConverterDic.ContainsKey(converter.TargetType))
                    {
                        JSConverterDic[converter.TargetType] = converter;
                    }
                    else
                    {
                        JSConverterDic.Add(converter.TargetType, converter);
                    }
                }
            }
        }

        public virtual Type OriginalType { get; set; }

        public virtual Type TargetType
        {
            get
            {
                if (this.OriginalType == null)
                {
                    throw new InvalidProgramException("Unknow TargetType for one JSConverter.");
                }
                return this.OriginalType;
            }
        }
    }
}

