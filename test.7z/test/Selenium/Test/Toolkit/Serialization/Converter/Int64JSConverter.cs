﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class Int64JSConverter : Int32JSConverter
    {
        public override object ConvertToCShapeType(object value)
        {
            return Convert.ToInt64(base.ConvertToCShapeType(value));
        }

        public override Type TargetType
        {
            get
            {
                return typeof(long);
            }
        }
    }
}

