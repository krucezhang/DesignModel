﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.InteropServices;

    public class CodeSnippetJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            throw new InvalidProgramException("CodeSnippetJSConverter don't provider convert logic from javaScript object to CSharp object.");
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            if (value is IExecutable)
            {
                return (value as IExecutable).DependedScript;
            }
            return (CodeSnippet) value;
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            throw new InvalidProgramException("CodeSnippetJSConverter don't provider javaScript format code.");
        }

        public override Type TargetType
        {
            get
            {
                return typeof(CodeSnippet);
            }
        }
    }
}

