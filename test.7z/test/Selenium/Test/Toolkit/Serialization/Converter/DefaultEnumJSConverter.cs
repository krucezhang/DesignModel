﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.InteropServices;

    public class DefaultEnumJSConverter : JSConverterBase
    {
        private Int32JSConverter _converter;

        public override object ConvertToCShapeType(object value)
        {
            if (this.OriginalType.GetCustomAttributes(typeof(EnumStringAttribute), false).Length > 0)
            {
                return Enum.Parse(this.OriginalType, (string) value, true);
            }
            return this.Int32Converter.ConvertToCShapeType(value);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            if (this.OriginalType.GetCustomAttributes(typeof(EnumStringAttribute), false).Length > 0)
            {
                return base.ConvertToJavaScript(Enum.GetName(this.OriginalType, value), header);
            }
            return this.Int32Converter.ConvertToJavaScript((int) value, header);
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            return this.Int32Converter.GetFormatCode(codeHeader);
        }

        protected Int32JSConverter Int32Converter
        {
            get
            {
                if (this._converter == null)
                {
                    this._converter = new Int32JSConverter();
                }
                return this._converter;
            }
        }

        public override Type TargetType
        {
            get
            {
                return typeof(Enum);
            }
        }
    }
}

