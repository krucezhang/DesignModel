﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public interface IJSConverter
    {
        object ConvertToCShapeType(object value);
        CodeSnippet ConvertToJavaScript(object value, string header);
        CodeSnippet GetFormatCode(string codeHeader);

        Type OriginalType { get; set; }

        Type TargetType { get; }
    }
}

