﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class StringJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            object obj2 = base.ConvertToCShapeType(value);
            if (obj2 == null)
            {
                return null;
            }
            return Convert.ToString(obj2);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(string);
            }
        }
    }
}

