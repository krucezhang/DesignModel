﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using System;

    public class NullJSConverter : JSConverterBase
    {
        public override Type TargetType
        {
            get
            {
                return typeof(Nullable);
            }
        }
    }
}

