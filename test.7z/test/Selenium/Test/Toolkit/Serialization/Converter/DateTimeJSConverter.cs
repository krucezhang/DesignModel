﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;

    public class DateTimeJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            IList list = value as IList;
            object[] args = new object[list.Count - 1];
            for (int i = 1; i < list.Count; i++)
            {
                args[i - 1] = Convert.ToInt32(list[i]);
            }
            return Activator.CreateInstance(typeof(DateTime), args);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "date1" : header;
            DateTime time = (DateTime) value;
            return new CodeSnippet(str, string.Format("var {0} = new Date({1}, {2}, {3}, {4}, {5}, {6}, {7});", new object[] { str, time.Year, time.Month - 1, time.Day, time.Hour, time.Minute, time.Second, time.Millisecond }), new object[0]);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(DateTime);
            }
        }
    }
}

