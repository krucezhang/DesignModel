﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Runtime.InteropServices;

    public class NullableJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            if (value == null)
            {
                return value;
            }
            return JSConverterBase.GetTypeConverter(this.UnderlyingType).ConvertToCShapeType(value);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            if ((value != null) && ((bool) this.OriginalType.GetProperty("HasValue").GetValue(value, null)))
            {
                return JSConverterBase.GetTypeConverter(this.UnderlyingType).ConvertToJavaScript(this.OriginalType.GetProperty("Value").GetValue(value, null), header);
            }
            return new NullJSConverter().ConvertToJavaScript(null, null);
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            return JSConverterBase.GetTypeConverter(this.UnderlyingType).GetFormatCode(codeHeader);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(Nullable<>);
            }
        }

        public Type UnderlyingType
        {
            get
            {
                if (this.OriginalType == null)
                {
                    throw new InvalidProgramException("OriginalType is Null.");
                }
                Type underlyingType = Nullable.GetUnderlyingType(this.OriginalType);
                if (underlyingType == null)
                {
                    throw new InvalidCastException(string.Format("OriginalType[{0}] must is Nullable<> type.", this.OriginalType.FullName));
                }
                return underlyingType;
            }
        }
    }
}

