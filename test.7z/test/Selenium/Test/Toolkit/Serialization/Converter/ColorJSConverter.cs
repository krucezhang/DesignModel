﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Drawing;
    using System.Runtime.InteropServices;

    public class ColorJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            IList list = value as IList;
            if (list == null)
            {
                return Color.Empty;
            }
            double[] numArray = new double[list.Count - 1];
            for (int i = 1; i < list.Count; i++)
            {
                numArray[i - 1] = Convert.ToDouble(list[i]);
            }
            return Color.FromArgb(Convert.ToInt32((double) (numArray[0] * 255.0)), Convert.ToInt32(numArray[1]), Convert.ToInt32(numArray[2]), Convert.ToInt32(numArray[3]));
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            string str = string.IsNullOrEmpty(header) ? "color1" : header;
            Color color = (Color) value;
            string[] strArray = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
            string str2 = "'#" + strArray[color.R / 0x10] + strArray[color.R % 0x10] + strArray[color.G / 0x10] + strArray[color.G % 0x10] + strArray[color.B / 0x10] + strArray[color.B % 0x10] + "'";
            if (color == Color.Empty)
            {
                str2 = "null";
            }
            return new CodeSnippet(str, string.Format("\r\n                    var {0} = {1};\r\n                ", str, str2), new object[0]);
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            return new CodeSnippet("formatObj", "var formatObj = window.GrapeCityAutoTest.parseColor(" + codeHeader + ");", new object[0]);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(Color);
            }
        }
    }
}

