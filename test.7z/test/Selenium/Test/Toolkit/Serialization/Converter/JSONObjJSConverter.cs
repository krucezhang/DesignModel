﻿namespace Selenium.Test.Toolkit.Serialization.Converter
{
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class JSONObjJSConverter : JSConverterBase
    {
        public override object ConvertToCShapeType(object value)
        {
            IList list = value as IList;
            object[] args = new object[list.Count - 1];
            for (int i = 1; i < list.Count; i++)
            {
                args[i - 1] = Convert.ToString(list[i]);
            }
            return Activator.CreateInstance(this.TargetType, args);
        }

        public override CodeSnippet ConvertToJavaScript(object value, string header = null)
        {
            JSONObj obj2 = value as JSONObj;
            int length = obj2.JSONString.Length;
            int startIndex = 0;
            List<string> list = new List<string>();
            while ((length - startIndex) > 0)
            {
                int num3 = 0xc350;
                if ((startIndex + num3) > length)
                {
                    list.Add(obj2.JSONString.Substring(startIndex));
                }
                else
                {
                    list.Add(obj2.JSONString.Substring(startIndex, num3));
                }
                startIndex += num3;
            }
            CodeSnippet dependedScript = JSConverterBase.GetTypeConverter(typeof(string)).ConvertToJavaScript(list[0], "jsonStr1");
            if (list.Count > 1)
            {
                string newCodeHeader = ExecutableObject.GetNewCodeHeader("jsonStr");
                ExecutableObject obj3 = new ExecutableObject(new CodeSnippet(newCodeHeader, string.Format("{0} = '';", newCodeHeader), new object[0]));
                dependedScript = obj3.DependedScript;
                for (int i = 0; i < list.Count; i++)
                {
                    CodeSnippet snippet2 = JSConverterBase.GetTypeConverter(typeof(string)).ConvertToJavaScript(list[i], "jsonTempStr" + i);
                    string snippet = snippet2.Snippet + string.Format("{0} = {0} + {1};", dependedScript.CodeHeader, snippet2.CodeHeader);
                    if (i == 0)
                    {
                        snippet = dependedScript.Snippet + snippet;
                    }
                    obj3.ExecuteJS(new CodeSnippet(dependedScript.CodeHeader, snippet, new object[0]));
                }
                dependedScript = new CodeSnippet(dependedScript.CodeHeader, string.Empty, new object[0]);
            }
            string str3 = string.IsNullOrEmpty(header) ? "jsonObj1" : header;
            string str4 = string.Format("var {0} = JSON.parse({1});", str3, dependedScript.CodeHeader);
            return new CodeSnippet(str3, dependedScript.Snippet + str4, new object[0]);
        }

        public override CodeSnippet GetFormatCode(string codeHeader)
        {
            return new CodeSnippet("formatObj", "var formatObj = window.GrapeCityAutoTest.parseJSONObj(" + codeHeader + ");", new object[0]);
        }

        public override Type TargetType
        {
            get
            {
                return typeof(JSONObj);
            }
        }
    }
}

