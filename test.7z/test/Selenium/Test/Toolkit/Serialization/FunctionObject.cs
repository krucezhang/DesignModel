﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit;
    using System;
    using System.Runtime.InteropServices;

    public class FunctionObject : JSObject
    {
        private string _functionName;

        public FunctionObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public FunctionObject(string functionName = null) : base(null)
        {
            this._functionName = functionName;
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            string header = string.IsNullOrWhiteSpace(this._functionName) ? "FunctionObj" : this._functionName;
            CodeSnippet executeCode = new CodeSnippet("funcObj", "var funcObj = function(){};", new object[0]);
            return this.GetExecutedJSSnippet(executeCode, header);
        }

        protected override CodeSnippet GetDependedScript()
        {
            CodeSnippet dependedScript = base.GetDependedScript();
            if ((dependedScript != null) && !string.IsNullOrWhiteSpace(dependedScript.Snippet))
            {
                string header = string.IsNullOrWhiteSpace(this._functionName) ? "FunctionObj" : this._functionName;
                dependedScript = this.GetExecutedJSSnippet(dependedScript, header);
                base.DependedScript = dependedScript;
            }
            return dependedScript;
        }

        public void ImplementMehtodInterface(string methodName, CodeSnippet func)
        {
            base.prototype.SetJSProperty(methodName, func);
        }

        public void InvokeFunction(params object[] args)
        {
            this.InvokeJSMehtod(string.Empty, args);
        }

        public T InvokeFunction<T>(params object[] args)
        {
            return this.InvokeJSMehtod<T>(string.Empty, args);
        }

        public JSObject NewInstance(params object[] args)
        {
            return this.NewInstance<JSObject>(args);
        }

        public T NewInstance<T>(params object[] args)
        {
            return TestUtility.CreateInstance<T>(base.GetCtorJSSnippet(base.DependedScript.CodeHeader, null, args), null, null, new object[0]);
        }
    }
}

