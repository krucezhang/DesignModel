﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;
    using System.Collections.Generic;

    public class CodeSnippet : IDisposable
    {
        private List<object> _args;
        private string _header;
        private string _snippet;

        public CodeSnippet()
        {
        }

        public CodeSnippet(string header, string snippet, params object[] args)
        {
            this._header = header;
            this._snippet = snippet;
            this.Args.AddRange(args);
        }

        public void Dispose()
        {
            if (this._args != null)
            {
                this._args.Clear();
                this._args = null;
            }
        }

        public List<object> Args
        {
            get
            {
                if (this._args == null)
                {
                    this._args = new List<object>();
                }
                return this._args;
            }
        }

        public string CodeHeader
        {
            get
            {
                return this._header;
            }
        }

        public string Snippet
        {
            get
            {
                return this._snippet;
            }
        }
    }
}

