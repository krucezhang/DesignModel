﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;

    public class ErrorObject : JSObject
    {
        public ErrorObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public string message
        {
            get
            {
                return this.GetJSProperty<string>("message");
            }
        }

        public string name
        {
            get
            {
                return this.GetJSProperty<string>("name");
            }
        }

        public string stack
        {
            get
            {
                return this.GetJSProperty<string>("stack");
            }
        }
    }
}

