﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit.Core;
    using System;

    public class ErrorWatcher : JSObject
    {
        public ErrorWatcher() : base(null)
        {
        }

        public ErrorWatcher(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public void FireErrors()
        {
            ArrayObject<ErrorInfo> errors = this.Errors;
            int length = errors.length;
            if (length > 0)
            {
                string message = null;
                for (int i = 0; i < length; i++)
                {
                    message = ((message == null) ? "" : " - ") + string.Format("{0} (found at '{1}', line {2})", errors[i].Message, errors[i].URL, errors[i].Line);
                }
                throw new InvalidProgramException(message);
            }
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            return Manager.Current.GrapeCityAutoTest.DependedScript;
        }

        protected override string InjectDPDetection()
        {
            return (base.InjectDPDetection() + string.Format("if(!window.GrapeCityAutoTest.Errors)return '{0}:ErrorWatcher';", "InjectDP"));
        }

        protected override void InjectionDependency(ExecutableObject.DependencyInjectionContext context)
        {
            base.InjectionDependency(context);
            if (context.InjectDP.Contains("ErrorWatcher"))
            {
                Manager.Current.GrapeCityAutoTest.InvokeJSMehtod("watchJSError", new object[0]);
                context.InjectSucess = true;
            }
        }

        public void StartWatchError()
        {
            if (Manager.WatchJavaScriptError)
            {
                this.InvokeJSMehtod("watchJSError", new object[0]);
            }
        }

        public int ErrorCount
        {
            get
            {
                return this.Errors.length;
            }
        }

        public ArrayObject<ErrorInfo> Errors
        {
            get
            {
                return new ArrayObject<ErrorInfo>(base.DependedScript);
            }
        }

        public bool HasError
        {
            get
            {
                return (this.ErrorCount > 0);
            }
        }
    }
}

