﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;

    public abstract class JSOptions : JSObject
    {
        public JSOptions() : base(null)
        {
        }

        public JSOptions(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            CodeSnippet executeCode = new CodeSnippet("options", "var options = {};", new object[0]);
            return this.GetExecutedJSSnippet(executeCode, "Options");
        }
    }
}

