﻿namespace Selenium.Test.Toolkit.Serialization
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization.Converter;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.InteropServices;

    public class ArrayObject<T> : JSObject where T: IExecutable
    {
        private ArrayList _dependentArgs;
        private IElementGUI _dependentParentGUI;

        public ArrayObject() : this(null)
        {
        }

        public ArrayObject(CodeSnippet dependedScript) : this(dependedScript, null, null)
        {
        }

        public ArrayObject(CodeSnippet dependedScript, IElementGUI parentGUI) : this(dependedScript, parentGUI, null)
        {
        }

        public ArrayObject(CodeSnippet dependedScript, IElementGUI parentGUI, ArrayList depandentArgs) : base(dependedScript)
        {
            this._dependentParentGUI = parentGUI;
            this._dependentArgs = depandentArgs;
        }

        public void Add(T item)
        {
            this.push(new T[] { item });
        }

        public override AT AsTo<AT>()
        {
            return TestUtility.CreateInstance<AT>(base.DependedScript, null, this.DependentParentGUI, this.DependentArgs.ToArray());
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public bool Contains(T item)
        {
            throw new NotImplementedException();
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        internal static CodeSnippet GetArrayItemJSSnippet(CodeSnippet dependedScript, int index, Type returnType, string header = null)
        {
            string str = dependedScript.Snippet;
            string codeHeader = string.IsNullOrEmpty(header) ? "itemValue" : header;
            object obj2 = str;
            str = string.Concat(new object[] { obj2, "var ", codeHeader, " = ", dependedScript.CodeHeader, "[", index, "];" });
            if (returnType != null)
            {
                CodeSnippet formatCode = JSConverterBase.GetTypeConverter(returnType).GetFormatCode(codeHeader);
                str = (str + formatCode.Snippet) + "return " + formatCode.CodeHeader + ";";
            }
            return new CodeSnippet(codeHeader, str, dependedScript.Args.ToArray());
        }

        protected override CodeSnippet GetDependedScript()
        {
            CodeSnippet dependedScript = base.GetDependedScript();
            if (dependedScript == null)
            {
                dependedScript = this.GetExecutedJSSnippet(new CodeSnippet("arrayObj", "var arrayObj = [];", new object[0]), "ArrayObj");
                base.DependedScript = dependedScript;
            }
            return dependedScript;
        }

        public IEnumerator<T> GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public virtual OT GetJSArrayItem<OT>(int index)
        {
            return (OT) this.GetJSArrayItem(index, typeof(OT));
        }

        public virtual object GetJSArrayItem(int index, Type itemType)
        {
            CodeSnippet executeCode = ArrayObject<T>.GetArrayItemJSSnippet(base.DependedScript, index, itemType, string.Empty);
            object obj2 = this.ExecuteJS(executeCode);
            return JSConverterBase.GetTypeConverter(itemType).ConvertToCShapeType(obj2);
        }

        public int IndexOf(T item)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, T item)
        {
            throw new NotImplementedException();
        }

        public T pop()
        {
            CodeSnippet dependedCode = ExecutableObject.GetInvokeJSSnippet(base.DependedScript, "pop", null, "item1", new object[0]);
            string newCodeHeader = ExecutableObject.GetNewCodeHeader("popItem");
            string snippet = dependedCode.Snippet + string.Format("{0} = {1};", newCodeHeader, dependedCode.CodeHeader);
            this.ExecuteJS(new CodeSnippet(string.Empty, snippet, dependedCode.Args.ToArray()));
            dependedCode = new CodeSnippet(newCodeHeader, string.Empty, new object[0]);
            return TestUtility.CreateInstance<T>(dependedCode, null, this.DependentParentGUI, this.DependentArgs.ToArray());
        }

        public int push(params T[] values)
        {
            if (values.Length < 1)
            {
                throw new ArgumentException("Array's Push method must has one params.");
            }
            object[] args = new object[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] != null)
                {
                    args[i] = values[i].DependedScript;
                }
                else
                {
                    args[i] = values[i];
                }
            }
            return this.InvokeJSMehtod<int>("push", args);
        }

        public bool Remove(T item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        internal static CodeSnippet SetArrayItemJSSnippet(CodeSnippet dependedScript, int index, object value)
        {
            string str = dependedScript.Snippet;
            CodeSnippet snippet = JSConverterBase.GetTypeConverter(value).ConvertToJavaScript(value, "item" + index);
            object obj2 = str + snippet.Snippet;
            return new CodeSnippet(dependedScript.CodeHeader, string.Concat(new object[] { obj2, dependedScript.CodeHeader, "[", index, "] = ", snippet.CodeHeader, ";" }), dependedScript.Args.ToArray());
        }

        public virtual void SetJSArrayItem(int index, object value)
        {
            CodeSnippet executeCode = ArrayObject<T>.SetArrayItemJSSnippet(base.DependedScript, index, value);
            this.ExecuteJS(executeCode);
        }

        public int Count
        {
            get
            {
                return this.length;
            }
        }

        private ArrayList DependentArgs
        {
            get
            {
                if (this._dependentArgs == null)
                {
                    return new ArrayList();
                }
                return this._dependentArgs;
            }
        }

        protected IElementGUI DependentParentGUI
        {
            get
            {
                return this._dependentParentGUI;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        public T this[int index]
        {
            get
            {
                CodeSnippet executedJSSnippet = this.GetExecutedJSSnippet(ArrayObject<T>.GetArrayItemJSSnippet(base.DependedScript, index, null, "item" + index), "ArrayItem");
                string snippet = executedJSSnippet.Snippet + "return " + executedJSSnippet.CodeHeader + ";";
                CodeSnippet executeCode = new CodeSnippet(string.Empty, snippet, executedJSSnippet.Args.ToArray());
                if (this.IsNullJSObject(executedJSSnippet))
                {
                    return default(T);
                }
                object obj2 = null;
                if (typeof(DomElementGUI).IsAssignableFrom(typeof(T)))
                {
                    try
                    {
                        obj2 = this.ExecuteJS(executeCode);
                    }
                    catch
                    {
                    }
                }
                IWebElement webElement = obj2 as IWebElement;
                if (webElement != null)
                {
                    executedJSSnippet = null;
                }
                return TestUtility.CreateInstance<T>(executedJSSnippet, webElement, this.DependentParentGUI, this.DependentArgs.ToArray());
            }
            set
            {
                object obj2 = (value != null) ? value.DependedScript : null;
                this.SetJSArrayItem(index, obj2);
            }
        }

        public int length
        {
            get
            {
                return this.GetJSProperty<int>("length");
            }
            set
            {
                this.SetJSProperty("length", value);
            }
        }
    }
}

