﻿namespace Selenium.Test.Toolkit.Serialization
{
    using System;

    public class JSObject : ExecutableObject
    {
        public JSObject() : base(null)
        {
        }

        public JSObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        protected virtual CodeSnippet GetDefaultObjectDependedScript()
        {
            CodeSnippet executeCode = new CodeSnippet("jsObject", "var jsObject = {};", new object[0]);
            return this.GetExecutedJSSnippet(executeCode, "JSObject");
        }

        public override T GetJSProperty<T>(string property)
        {
            if (!typeof(T).IsValueType && base.GetJSProperty<JSObject>(property).IsNullValue)
            {
                return default(T);
            }
            return base.GetJSProperty<T>(property);
        }

        public bool hasOwnProperty(string propertyName)
        {
            return this.InvokeJSMehtod<bool>("hasOwnProperty", new object[] { propertyName });
        }

        protected override void Initization()
        {
            base.Initization();
            if (base.DependedScript == null)
            {
                base.DependedScript = this.GetDefaultObjectDependedScript();
            }
        }

        public ExecutableObject prototype
        {
            get
            {
                return new ExecutableObject(this.GetJSPropertyJSSnippet("prototype", "objprototype"));
            }
            set
            {
                this.SetJSProperty("prototype", value);
            }
        }
    }
}

