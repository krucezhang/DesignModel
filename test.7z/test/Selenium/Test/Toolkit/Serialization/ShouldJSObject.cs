﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit;
    using System;

    public class ShouldJSObject : ExecutableObject
    {
        public ShouldJSObject(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public ShouldJSObject(ExecutableObject obj) : base(null)
        {
            base.DependedScript = new ExecutableObject(new CodeSnippet("window", string.Empty, new object[0])).GetInvokeJSSnippet("should", "ShouldObject", new object[] { obj });
        }

        public ShouldJSObject above(double num)
        {
            return this.PerformInvokeJSMehtod("above", new object[] { num });
        }

        public ShouldJSObject approximately(double num, double delta)
        {
            return this.PerformInvokeJSMehtod("approximately", new object[] { num, delta });
        }

        public ShouldJSObject below(double num)
        {
            return this.PerformInvokeJSMehtod("below", new object[] { num });
        }

        public ShouldJSObject endWith(string value)
        {
            return this.PerformInvokeJSMehtod("endWith", new object[] { value });
        }

        public ShouldJSObject eql(object value)
        {
            return this.PerformInvokeJSMehtod("eql", new object[] { value });
        }

        public ShouldJSObject equal(object value)
        {
            return this.PerformInvokeJSMehtod("equal", new object[] { value });
        }

        public ShouldJSObject exactly(object value)
        {
            return this.PerformInvokeJSMehtod("exactly", new object[] { value });
        }

        protected override string InjectDPDetection()
        {
            return (base.InjectDPDetection() + string.Format("if(!window.should)return '{0}:ShouldJS';", "InjectDP"));
        }

        protected override void InjectionDependency(ExecutableObject.DependencyInjectionContext context)
        {
            base.InjectionDependency(context);
            if (context.InjectDP.Contains("ShouldJS"))
            {
                ExecutableObject.ExecuteScript(FileHelper.GetJSFromResourcesFile("should.min.js"), new object[0]);
                context.InjectSucess = true;
            }
        }

        public ShouldJSObject lengthOf(int length)
        {
            return this.PerformInvokeJSMehtod("lengthOf", new object[] { length });
        }

        private ShouldJSObject PerformGetJSProperty(string property)
        {
            return new ShouldJSObject(this.GetJSProperty<CodeSnippet>(property));
        }

        private ShouldJSObject PerformInvokeJSMehtod(string method, params object[] args)
        {
            return new ShouldJSObject(this.InvokeJSMehtod<CodeSnippet>(method, args));
        }

        public ShouldJSObject properties(params string[] propertyNames)
        {
            return this.PerformInvokeJSMehtod("properties", propertyNames);
        }

        public ShouldJSObject properties(JSObject jsObj)
        {
            return this.PerformInvokeJSMehtod("properties", new object[] { jsObj });
        }

        public ShouldJSObject property(string name)
        {
            return this.PerformInvokeJSMehtod("property", new object[] { name });
        }

        public ShouldJSObject property(string name, object value)
        {
            return this.PerformInvokeJSMehtod("property", new object[] { name, value });
        }

        public ShouldJSObject startWith(string value)
        {
            return this.PerformInvokeJSMehtod("startWith", new object[] { value });
        }

        public ShouldJSObject within(double from, double to)
        {
            return this.PerformInvokeJSMehtod("within", new object[] { from, to });
        }

        public ShouldJSObject a
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("a");
            }
        }

        public ShouldJSObject an
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("an");
            }
        }

        public ShouldJSObject and
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("and");
            }
        }

        public ShouldJSObject be
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("be");
            }
        }

        public ShouldJSObject empty
        {
            get
            {
                return this.PerformGetJSProperty("empty");
            }
        }

        public ShouldJSObject False
        {
            get
            {
                return this.PerformGetJSProperty("false");
            }
        }

        public ShouldJSObject have
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("have");
            }
        }

        public ShouldJSObject Infinity
        {
            get
            {
                return this.PerformGetJSProperty("Infinity");
            }
        }

        public ShouldJSObject Is
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("is");
            }
        }

        public ShouldJSObject NaN
        {
            get
            {
                return this.PerformGetJSProperty("NaN");
            }
        }

        public ShouldJSObject not
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("not");
            }
        }

        public ShouldJSObject of
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("of");
            }
        }

        public ShouldJSObject ok
        {
            get
            {
                return this.PerformGetJSProperty("ok");
            }
        }

        public ShouldJSObject True
        {
            get
            {
                return this.PerformGetJSProperty("true");
            }
        }

        public ShouldJSObject which
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("which");
            }
        }

        public ShouldJSObject with
        {
            get
            {
                return this.GetJSProperty<ShouldJSObject>("with");
            }
        }
    }
}

