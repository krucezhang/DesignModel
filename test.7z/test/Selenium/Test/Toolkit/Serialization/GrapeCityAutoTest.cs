﻿namespace Selenium.Test.Toolkit.Serialization
{
    using Selenium.Test.Toolkit.GUI;
    using System;

    public class GrapeCityAutoTest : JSObject
    {
        public GrapeCityAutoTest() : base(null)
        {
        }

        public GrapeCityAutoTest(CodeSnippet dependedScript) : base(dependedScript)
        {
        }

        public GrapeCityAutoTest deleteAllCookies()
        {
            this.InvokeJSMehtod("deleteAllCookies", new object[0]);
            return this;
        }

        protected override CodeSnippet GetDefaultObjectDependedScript()
        {
            return new CodeSnippet("window.GrapeCityAutoTest", string.Empty, new object[0]);
        }

        public void loadScript(string src)
        {
            this.InvokeJSMehtod("loadScript", new object[] { src });
        }

        public void loadStylesheet(string href)
        {
            this.InvokeJSMehtod("loadStylesheet", new object[] { href });
        }

        public void Simulate(DomElementGUI element, string eventType, int x, int y)
        {
            this.InvokeJSMehtod("simulate", new object[] { element, eventType, x, y });
        }

        public bool loadScriptComplete
        {
            get
            {
                return this.GetJSProperty<bool>("loadScriptComplete");
            }
        }

        public bool loadStylesheetComplete
        {
            get
            {
                return this.GetJSProperty<bool>("loadStylesheetComplete");
            }
        }

        public JSObject TestObjects
        {
            get
            {
                return this.GetJSProperty<JSObject>("TestObjects");
            }
        }
    }
}

