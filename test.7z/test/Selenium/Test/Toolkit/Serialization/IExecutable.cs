﻿namespace Selenium.Test.Toolkit.Serialization
{
    public interface IExecutable
    {
        CodeSnippet DependedScript { get; }
    }
}

