﻿namespace Selenium.Test.Toolkit
{
    using System;
    using System.Timers;

    public static class WaitHelper
    {
        private static bool flag = false;
        private static Timer timer = new Timer();

        public static void Wait()
        {
            Wait(30f);
        }

        public static void Wait(float seconds)
        {
            if (!seconds.Equals((float) 0f))
            {
                timer.Elapsed += delegate (object o, ElapsedEventArgs e) {
                    timer.Stop();
                    timer.Enabled = false;
                    flag = false;
                };
                timer.Interval = Convert.ToInt32((float) (seconds * 1000f));
                timer.Enabled = true;
                flag = true;
                timer.Start();
                while (flag)
                {
                    ProcessSleep.WaitAWhile(0.1f);
                }
            }
        }
    }
}

