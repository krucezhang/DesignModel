﻿namespace Selenium.Test.Toolkit.WebDriver
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Remote;
    using System;

    public class ChromeMobileDriver : ChromeDriver, IHasTouchScreen
    {
        private ITouchScreen _touchDriver;

        public ChromeMobileDriver()
        {
        }

        public ChromeMobileDriver(string chromeDriverDirectory, ChromeOptions options, TimeSpan commandTimeout) : base(chromeDriverDirectory, options, commandTimeout)
        {
        }

        protected override void Dispose(bool disposing)
        {
            this._touchDriver = null;
            base.Dispose(disposing);
        }

        public ITouchScreen TouchScreen
        {
            get
            {
                if (this._touchDriver == null)
                {
                    this._touchDriver = new RemoteTouchScreen(this);
                }
                return this._touchDriver;
            }
        }
    }
}

