﻿namespace Selenium.Test.Toolkit.Finder
{
    using Selenium.Test.Toolkit;
    using System;

    [EnumString]
    public enum TextFindCondition
    {
        None,
        Equals,
        Contains,
        StartsWith,
        EndsWith,
        Regex
    }
}

