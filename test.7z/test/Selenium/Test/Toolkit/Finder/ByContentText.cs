﻿namespace Selenium.Test.Toolkit.Finder
{
    using Microsoft.VisualBasic;
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Runtime.InteropServices;
    using System.Text.RegularExpressions;

    public class ByContentText : By
    {
        private By _baseFinder;
        private TextComparison _comparison;
        private TextFindCondition _condition;
        private string _findText;
        private bool _useTextMap;

        public ByContentText(By baseFinder, string findText) : this(baseFinder, findText, TextFindCondition.Equals, TextComparison.IgnoreCase, false)
        {
        }

        public ByContentText(By baseFinder, string findText, TextFindCondition condition) : this(baseFinder, findText, condition, TextComparison.IgnoreCase, false)
        {
        }

        public ByContentText(By baseFinder, string findText, TextFindCondition condition, bool ignoreCase) : this(baseFinder, findText, condition, ignoreCase, false)
        {
        }

        public ByContentText(By baseFinder, string findText, TextFindCondition condition, TextComparison comparison, bool useTextMap)
        {
            this._findText = string.Empty;
            this._condition = TextFindCondition.Equals;
            this._comparison = TextComparison.IgnoreCase;
            if (baseFinder == null)
            {
                throw new ArgumentException("Basic finder[By] cannot be null", "baseFinder");
            }
            if (string.IsNullOrEmpty(findText))
            {
                throw new ArgumentException("find Content Text cannot be null or the empty string", "findText");
            }
            this._baseFinder = baseFinder;
            this._findText = findText;
            this._condition = condition;
            this._comparison = comparison;
            this._useTextMap = useTextMap;
        }

        public ByContentText(By baseFinder, string findText, TextFindCondition condition, bool ignoreCase, bool useTextMap) : this(baseFinder, findText, condition, ignoreCase ? TextComparison.IgnoreCase : TextComparison.None, false)
        {
        }

        public static bool CompareText(string userText, string actualText, TextFindCondition condition, TextComparison comparison, bool useTextMap)
        {
            if ((userText == actualText) && (condition != TextFindCondition.Regex))
            {
                return true;
            }
            if (!string.IsNullOrEmpty(userText) && !string.IsNullOrEmpty(actualText))
            {
                bool flag = comparison != TextComparison.None;
                if (comparison == TextComparison.IgnoreCaseWithMoreByteChar)
                {
                    actualText = Strings.StrConv(actualText, VbStrConv.Narrow, new CultureInfo("ja-JP").LCID);
                }
                foreach (string str in GetFinderText(userText, useTextMap))
                {
                    if (!string.IsNullOrEmpty(str))
                    {
                        if (comparison == TextComparison.IgnoreCaseWithMoreByteChar)
                        {
                            str = Strings.StrConv(str, VbStrConv.Narrow, new CultureInfo("ja-JP").LCID);
                        }
                        switch (condition)
                        {
                            case TextFindCondition.None:
                            case TextFindCondition.Equals:
                                if (!(flag ? actualText.Equals(str, StringComparison.OrdinalIgnoreCase) : actualText.Equals(str)))
                                {
                                    break;
                                }
                                return true;

                            case TextFindCondition.Contains:
                                if (!(flag ? actualText.ToLower().Contains(str.ToLower()) : actualText.Contains(str)))
                                {
                                    break;
                                }
                                return true;

                            case TextFindCondition.StartsWith:
                                if (!(flag ? actualText.StartsWith(str, StringComparison.OrdinalIgnoreCase) : actualText.StartsWith(str)))
                                {
                                    break;
                                }
                                return true;

                            case TextFindCondition.EndsWith:
                                if (!(flag ? actualText.EndsWith(str, StringComparison.OrdinalIgnoreCase) : actualText.EndsWith(str)))
                                {
                                    break;
                                }
                                return true;

                            case TextFindCondition.Regex:
                                if (!(flag ? Regex.IsMatch(actualText, str, RegexOptions.IgnoreCase) : Regex.IsMatch(actualText, str)))
                                {
                                    break;
                                }
                                return true;
                        }
                    }
                }
            }
            return false;
        }

        public static bool CompareText(string userText, string actualText, TextFindCondition condition, bool ignoreCase, bool useTextMap)
        {
            return CompareText(userText, actualText, condition, ignoreCase ? TextComparison.IgnoreCase : TextComparison.None, useTextMap);
        }

        public override IWebElement FindElement(ISearchContext context)
        {
            List<IWebElement> list = this.FindElementByBaseFinder(context, true);
            if (list.Count <= 0)
            {
                throw new NoSuchElementException(string.Format(CultureInfo.InvariantCulture, "Can't find element {0}.", new object[] { this }));
            }
            return list[0];
        }

        private List<IWebElement> FindElementByBaseFinder(ISearchContext context, bool returnFirst = false)
        {
            List<IWebElement> list = new List<IWebElement>();
            foreach (IWebElement element in this._baseFinder.FindElements(context))
            {
                string elementText = new DomElementGUI(element).ElementText;
                if (CompareText(this._findText, elementText, this._condition, this._comparison, this._useTextMap))
                {
                    list.Add(element);
                    if (returnFirst)
                    {
                        return list;
                    }
                }
            }
            return list;
        }

        public override ReadOnlyCollection<IWebElement> FindElements(ISearchContext context)
        {
            return this.FindElementByBaseFinder(context, false).AsReadOnly();
        }

        public static string[] GetFinderText(string text, bool useTextMap)
        {
            if (!useTextMap)
            {
                return new string[] { text };
            }
            return Manager.TextResourceMap.GetTextMap(text);
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "ByContentText([By:{0}], [FindText:{1}], [Condition:{2}], [TextComparison:{3}], [UseTextMap:{4}])", new object[] { this._baseFinder, this._findText, this._condition, this._comparison, this._useTextMap });
        }
    }
}

