﻿namespace Selenium.Test.Toolkit.Finder
{
    using Selenium.Test.Toolkit;
    using System;

    [EnumString]
    public enum TextComparison
    {
        None,
        IgnoreCase,
        IgnoreCaseWithMoreByteChar
    }
}

