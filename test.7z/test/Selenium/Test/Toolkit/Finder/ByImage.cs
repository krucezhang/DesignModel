﻿namespace Selenium.Test.Toolkit.Finder
{
    using OpenQA.Selenium;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Runtime.InteropServices;

    public class ByImage : By
    {
        private string _imageSource = string.Empty;

        public ByImage(string imageSource)
        {
            if (string.IsNullOrWhiteSpace(imageSource))
            {
                throw new ArgumentException("Image source path cannot be null or the empty string", "imageSource");
            }
            this._imageSource = imageSource;
        }

        public override IWebElement FindElement(ISearchContext context)
        {
            List<IWebElement> list = this.FindElementByBaseFinder(context, true);
            if (list.Count <= 0)
            {
                throw new NoSuchElementException(string.Format(CultureInfo.InvariantCulture, "Can't find element {0}.", new object[] { this }));
            }
            return list[0];
        }

        private List<IWebElement> FindElementByBaseFinder(ISearchContext context, bool returnFirst = false)
        {
            return new List<IWebElement>();
        }

        public override ReadOnlyCollection<IWebElement> FindElements(ISearchContext context)
        {
            return this.FindElementByBaseFinder(context, false).AsReadOnly();
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "ByImage([imageSource:{0}])", new object[] { this._imageSource });
        }
    }
}

