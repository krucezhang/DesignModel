﻿namespace Selenium.Test.Toolkit.Core
{
    using Selenium.Test.Toolkit.GUI;
    using System;

    public interface IProxyElement
    {
        bool ExistDisplayedElement(IElementGUI element);
        bool ExistElement(IElementGUI element);
        IElementGUI WaitForElementDisappeared(int timeout);
        IElementGUI WaitForElementEnabled(int timeout);
        IElementGUI WaitForElementVisible(int timeout);

        bool IsExistDisplayedElement { get; }

        bool IsExistElement { get; }

        bool IsNull { get; }

        IElementGUI Self { get; }
    }
}

