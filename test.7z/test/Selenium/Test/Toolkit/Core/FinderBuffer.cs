﻿namespace Selenium.Test.Toolkit.Core
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class FinderBuffer : IDisposable
    {
        private Dictionary<string, object> _cachedDic;

        public void ClearFinderBuffer()
        {
            if (this._cachedDic != null)
            {
                this._cachedDic.Clear();
                this._cachedDic = null;
            }
        }

        public void Dispose()
        {
            this.ClearFinderBuffer();
        }

        public bool TryGetElement(string key, out object value, ElementVisibility visibility = 0)
        {
            if (!this.Enable || (this._cachedDic == null))
            {
                value = null;
                return false;
            }
            return (this.Buffer.TryGetValue(key, out value) && this.ValidateElementIsActive(value, visibility));
        }

        public bool TryGetElement(By by, ElementVisibility visibility, out object value, string text = "", TextFindCondition condition = 1, TextComparison comparison = 1)
        {
            string key = by.ToString() + text + condition.ToString() + comparison.ToString();
            return this.TryGetElement(key, out value, visibility);
        }

        public void UpdateElement(string key, object value)
        {
            if (this.Enable)
            {
                if (this.Buffer.ContainsKey(key))
                {
                    this.Buffer[key] = value;
                }
                else
                {
                    this.Buffer.Add(key, value);
                }
            }
        }

        public void UpdateElement(By by, ElementVisibility visibility, object value, string text = "", TextFindCondition condition = 1, TextComparison comparison = 1)
        {
            string key = by.ToString() + text + condition.ToString() + comparison.ToString();
            this.UpdateElement(key, value);
        }

        protected bool ValidateElementIsActive(object value, ElementVisibility visibility)
        {
            if (value == null)
            {
                return false;
            }
            IElementGUI tgui = value as IElementGUI;
            if (tgui == null)
            {
                IList<object> list = value as IList<object>;
                if ((list != null) && (list.Count > 0))
                {
                    tgui = list[0] as IElementGUI;
                }
            }
            if (tgui != null)
            {
                try
                {
                    if (visibility == ElementVisibility.Display)
                    {
                        return tgui.Visible;
                    }
                    tgui.WebElement.get_Enabled();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            return true;
        }

        protected Dictionary<string, object> Buffer
        {
            get
            {
                if (this._cachedDic == null)
                {
                    this._cachedDic = new Dictionary<string, object>();
                }
                return this._cachedDic;
            }
        }

        public bool Enable { get; set; }

        public enum ElementVisibility
        {
            UnKnow,
            Display,
            Hidden
        }
    }
}

