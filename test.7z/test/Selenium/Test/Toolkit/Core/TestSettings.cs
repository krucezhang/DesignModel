﻿namespace Selenium.Test.Toolkit.Core
{
    using Selenium.Test.Toolkit.Action;
    using System;
    using System.Runtime.CompilerServices;

    public class TestSettings
    {
        public TestSettings()
        {
            this.DriverType = "OpenQA.Selenium.Firefox.FirefoxDriver";
            this.BrowserType = Selenium.Test.Toolkit.Core.BrowserType.Firefox;
            this.ActionType = Selenium.Test.Toolkit.Action.ActionType.Auto;
            this.IsWinPlatform = Environment.OSVersion.Platform == PlatformID.Win32NT;
            this.IsHeadless = false;
        }

        internal TestSettings(TestSettingsConfigSectionHandler configSettings) : this()
        {
            this.DriverType = configSettings.DriverType;
            this.DriverPath = configSettings.DriverPath;
            this.BrowserType = configSettings.BrowserType;
            this.ActionType = configSettings.ActionType;
            this.RemoteAddress = configSettings.RemoteAddress;
            this.CommandTimeout = configSettings.CommandTimeout;
            this.IsHeadless = configSettings.IsHeadless;
        }

        public Selenium.Test.Toolkit.Action.ActionType ActionType { get; set; }

        public Selenium.Test.Toolkit.Core.BrowserType BrowserType { get; set; }

        public int CommandTimeout { get; set; }

        public string DriverPath { get; set; }

        public string DriverType { get; set; }

        public bool IsHeadless { get; set; }

        public bool IsRemote
        {
            get
            {
                return this.DriverType.ToLower().Contains("remotewebdriver");
            }
        }

        public bool IsWinPlatform { get; private set; }

        public string RemoteAddress { get; set; }
    }
}

