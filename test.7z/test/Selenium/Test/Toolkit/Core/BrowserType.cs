﻿namespace Selenium.Test.Toolkit.Core
{
    using System;

    [Flags]
    public enum BrowserType
    {
        ALL = 0xff,
        Chrome = 4,
        Chrome360se = 0x40,
        ChromeMobile = 0x80,
        Edge = 0x10,
        Firefox = 2,
        IE = 1,
        None = 0,
        Opera = 0x20,
        Safari = 8
    }
}

