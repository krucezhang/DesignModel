﻿namespace Selenium.Test.Toolkit.Core
{
    using System;
    using System.Collections.Generic;

    public class TextResourceMap
    {
        private Dictionary<string, string[]> _textMap;

        public void AddTextMap(params string[] text)
        {
            if ((text != null) && (text.Length != 0))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    string key = text[i];
                    if (this.TextMap.ContainsKey(key))
                    {
                        List<string> list = new List<string>();
                        list.AddRange(this.TextMap[key]);
                        list.AddRange(text);
                        this.TextMap[key] = list.ToArray();
                    }
                    else
                    {
                        this.TextMap.Add(text[i], text);
                    }
                }
            }
        }

        public string[] GetTextMap(string text)
        {
            string[] strArray;
            if (!this.TextMap.TryGetValue(text, out strArray))
            {
                strArray = new string[] { text };
            }
            return strArray;
        }

        public Dictionary<string, string[]> TextMap
        {
            get
            {
                if (this._textMap == null)
                {
                    this._textMap = new Dictionary<string, string[]>();
                }
                return this._textMap;
            }
        }
    }
}

