﻿namespace Selenium.Test.Toolkit.Core
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Finder;
    using System;
    using System.Collections.Generic;

    public interface IFindElementGUI
    {
        T FindDisplayedElementGUI<T>(By by);
        T FindDisplayedElementGUI<T>(By by, bool throwExpection);
        IList<T> FindDisplayedElementGUIs<T>(By by);
        T FindElementGUI<T>(By by);
        T FindElementGUI<T>(By by, bool throwExpection);
        IList<T> FindElementGUIs<T>(By by);
        T WaitFindDisplayedElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison, bool throwExpection, int timeout);
        T WaitFindDisplayedElementGUI<T>(By by, int timeout);
        T WaitFindDisplayedElementGUI<T>(By by, bool throwExpection, int timeout);
        T WaitFindElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison, bool throwExpection, int timeout);
        T WaitFindElementGUI<T>(By by, int timeout);
        T WaitFindElementGUI<T>(By by, bool throwExpection, int timeout);

        bool UseResourceTextFinder { get; set; }
    }
}

