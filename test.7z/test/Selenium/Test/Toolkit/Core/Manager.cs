﻿namespace Selenium.Test.Toolkit.Core
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Action;
    using Selenium.Test.Toolkit.Serialization;
    using Selenium.Test.Toolkit.Serialization.Converter;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public class Manager : IDisposable
    {
        private Selenium.Test.Toolkit.Action.ActionFactory _actionsFactory;
        private Browser _activeBrowser;
        private static Manager _currentManager = null;
        private Selenium.Test.Toolkit.Core.TestSettings _settings;
        private static Selenium.Test.Toolkit.Core.TextResourceMap _textResourceMap = null;
        public static bool DoMessageFlushAfterAction = true;
        internal static Dictionary<string, By> GlobalFinders = new Dictionary<string, By>();
        public static bool IgnoreAssertAlertDialog = false;
        public static bool WatchJavaScriptError = true;

        public Manager(Selenium.Test.Toolkit.Core.TestSettings settings)
        {
            this.Init(settings);
        }

        public Manager(bool useConfig)
        {
            if (useConfig)
            {
                this.Init(new Selenium.Test.Toolkit.Core.TestSettings(TestSettingsConfigSectionHandler.ConfigTestSettings));
            }
            else
            {
                this.Init(new Selenium.Test.Toolkit.Core.TestSettings());
            }
        }

        public void ClearDownloadsFolder()
        {
            DirectoryInfo info = new DirectoryInfo(DownloadsFolderPath);
            if (info.Exists)
            {
                FileInfo[] files = info.GetFiles();
                for (int i = 0; i < files.Length; i++)
                {
                    try
                    {
                        files[i].Attributes = FileAttributes.Normal;
                        files[i].Delete();
                    }
                    catch
                    {
                    }
                }
            }
        }

        public static void ConfigGlobalFinder(string key, By value)
        {
            if (GlobalFinders.ContainsKey(key))
            {
                GlobalFinders[key] = value;
            }
            else
            {
                GlobalFinders.Add(key, value);
            }
        }

        public void Dispose()
        {
            _currentManager = null;
            this._settings = null;
            this._actionsFactory = null;
            if (this._activeBrowser != null)
            {
                this._activeBrowser.Dispose();
                this._activeBrowser = null;
            }
        }

        private void Init(Selenium.Test.Toolkit.Core.TestSettings settings)
        {
            if (_currentManager != null)
            {
                _currentManager.Dispose();
            }
            this._settings = settings;
            _currentManager = this;
        }

        public void InitializeCustomTypeConverter(Assembly assembly)
        {
            JSConverterBase.SearchConverterFromAssembly(assembly);
        }

        public Selenium.Test.Toolkit.Action.ActionFactory ActionFactory
        {
            get
            {
                if (this._actionsFactory == null)
                {
                    this._actionsFactory = new Selenium.Test.Toolkit.Action.ActionFactory();
                }
                return this._actionsFactory;
            }
        }

        public Browser ActiveBrowser
        {
            get
            {
                if (this._activeBrowser == null)
                {
                    this._activeBrowser = new Browser(this._settings);
                }
                return this._activeBrowser;
            }
        }

        public static Manager Current
        {
            get
            {
                return _currentManager;
            }
        }

        internal static string DownloadsFolderPath
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            }
        }

        public Selenium.Test.Toolkit.Serialization.ErrorWatcher ErrorWatcher
        {
            get
            {
                return new Selenium.Test.Toolkit.Serialization.ErrorWatcher();
            }
        }

        public Selenium.Test.Toolkit.Serialization.GrapeCityAutoTest GrapeCityAutoTest
        {
            get
            {
                return new Selenium.Test.Toolkit.Serialization.GrapeCityAutoTest();
            }
        }

        public Selenium.Test.Toolkit.Core.TestSettings TestSettings
        {
            get
            {
                return this._settings;
            }
        }

        public static Selenium.Test.Toolkit.Core.TextResourceMap TextResourceMap
        {
            get
            {
                if (_textResourceMap == null)
                {
                    _textResourceMap = new Selenium.Test.Toolkit.Core.TextResourceMap();
                }
                return _textResourceMap;
            }
        }
    }
}

