﻿namespace Selenium.Test.Toolkit.Core
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Edge;
    using OpenQA.Selenium.Firefox;
    using OpenQA.Selenium.IE;
    using OpenQA.Selenium.Opera;
    using OpenQA.Selenium.Remote;
    using OpenQA.Selenium.Support.UI;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Action;
    using Selenium.Test.Toolkit.BOMObject;
    using Selenium.Test.Toolkit.Desktop;
    using Selenium.Test.Toolkit.Finder;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using Selenium.Test.Toolkit.Serialization.Converter;
    using Selenium.Test.Toolkit.WebDriver;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Windows;
    using System.Windows.Automation;
    using System.Windows.Forms;
    using TestStack.White;
    using TestStack.White.Factory;
    using TestStack.White.Sessions;
    using TestStack.White.UIItems;
    using TestStack.White.UIItems.Finders;
    using TestStack.White.UIItems.ListBoxItems;
    using TestStack.White.UIItems.WindowItems;

    public class Browser : INavigation, IWindow, IFindElementGUI, IDisposable
    {
        private Window _browserWindow;
        private Rectangle _catchedBrowserContentBounds = Rectangle.Empty;
        private Rectangle _catchedContentBounds = Rectangle.Empty;
        private string _catchedCurrentURL;
        private TestSettings _settings;
        private IWebDriver _webDriver;
        private bool CheckBrowserLaunchStatus = true;

        internal Browser(TestSettings settings)
        {
            this._settings = settings;
        }

        public virtual void AddScript(string src, int timeout = -1)
        {
            GrapeCityAutoTest testCore;
            if (!string.IsNullOrWhiteSpace(src))
            {
                if (timeout <= 0)
                {
                    timeout = PageGUI.PageLoadedTimeout;
                }
                testCore = this.BuildInTestObj;
                testCore.loadScript(src);
                TestUtility.WaitFunc(delegate {
                    bool loadScriptComplete = testCore.loadScriptComplete;
                    if (!loadScriptComplete)
                    {
                        Thread.Sleep(500);
                    }
                    return loadScriptComplete;
                }, timeout, true, string.Format("Wait load script[src = '{0}'] ", src) + "timeout({0}s).");
            }
        }

        public virtual void AddStyleSheet(string cssStr)
        {
            if (!string.IsNullOrEmpty(cssStr))
            {
                cssStr = cssStr.Replace("\r\n", "");
                cssStr = cssStr.Replace("\n", "");
                cssStr = cssStr.Replace("\r", "");
                cssStr = cssStr.Replace('\'', '"');
                string format = "var style = document.createElement('style');\r\n style.innerHTML='{0}';\r\n document.getElementsByTagName('head')[0].appendChild(style);";
                (this.WebDriver as IJavaScriptExecutor).ExecuteScript(string.Format(format, cssStr), new object[0]);
                Thread.Sleep(500);
                this.WaitForAjax(0x2710);
            }
        }

        internal void AutoRefreshDomIfNeeded()
        {
        }

        public void Back()
        {
            this.WebDriver.Navigate().Back();
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            PageGUI.CurrentPageTypeName = string.Empty;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        private void CheckHTTPSWebsite(string url)
        {
            if (((this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE) && !string.IsNullOrEmpty(url)) && url.ToLower().Contains("https:"))
            {
                string str = this.WebDriver.get_Title();
                if (!string.IsNullOrWhiteSpace(str) && str.Contains("Certificate"))
                {
                    bool flag = false;
                    try
                    {
                        if (this.FindElementGUI(By.Id("overridelink")) != null)
                        {
                            flag = true;
                        }
                    }
                    catch
                    {
                    }
                    if (flag)
                    {
                        this.GoToUrl("javascript:document.getElementById('overridelink').click()");
                    }
                }
            }
        }

        public void ClearMockAlertCache()
        {
            MockAlert.Instance.ClearAlertTextCache();
        }

        public void CloseCurrentWindow()
        {
            this.WebDriver.Close();
        }

        public void CloseNotificationElement()
        {
            Func<bool> action = null;
            Func<bool> func2 = null;
            if (this.IsRemote)
            {
                throw new InvalidOperationException("Current testing is Remote Browser, so can't do native operation.");
            }
            Window browserWindow = this.GetBrowserWindowFromDesktop();
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Chrome)
            {
                if (action == null)
                {
                    action = delegate {
                        try
                        {
                            SearchCriteria searchCriteria = SearchCriteria.ByControlType(ControlType.Pane).AndByClassName("", PropertyConditionFlags.None);
                            if (!browserWindow.Exists(searchCriteria))
                            {
                                return true;
                            }
                            IUIItem[] multiple = browserWindow.Get<Panel>(searchCriteria).GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                            if (multiple.Length > 0)
                            {
                                multiple[multiple.Length - 1].Click();
                            }
                        }
                        catch
                        {
                        }
                        return false;
                    };
                }
                TestUtility.WaitFunc(action, 0x1388, false, null);
            }
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE)
            {
                if (func2 == null)
                {
                    func2 = delegate {
                        try
                        {
                            SearchCriteria searchCriteria = SearchCriteria.ByControlType(ControlType.Pane).AndByClassName("Frame Notification Bar", PropertyConditionFlags.None);
                            if (!browserWindow.Exists(searchCriteria))
                            {
                                return true;
                            }
                            IUIItem[] multiple = browserWindow.Get<Panel>(searchCriteria).GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                            if (multiple.Length > 0)
                            {
                                IUIItem item = multiple[multiple.Length - 1];
                                if (item.Enabled)
                                {
                                    item.Click();
                                    browserWindow.WaitWhileBusy();
                                }
                            }
                        }
                        catch
                        {
                        }
                        return false;
                    };
                }
                TestUtility.WaitFunc(func2, 0x1388, false, null);
            }
        }

        private bool ComfirmIERecommendedSettingsDialog()
        {
            Window modelDialog = this.GetModelDialog(50);
            if (modelDialog != null)
            {
                modelDialog.Get<RadioButton>(SearchCriteria.ByAutomationId("54308", PropertyConditionFlags.None)).Click();
                modelDialog.WaitWhileBusy();
                modelDialog.Get(SearchCriteria.ByAutomationId("54314", PropertyConditionFlags.None)).Click();
                modelDialog.WaitWhileBusy();
                return true;
            }
            return false;
        }

        private static string ConvertSendKeyValue(string value)
        {
            value = value.Replace("[", "{[}");
            value = value.Replace("]", "{]}");
            value = value.Replace("(", "{(}");
            value = value.Replace(")", "{)}");
            return value;
        }

        private IWebDriver CreateWebDriver()
        {
            object obj2 = null;
            if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Firefox)
            {
                FirefoxProfile profile = new FirefoxProfile();
                profile.set_DeleteAfterUse(true);
                int num = 120;
                profile.SetPreference("browser.chrome.toolbar_tips", false);
                profile.SetPreference("dom.max_chrome_script_run_time", num);
                profile.SetPreference("dom.max_script_run_time", num);
                profile.SetPreference("browser.startup.page", 0);
                profile.SetPreference("browser.startup.homepage", "about:blank");
                profile.SetPreference("browser.startup.homepage_override.mstone", "ignore");
                profile.SetPreference("browser.usedOnWindows10", true);
                profile.SetPreference("browser.tabs.remote.force-enable", true);
                profile.SetPreference("browser.tabs.crashReporting.sendReport", false);
                profile.SetPreference("toolkit.asyncshutdown.crash_timeout", 100);
                obj2 = profile;
            }
            if (!this.Settings.IsRemote)
            {
                List<object> list = new List<object>();
                string driverPath = this.Settings.DriverPath;
                if (string.IsNullOrWhiteSpace(driverPath))
                {
                    Assembly assembly = typeof(Browser).Assembly;
                    string directoryName = Path.GetDirectoryName(assembly.Location);
                    if (AppDomain.CurrentDomain.ShadowCopyFiles)
                    {
                        Uri uri = new Uri(assembly.CodeBase);
                        directoryName = Path.GetDirectoryName(uri.LocalPath);
                    }
                    driverPath = directoryName;
                }
                list.Add(driverPath);
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Edge)
                {
                    list.Clear();
                    list.Add(EdgeDriverService.CreateDefaultService(driverPath));
                    EdgeOptions item = new EdgeOptions();
                    item.set_PageLoadStrategy(2);
                    list.Add(item);
                }
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Opera)
                {
                    list.Clear();
                    list.Add(OperaDriverService.CreateDefaultService(driverPath));
                    list.Add(new OperaOptions());
                }
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Firefox)
                {
                    list.Clear();
                    list.Add(FirefoxDriverService.CreateDefaultService(driverPath));
                    FirefoxOptions options2 = new FirefoxOptions();
                    options2.set_Profile((FirefoxProfile) obj2);
                    options2.AddAdditionalCapability("acceptInsecureCerts", true, true);
                    list.Add(options2);
                }
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE)
                {
                    InternetExplorerOptions options3 = new InternetExplorerOptions();
                    options3.AddAdditionalCapability(CapabilityType.AcceptSslCertificates, true);
                    options3.set_IntroduceInstabilityByIgnoringProtectedModeSettings(true);
                    options3.set_IgnoreZoomLevel(true);
                    options3.set_EnsureCleanSession(true);
                    list.Add(options3);
                }
                if ((this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Chrome) || (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.ChromeMobile))
                {
                    string tempPath = Path.GetTempPath();
                    if (Directory.Exists(tempPath))
                    {
                        string[] strArray = Directory.GetDirectories(tempPath, "scoped_dir*", SearchOption.TopDirectoryOnly);
                        if ((strArray != null) && (strArray.Length > 0))
                        {
                            for (int i = 0; i < strArray.Length; i++)
                            {
                                try
                                {
                                    Directory.Delete(strArray[i], true);
                                }
                                catch
                                {
                                }
                            }
                        }
                    }
                    string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                    folderPath = Path.Combine(new string[] { folderPath, "Google", "Chrome", "User Data", "Default", "Cache" });
                    if (Directory.Exists(folderPath))
                    {
                        try
                        {
                            Directory.Delete(folderPath, true);
                        }
                        catch
                        {
                        }
                    }
                    ChromeOptions options4 = new ChromeOptions();
                    options4.AddUserProfilePreference("credentials_enable_service", false);
                    options4.AddUserProfilePreference("password_manager_enabled", false);
                    options4.AddUserProfilePreference("profile.default_content_settings.popups", 0);
                    options4.AddUserProfilePreference("profile.default_content_settings.multiple-automatic-downloads", 1);
                    options4.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1);
                    options4.AddUserProfilePreference("profile.content_settings.exceptions.automatic_downloads.*.setting", 1);
                    options4.AddUserProfilePreference("download.prompt_for_download", false);
                    options4.AddArgument("--start-maximized");
                    options4.AddArgument("--enable-automation");
                    options4.AddArgument("--disable-infobars");
                    if (this.Settings.IsHeadless)
                    {
                        options4.AddArgument("--headless");
                        options4.AddArgument("--window-size=1280,1024");
                    }
                    list.Add(options4);
                }
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.ChromeMobile)
                {
                    ChromeOptions options5 = list[1] as ChromeOptions;
                    ChromeMobileEmulationDeviceSettings settings = new ChromeMobileEmulationDeviceSettings();
                    settings.set_UserAgent("Mozilla/5.0 (Linux; U; Android 4.0.3; zh-cn; M032 Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30");
                    settings.set_Width(360L);
                    settings.set_Height(640L);
                    settings.set_PixelRatio(3.0);
                    options5.EnableMobileEmulation(settings);
                    list.Add(TimeSpan.FromSeconds(120.0));
                    return (Activator.CreateInstance(typeof(ChromeMobileDriver), BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, list.ToArray(), CultureInfo.CurrentCulture) as IWebDriver);
                }
                if (this.Settings.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Chrome360se)
                {
                    string path = Path.GetTempPath();
                    if (Directory.Exists(path))
                    {
                        string[] strArray2 = Directory.GetDirectories(path, "scoped_dir*", SearchOption.TopDirectoryOnly);
                        if ((strArray2 != null) && (strArray2.Length > 0))
                        {
                            for (int j = 0; j < strArray2.Length; j++)
                            {
                                try
                                {
                                    Directory.Delete(strArray2[j], true);
                                }
                                catch
                                {
                                }
                            }
                        }
                    }
                    list.Clear();
                    list.Add(ChromeDriverService.CreateDefaultService(driverPath, "chrome360driver.exe"));
                    string str6 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"360se6\Application\360se.exe");
                    ChromeOptions options6 = new ChromeOptions();
                    options6.set_BinaryLocation(str6);
                    options6.AddUserProfilePreference("credentials_enable_service", false);
                    options6.AddUserProfilePreference("password_manager_enabled", false);
                    options6.AddArgument("--enable-automation");
                    options6.AddArgument("--disable-infobars");
                    list.Add(options6);
                }
                int commandTimeout = this.Settings.CommandTimeout;
                if (commandTimeout <= 0)
                {
                    commandTimeout = 120;
                }
                list.Add(TimeSpan.FromSeconds((double) commandTimeout));
                return (Activator.CreateInstance(typeof(IWebDriver).Assembly.GetType(this.Settings.DriverType), BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, list.ToArray(), CultureInfo.CurrentCulture) as IWebDriver);
            }
            DesiredCapabilities capabilities = null;
            switch (this.Settings.BrowserType)
            {
                case Selenium.Test.Toolkit.Core.BrowserType.Edge:
                    capabilities = DesiredCapabilities.Edge();
                    break;

                case Selenium.Test.Toolkit.Core.BrowserType.Opera:
                    capabilities = DesiredCapabilities.Opera();
                    break;

                case Selenium.Test.Toolkit.Core.BrowserType.IE:
                    capabilities = DesiredCapabilities.InternetExplorer();
                    break;

                case Selenium.Test.Toolkit.Core.BrowserType.Firefox:
                    capabilities = DesiredCapabilities.Firefox();
                    capabilities.SetCapability("javascriptEnabled", true);
                    if (obj2 != null)
                    {
                        capabilities.SetCapability("firefox_profile", obj2);
                    }
                    break;

                case Selenium.Test.Toolkit.Core.BrowserType.Chrome:
                    capabilities = DesiredCapabilities.Chrome();
                    break;

                case Selenium.Test.Toolkit.Core.BrowserType.Safari:
                    capabilities = DesiredCapabilities.Safari();
                    break;
            }
            object[] args = new object[] { new Uri(this.Settings.RemoteAddress), capabilities };
            return (Activator.CreateInstance(typeof(IWebDriver).Assembly.GetType(this.Settings.DriverType), BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, args, CultureInfo.CurrentCulture) as IWebDriver);
        }

        public virtual void Dispose()
        {
            this._settings = null;
            WindowsActions.ReleaseResource();
            if (this._webDriver != null)
            {
                try
                {
                    this._webDriver.Quit();
                    this._webDriver.Dispose();
                }
                catch
                {
                }
                this._webDriver = null;
            }
            if (this._browserWindow != null)
            {
                if (!this._browserWindow.IsClosed)
                {
                    try
                    {
                        this._browserWindow.Dispose();
                    }
                    catch
                    {
                    }
                }
                this._browserWindow = null;
            }
        }

        public string DownloadFile(Action action, int waitDownloadFileTimeout = 0xea60)
        {
            Func<bool> func2 = null;
            Func<bool> func3 = null;
            Func<bool> func4 = null;
            if (action == null)
            {
                throw new ArgumentException("Action is Null.");
            }
            if (this.IsRemote)
            {
                throw new InvalidOperationException("Current testing is Remote Browser, so can't do native download file operation.");
            }
            Manager.Current.ClearDownloadsFolder();
            int startFileCount = 0;
            string downloadsFolderPath = Manager.DownloadsFolderPath;
            DirectoryInfo info = new DirectoryInfo(downloadsFolderPath);
            if (info.Exists)
            {
                info.Attributes &= ~FileAttributes.ReadOnly;
                startFileCount = info.GetFiles().Length;
            }
            Window browserWindow = this.GetBrowserWindowFromDesktop();
            action();
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE)
            {
                bool isClickSaveButton = false;
                TestUtility.WaitFunc(delegate {
                    try
                    {
                        Panel panel = browserWindow.Get<Panel>(SearchCriteria.ByControlType(ControlType.Pane).AndByClassName("Frame Notification Bar", PropertyConditionFlags.None));
                        AutomationElement automationElement = this.FindWindowsControl(panel.AutomationElement, SearchCriteria.ByControlType(ControlType.SplitButton).AndNativeProperty(AutomationElementIdentifiers.AccessKeyProperty, "Alt+S", PropertyConditionFlags.IgnoreCase), null);
                        if (automationElement != null)
                        {
                            new Button(automationElement, panel.ActionListener).Click();
                            browserWindow.WaitWhileBusy();
                            isClickSaveButton = true;
                        }
                        if (isClickSaveButton && (automationElement == null))
                        {
                            return true;
                        }
                    }
                    catch
                    {
                    }
                    return false;
                }, 0x1388, true, "Wait Save Notification Bar timeout({0}s).");
            }
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Edge)
            {
                if (func2 == null)
                {
                    func2 = delegate {
                        try
                        {
                            IUIItem[] multiple = new UIItemContainer(this.FindWindowsControl(browserWindow.AutomationElement, "NotificationBarRootNode"), browserWindow.ActionListener).GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                            if (multiple.Length > 0)
                            {
                                IUIItem item = multiple[0];
                                if (item.Enabled)
                                {
                                    item.Click();
                                    browserWindow.WaitWhileBusy();
                                    return true;
                                }
                            }
                        }
                        catch
                        {
                        }
                        return false;
                    };
                }
                TestUtility.WaitFunc(func2, 0x1388, true, "Wait Save Notification Bar timeout({0}s).");
            }
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Firefox)
            {
                Func<bool> func = null;
                Window saveDialog = this.GetModelDialog(0x1388);
                if (saveDialog != null)
                {
                    saveDialog.Get(SearchCriteria.ByControlType(ControlType.RadioButton).AndNativeProperty(AutomationElementIdentifiers.AccessKeyProperty, "Alt+s", PropertyConditionFlags.IgnoreCase)).Click();
                    IUIItem[] itemArray = saveDialog.GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                    itemArray[itemArray.Length - 2].Click();
                    saveDialog.WaitWhileBusy();
                    if (func == null)
                    {
                        func = delegate {
                            bool isClosed = saveDialog.IsClosed;
                            if (!isClosed)
                            {
                                Thread.Sleep(500);
                            }
                            return isClosed;
                        };
                    }
                    TestUtility.WaitFunc(func, 0x1388, true, "Wait Save Save Dialog close timeout({0}s).");
                }
            }
            string downloadFile = string.Empty;
            TestUtility.WaitFunc(delegate {
                if (info.Exists)
                {
                    info.Attributes &= ~FileAttributes.ReadOnly;
                    FileInfo[] files = info.GetFiles();
                    if (files.Length > startFileCount)
                    {
                        FileInfo info1 = (from f in files
                            orderby f.LastWriteTime descending
                            select f).First<FileInfo>();
                        string extension = info1.Extension;
                        if ((!extension.Equals(".crdownload", StringComparison.OrdinalIgnoreCase) && !extension.Equals(".partial", StringComparison.OrdinalIgnoreCase)) && (!extension.Equals(".part", StringComparison.OrdinalIgnoreCase) && !extension.Equals(".tmp", StringComparison.OrdinalIgnoreCase)))
                        {
                            downloadFile = info1.FullName;
                            return true;
                        }
                    }
                }
                Thread.Sleep(500);
                return false;
            }, waitDownloadFileTimeout, true, "Wait Download file timeout({0}s).");
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Chrome)
            {
                if (func3 == null)
                {
                    func3 = delegate {
                        try
                        {
                            SearchCriteria searchCriteria = SearchCriteria.ByControlType(ControlType.Pane).AndByClassName("", PropertyConditionFlags.None);
                            if (!browserWindow.Exists(searchCriteria))
                            {
                                return true;
                            }
                            IUIItem[] multiple = browserWindow.Get<Panel>(searchCriteria).GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                            if (multiple.Length > 0)
                            {
                                multiple[multiple.Length - 1].Click();
                            }
                        }
                        catch
                        {
                        }
                        return false;
                    };
                }
                TestUtility.WaitFunc(func3, 0x1388, false, null);
            }
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Edge)
            {
                new UIItemContainer(this.FindWindowsControl(browserWindow.AutomationElement, "NotificationBarRootNode"), browserWindow.ActionListener).Get(SearchCriteria.ByAutomationId("NotificationBarCloseButton", PropertyConditionFlags.None)).Click();
            }
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE)
            {
                if (func4 == null)
                {
                    func4 = delegate {
                        try
                        {
                            SearchCriteria searchCriteria = SearchCriteria.ByControlType(ControlType.Pane).AndByClassName("Frame Notification Bar", PropertyConditionFlags.None);
                            if (!browserWindow.Exists(searchCriteria))
                            {
                                return true;
                            }
                            IUIItem[] multiple = browserWindow.Get<Panel>(searchCriteria).GetMultiple(SearchCriteria.ByControlType(ControlType.Button));
                            if (multiple.Length > 0)
                            {
                                IUIItem item = multiple[multiple.Length - 1];
                                if (item.Enabled)
                                {
                                    item.Click();
                                    browserWindow.WaitWhileBusy();
                                }
                            }
                        }
                        catch
                        {
                        }
                        return false;
                    };
                }
                TestUtility.WaitFunc(func4, 0x1388, false, null);
            }
            return downloadFile;
        }

        internal bool EnsureBrowserOnFocusIfPossible()
        {
            if (Manager.DoMessageFlushAfterAction && !this.SetWindowFocus())
            {
                throw new InvalidProgramException("Can't make browser activtor.");
            }
            return true;
        }

        public DomElementGUI FindDisplayedElementGUI(By by)
        {
            return this.FindDisplayedElementGUI<DomElementGUI>(by);
        }

        public T FindDisplayedElementGUI<T>(By by)
        {
            return this.FindDisplayedElementGUI<T>(by, false);
        }

        public T FindDisplayedElementGUI<T>(By by, bool throwExpection)
        {
            return TestUtility.FindDisplayedElementGUI<T>(this.WebDriver, by, throwExpection);
        }

        public IList<DomElementGUI> FindDisplayedElementGUIs(By by)
        {
            return TestUtility.FindDisplayedElementGUIs<DomElementGUI>(this.WebDriver, by);
        }

        public IList<T> FindDisplayedElementGUIs<T>(By by)
        {
            return TestUtility.FindDisplayedElementGUIs<T>(this.WebDriver, by);
        }

        public DomElementGUI FindElementGUI(By by)
        {
            return this.FindElementGUI<DomElementGUI>(by);
        }

        public T FindElementGUI<T>(By by)
        {
            return this.FindElementGUI<T>(by, true);
        }

        public T FindElementGUI<T>(By by, bool throwExpection)
        {
            return TestUtility.FindElementGUI<T>(this.WebDriver, by, throwExpection);
        }

        public IList<DomElementGUI> FindElementGUIs(By by)
        {
            return this.FindElementGUIs<DomElementGUI>(by);
        }

        public IList<T> FindElementGUIs<T>(By by)
        {
            return TestUtility.FindElementGUIs<T>(this.WebDriver, by);
        }

        private AutomationElement FindWindowsControl(AutomationElement element, string automationID)
        {
            foreach (AutomationElement element2 in element.FindAll(TreeScope.Children, Condition.TrueCondition))
            {
                string currentPropertyValue = (string) element2.GetCurrentPropertyValue(AutomationElement.AutomationIdProperty);
                if ((currentPropertyValue != null) && currentPropertyValue.Equals(automationID, StringComparison.OrdinalIgnoreCase))
                {
                    return element2;
                }
                ControlType type = (ControlType) element2.GetCurrentPropertyValue(AutomationElement.ControlTypeProperty);
                if ((((type == ControlType.Group) || (type == ControlType.Custom)) || ((type == ControlType.Pane) || (type == ControlType.Tab))) || ((type == ControlType.TabItem) || (type == ControlType.Window)))
                {
                    AutomationElement element3 = this.FindWindowsControl(element2, automationID);
                    if (element3 != null)
                    {
                        return element3;
                    }
                }
            }
            return null;
        }

        private AutomationElement FindWindowsControl(AutomationElement element, SearchCriteria searchCriteria, Func<AutomationElement, bool> callBack = null)
        {
            foreach (AutomationElement element2 in element.FindAll(TreeScope.Children, Condition.TrueCondition))
            {
                if (searchCriteria.AppliesTo(element2) && ((callBack == null) || ((callBack != null) && callBack(element2))))
                {
                    return element2;
                }
                ControlType currentPropertyValue = (ControlType) element2.GetCurrentPropertyValue(AutomationElement.ControlTypeProperty);
                if ((((currentPropertyValue == ControlType.Group) || (currentPropertyValue == ControlType.ToolBar)) || ((currentPropertyValue == ControlType.Custom) || (currentPropertyValue == ControlType.Pane))) || (((currentPropertyValue == ControlType.Tab) || (currentPropertyValue == ControlType.TabItem)) || (currentPropertyValue == ControlType.Window)))
                {
                    AutomationElement element3 = this.FindWindowsControl(element2, searchCriteria, null);
                    if (element3 != null)
                    {
                        return element3;
                    }
                }
            }
            return null;
        }

        public void Forward()
        {
            this.WebDriver.Navigate().Forward();
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            PageGUI.CurrentPageTypeName = string.Empty;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        internal Process GetBrowserProcess()
        {
            Window browserWindowFromDesktop = this.GetBrowserWindowFromDesktop();
            if (browserWindowFromDesktop == null)
            {
                return null;
            }
            return Process.GetProcessById(browserWindowFromDesktop.AutomationElement.Current.ProcessId);
        }

        internal Window GetBrowserWindowFromDesktop()
        {
            if (this._browserWindow != null)
            {
                return this._browserWindow;
            }
            Window window = null;
            string str = this.WebDriver.get_Title();
            if (str != null)
            {
                str = str.Replace("http://", string.Empty).Replace("https://", string.Empty);
            }
            IntPtr foregroundWindow = Win32NativeMethods.GetForegroundWindow();
            if (foregroundWindow != IntPtr.Zero)
            {
                AutomationElement automationElement = AutomationElement.FromHandle(foregroundWindow);
                if ((automationElement != null) && automationElement.Current.Name.Contains(str))
                {
                    this._browserWindow = new Win32Window(automationElement, WindowFactory.Desktop, InitializeOption.NoCache, new NullWindowSession());
                    return this._browserWindow;
                }
            }
            foreach (Window window2 in Desktop.Instance.Windows())
            {
                if (window2.AutomationElement.Current.Name.Contains(str))
                {
                    if (window2.AutomationElement.Current.NativeWindowHandle == Win32NativeMethods.GetForegroundWindow().ToInt32())
                    {
                        this._browserWindow = window2;
                        return window2;
                    }
                    window = window2;
                }
            }
            this._browserWindow = window;
            return window;
        }

        internal Rectangle GetElementRectangleByScreem(IWebElement webElement)
        {
            int documentScrollLeft = this.DocumentScrollLeft;
            int documentScrollTop = this.DocumentScrollTop;
            DomElementGUI tgui = new DomElementGUI(webElement);
            Rectangle rectangle = new Rectangle(tgui.Location, tgui.Size);
            rectangle.Offset(-documentScrollLeft, -documentScrollTop);
            rectangle.Offset(this.ContentRectangle.Location);
            return rectangle;
        }

        public Bitmap GetFullScreenshot()
        {
            if (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE)
            {
                using (MemoryStream stream = new MemoryStream(((ITakesScreenshot) this.WebDriver).GetScreenshot().get_AsByteArray()))
                {
                    return new Bitmap(stream);
                }
            }
            int documentScrollLeft = this.DocumentScrollLeft;
            int documentScrollTop = this.DocumentScrollTop;
            this.BOMWindow.scrollTo(0, 0);
            DomElementGUI body = this.Body;
            int clientWidth = body.clientWidth;
            int clientHeight = body.clientHeight;
            DomElementGUI documentElement = this.Document.documentElement;
            int num5 = documentElement.clientWidth;
            int num6 = documentElement.clientHeight;
            List<Rectangle> list = new List<Rectangle>();
            for (int i = 0; i < clientHeight; i += num6)
            {
                int height = num6;
                if ((i + num6) > clientHeight)
                {
                    height = clientHeight - i;
                }
                for (int j = 0; j < clientWidth; j += num5)
                {
                    int width = num5;
                    if ((j + num5) > clientWidth)
                    {
                        width = clientWidth - j;
                    }
                    Rectangle item = new Rectangle(j, i, width, height);
                    list.Add(item);
                }
            }
            Bitmap bitmap = new Bitmap(clientWidth, clientHeight);
            Rectangle empty = Rectangle.Empty;
            foreach (Rectangle rectangle3 in list)
            {
                if (empty != Rectangle.Empty)
                {
                    int x = rectangle3.Right - empty.Right;
                    int y = rectangle3.Bottom - empty.Bottom;
                    this.BOMWindow.scrollBy(x, y);
                    Thread.Sleep(200);
                }
                using (MemoryStream stream2 = new MemoryStream(((ITakesScreenshot) this.WebDriver).GetScreenshot().get_AsByteArray()))
                {
                    using (Image image = Image.FromStream(stream2))
                    {
                        Rectangle srcRect = new Rectangle(num5 - rectangle3.Width, num6 - rectangle3.Height, rectangle3.Width, rectangle3.Height);
                        using (Graphics graphics = Graphics.FromImage(bitmap))
                        {
                            graphics.DrawImage(image, rectangle3, srcRect, GraphicsUnit.Pixel);
                        }
                    }
                }
                empty = rectangle3;
            }
            this.BOMWindow.scrollTo(documentScrollLeft, documentScrollTop);
            return bitmap;
        }

        private Window GetIEDialogPanelWindow()
        {
            foreach (Window window in Desktop.Instance.Windows())
            {
                if (window.AutomationElement.Current.ClassName.Equals("Alternate Modal Top Most", StringComparison.OrdinalIgnoreCase))
                {
                    return window;
                }
            }
            return null;
        }

        public Window GetModelDialog(int timeout)
        {
            Window browserWindowFromDesktop = this.GetBrowserWindowFromDesktop();
            if (browserWindowFromDesktop != null)
            {
                List<Window> list = new List<Window>();
                DateTime now = DateTime.Now;
                while (DateTime.Now.Subtract(now) < TimeSpan.FromMilliseconds((double) timeout))
                {
                    list.Clear();
                    if ((this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE) || (this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Edge))
                    {
                        Window iEDialogPanelWindow = this.GetIEDialogPanelWindow();
                        if (iEDialogPanelWindow != null)
                        {
                            browserWindowFromDesktop = iEDialogPanelWindow;
                        }
                    }
                    try
                    {
                        list = browserWindowFromDesktop.ModalWindows();
                    }
                    catch
                    {
                        try
                        {
                            AutomationElement automationElement = this.FindWindowsControl(browserWindowFromDesktop.AutomationElement, SearchCriteria.ByControlType(ControlType.Window), null);
                            if (automationElement != null)
                            {
                                list.Add(new Win32Window(automationElement, WindowFactory.Desktop, InitializeOption.NoCache, new NullWindowSession()));
                            }
                        }
                        catch
                        {
                        }
                    }
                    foreach (Window window3 in list)
                    {
                        try
                        {
                            string className = window3.AutomationElement.Current.ClassName;
                            if (!string.IsNullOrWhiteSpace(className))
                            {
                                if (className.Equals("#32770", StringComparison.OrdinalIgnoreCase))
                                {
                                    return window3;
                                }
                                if ((this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.Firefox) && className.Equals("MozillaDialogClass", StringComparison.OrdinalIgnoreCase))
                                {
                                    return window3;
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                    Thread.Sleep(500);
                    this.GetBrowserProcess().WaitForInputIdle();
                }
            }
            return null;
        }

        public void GoToUrl(string url)
        {
            this.WebDriver.Navigate().GoToUrl(url);
            if (this.CheckBrowserLaunchStatus)
            {
                if ((this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE) && this.ComfirmIERecommendedSettingsDialog())
                {
                    this.WebDriver.Navigate().GoToUrl(url);
                }
                this.CheckBrowserLaunchStatus = false;
            }
            this.CheckHTTPSWebsite(url);
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            PageGUI.CurrentPageTypeName = string.Empty;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        public void GoToUrl(Uri url)
        {
            this.WebDriver.Navigate().GoToUrl(url);
            if (this.CheckBrowserLaunchStatus)
            {
                if ((this.BrowserType == Selenium.Test.Toolkit.Core.BrowserType.IE) && this.ComfirmIERecommendedSettingsDialog())
                {
                    this.WebDriver.Navigate().GoToUrl(url);
                }
                this.CheckBrowserLaunchStatus = false;
            }
            this.CheckHTTPSWebsite(url.ToString());
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            PageGUI.CurrentPageTypeName = string.Empty;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        public virtual void InjectJS(string jsContent)
        {
            ExecutableObject.InjectJS(jsContent);
        }

        internal bool IsAjaxRequestComplete()
        {
            string str = "var result = true; if (window.Sys != undefined && window.Sys.WebForms != undefined && window.Sys.WebForms.PageRequestManager != undefined) result = !Sys.WebForms.PageRequestManager.getInstance().get_isInAsyncPostBack();else if (window.jQuery)result = !jQuery.active;return result;";
            if (this.WebDriver != null)
            {
                if (!Manager.IgnoreAssertAlertDialog)
                {
                    try
                    {
                        this.WebDriver.SwitchTo().Alert();
                        return true;
                    }
                    catch
                    {
                    }
                }
                try
                {
                    return Convert.ToBoolean((this.WebDriver as IJavaScriptExecutor).ExecuteScript(str, new object[0]));
                }
                catch (Exception exception)
                {
                    if (!(exception is UnhandledAlertException))
                    {
                        throw exception;
                    }
                    return true;
                }
            }
            return false;
        }

        public virtual void LinkCSS(string herf, int timeout = -1)
        {
            GrapeCityAutoTest testCore;
            if (!string.IsNullOrWhiteSpace(herf))
            {
                if (timeout <= 0)
                {
                    timeout = PageGUI.PageLoadedTimeout;
                }
                testCore = this.BuildInTestObj;
                testCore.loadStylesheet(herf);
                TestUtility.WaitFunc(delegate {
                    bool loadStylesheetComplete = testCore.loadStylesheetComplete;
                    if (!loadStylesheetComplete)
                    {
                        Thread.Sleep(500);
                    }
                    return loadStylesheetComplete;
                }, timeout, true, string.Format("Wait load stylesheet[herf = '{0}'] ", herf) + "timeout({0}s).");
            }
        }

        public virtual void LinkFiles(params string[] src)
        {
            for (int i = 0; i < src.Length; i++)
            {
                string str = src[i];
                if (str.Trim().EndsWith(".js", StringComparison.OrdinalIgnoreCase))
                {
                    this.AddScript(str, -1);
                }
                else
                {
                    if (!str.Trim().EndsWith(".css", StringComparison.OrdinalIgnoreCase))
                    {
                        throw new ArgumentException(string.Format("Can't add the file[{0}] into head resource.", str));
                    }
                    this.AddStyleSheet(str);
                }
            }
        }

        public void Maximize()
        {
            this._catchedBrowserContentBounds = Rectangle.Empty;
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            try
            {
                this.WebDriver.Manage().get_Window().Maximize();
            }
            catch (Exception)
            {
            }
        }

        public void Refresh()
        {
            this.WebDriver.Navigate().Refresh();
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            PageGUI.CurrentPageTypeName = string.Empty;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        internal bool SetWindowFocus()
        {
            if (this.WebDriver != null)
            {
                Window browserWindowFromDesktop = this.GetBrowserWindowFromDesktop();
                int nativeWindowHandle = browserWindowFromDesktop.AutomationElement.Current.NativeWindowHandle;
                if (nativeWindowHandle == Win32NativeMethods.GetForegroundWindow().ToInt32())
                {
                    return true;
                }
                try
                {
                    browserWindowFromDesktop.Focus();
                    browserWindowFromDesktop.WaitWhileBusy();
                }
                catch
                {
                }
                if (nativeWindowHandle == Win32NativeMethods.GetForegroundWindow().ToInt32())
                {
                    return true;
                }
            }
            return false;
        }

        public void SwitchToDefaultContent()
        {
            this.WebDriver.SwitchTo().DefaultContent();
            this._catchedCurrentURL = this.WebDriver.get_Url();
            this._catchedContentBounds = Rectangle.Empty;
        }

        public void SwitchToDefaultWindow()
        {
            if (!string.IsNullOrEmpty(this.MainWindowHandle) && (this.WebDriver.get_CurrentWindowHandle() != this.MainWindowHandle))
            {
                this.CloseCurrentWindow();
                this.SwitchToWindow(this.MainWindowHandle);
            }
        }

        public void SwitchToFrame(WebElementGUI frame)
        {
            frame.TryToScrollElementIntoView();
            this._catchedContentBounds = this.GetElementRectangleByScreem(frame.WebElement);
            this.WebDriver.SwitchTo().Frame(frame.WebElement);
            this._catchedCurrentURL = this.WebDriver.get_Url();
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        public void SwitchToWindow(string windowName)
        {
            if (string.IsNullOrEmpty(this.MainWindowHandle))
            {
                this.MainWindowHandle = this.WebDriver.get_CurrentWindowHandle();
            }
            this.WebDriver.SwitchTo().Window(windowName);
            this._catchedContentBounds = Rectangle.Empty;
            this._catchedCurrentURL = null;
            Manager.Current.ErrorWatcher.StartWatchError();
        }

        public void SwitchToWindow(Action action = null, int waitWindowTimeout = 0x2710)
        {
            ReadOnlyCollection<string> onlys = this.WebDriver.get_WindowHandles();
            if (string.IsNullOrEmpty(this.MainWindowHandle))
            {
                this.MainWindowHandle = this.WebDriver.get_CurrentWindowHandle();
            }
            if (action != null)
            {
                action();
            }
            string str = null;
            DateTime now = DateTime.Now;
            while (DateTime.Now.Subtract(now) < TimeSpan.FromMilliseconds((double) waitWindowTimeout))
            {
                foreach (string str2 in this.WebDriver.get_WindowHandles())
                {
                    if (((action != null) && !onlys.Contains(str2)) || ((action == null) && (this.MainWindowHandle != str2)))
                    {
                        str = str2;
                        break;
                    }
                }
                if (!string.IsNullOrEmpty(str))
                {
                    break;
                }
                Thread.Sleep(300);
            }
            if (string.IsNullOrEmpty(str))
            {
                throw new NoSuchWindowException("Can't find expected new browser window or tab.");
            }
            this.SwitchToWindow(str);
        }

        public Bitmap UISnap(params WebElementGUI[] elements)
        {
            WebElementGUI tgui3;
            if (elements == null)
            {
                return null;
            }
            DomElementGUI tgui = new DomElementGUI(By.TagName("body"));
            Rectangle empty = Rectangle.Empty;
            WebElementGUI tgui2 = (WebElementGUI) (tgui3 = null);
            for (int i = 0; i < elements.Length; i++)
            {
                WebElementGUI tgui4 = elements[i];
                Rectangle domElementBounds = tgui4.GetDomElementBounds();
                if (tgui2 == null)
                {
                    tgui2 = tgui3 = tgui4;
                }
                else
                {
                    if (domElementBounds.Right > tgui2.GetDomElementBounds().Right)
                    {
                        tgui2 = tgui4;
                    }
                    if (domElementBounds.Bottom > tgui3.GetDomElementBounds().Bottom)
                    {
                        tgui3 = tgui4;
                    }
                }
            }
            if (tgui2 != null)
            {
                tgui2.scrollIntoView();
            }
            if (tgui3 != null)
            {
                tgui3.scrollIntoView();
            }
            for (int j = 0; j < elements.Length; j++)
            {
                if (empty == Rectangle.Empty)
                {
                    empty = elements[j].GetDomElementBounds();
                }
                else
                {
                    empty = Rectangle.Union(empty, elements[j].GetDomElementBounds());
                }
            }
            return tgui.UISnap(empty, false);
        }

        public JSObject UploadFile(string file)
        {
            if (!File.Exists(file))
            {
                throw new ArgumentException(string.Format("Invalid File path[{0}].", file));
            }
            string str = string.Empty;
            using (FileStream stream = new FileStream(file, FileMode.Open))
            {
                byte[] buffer = new byte[stream.Length];
                stream.Read(buffer, 0, buffer.Length);
                str = Convert.ToBase64String(buffer);
            }
            string str2 = null;
            switch (Path.GetExtension(file).Remove(0, 1).ToLower())
            {
                case "xls":
                case "xlt":
                    str2 = "application/vnd.ms-excel";
                    break;

                case "xlsx":
                    str2 = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    break;

                case "xltx":
                    str2 = "application/vnd.openxmlformats-officedocument.spreadsheetml.template";
                    break;

                case "doc":
                case "dot":
                    str2 = "application/msword";
                    break;

                case "docx":
                    str2 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                    break;

                case "dotx":
                    str2 = "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
                    break;

                case "pps":
                case "ppt":
                case "pot":
                    str2 = "application/vnd.ms-powerpoint";
                    break;

                case "pptx":
                    str2 = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                    break;

                case "pdf":
                    str2 = "application/pdf";
                    break;

                case "prf":
                    str2 = "application/pics-rules";
                    break;

                case "msg":
                    str2 = "application/vnd.ms-pkicertstore";
                    break;

                case "txt":
                    str2 = "text/plain";
                    break;

                case "csv":
                    str2 = "text/csv";
                    break;

                case "ai":
                case "ps":
                case "eps":
                    str2 = "application/postscript";
                    break;

                case "mdb":
                    str2 = "application/x-msaccess";
                    break;

                case "sql":
                    str2 = "application/sql";
                    break;

                case "dbf":
                    str2 = "application/x-dbf";
                    break;

                case "wcm":
                case "wdb":
                case "wks":
                    str2 = "application/vnd.ms-works";
                    break;

                case "html":
                case "htm":
                    str2 = "text/html";
                    break;

                case "css":
                    str2 = "text/css";
                    break;

                case "js":
                    str2 = "application/javascript";
                    break;

                case "json":
                    str2 = "application/json";
                    break;

                case "xml":
                    str2 = "application/xml";
                    break;

                case "php":
                    str2 = "text/x-php";
                    break;

                case "c":
                case "h":
                case "java":
                case "sln":
                case "cs":
                    str2 = "text/plain";
                    break;

                case "jar":
                    str2 = "application/java-archive";
                    break;

                case "dll":
                    str2 = "application/x-msdownload";
                    break;

                case "jpg":
                case "jpeg":
                case "jpe":
                    str2 = "image/jpeg";
                    break;

                case "bmp":
                    str2 = "image/bmp";
                    break;

                case "png":
                    str2 = "image/png";
                    break;

                case "gif":
                    str2 = "image/gif";
                    break;

                case "svg":
                    str2 = "image/svg+xml";
                    break;

                case "ico":
                    str2 = "image/x-icon";
                    break;

                case "tif":
                case "tiff":
                    str2 = "image/tiff";
                    break;

                case "mp3":
                    str2 = "audio/x-mpeg";
                    break;

                case "wav":
                    str2 = "audio/wav";
                    break;

                case "wma":
                    str2 = "audio/x-ms-wma";
                    break;

                case "ogg":
                    str2 = "audio/ogg";
                    break;

                case "mpga":
                    str2 = "audio/mpeg";
                    break;

                case "wmv":
                    str2 = "video/x-ms-wmv";
                    break;

                case "avi":
                    str2 = "video/x-msvideo";
                    break;

                case "mp4":
                case "mpg4":
                    str2 = "video/mp4";
                    break;

                case "mpg":
                case "mpeg":
                    str2 = "video/mpeg";
                    break;

                case "swf":
                    str2 = "application/x-shockwave-flash";
                    break;

                case "mov":
                    str2 = "video/quicktime";
                    break;

                case "flv":
                    str2 = "video/x-flv";
                    break;

                case "mkv":
                    str2 = "video/x-matroska";
                    break;

                case "rar":
                    str2 = "application/x-rar-compressed";
                    break;

                case "zip":
                    str2 = "application/x-zip-compressed";
                    break;

                case "z":
                    str2 = "application/x-compress";
                    break;

                case "tar":
                    str2 = "application/x-tar";
                    break;

                case "gzip":
                case "tgz":
                    str2 = "application/gzip";
                    break;

                case "7z":
                    str2 = "application/x-7z-compressed";
                    break;

                case "bz":
                case "bz2":
                case "tbz":
                    str2 = "application/x-bzip2";
                    break;

                default:
                    str2 = "application/octet-stream";
                    break;
            }
            int length = str.Length;
            int startIndex = 0;
            List<string> list = new List<string>();
            while ((length - startIndex) > 0)
            {
                int num3 = 0xc350;
                if ((startIndex + num3) > length)
                {
                    list.Add(str.Substring(startIndex));
                }
                else
                {
                    list.Add(str.Substring(startIndex, num3));
                }
                startIndex += num3;
            }
            CodeSnippet dependedScript = JSConverterBase.GetTypeConverter(typeof(string)).ConvertToJavaScript(list[0], "fileContentStr1");
            if (list.Count > 1)
            {
                string newCodeHeader = ExecutableObject.GetNewCodeHeader("fileContentStr");
                ExecutableObject obj2 = new ExecutableObject(new CodeSnippet(newCodeHeader, string.Format("{0} = '';", newCodeHeader), new object[0]));
                dependedScript = obj2.DependedScript;
                for (int i = 0; i < list.Count; i++)
                {
                    CodeSnippet snippet2 = JSConverterBase.GetTypeConverter(typeof(string)).ConvertToJavaScript(list[i], "fileContentStr" + i);
                    string snippet = snippet2.Snippet + string.Format("{0} = {0} + {1};", dependedScript.CodeHeader, snippet2.CodeHeader);
                    if (i == 0)
                    {
                        snippet = dependedScript.Snippet + snippet;
                    }
                    obj2.ExecuteJS(new CodeSnippet(dependedScript.CodeHeader, snippet, new object[0]));
                }
                dependedScript = new CodeSnippet(dependedScript.CodeHeader, string.Empty, new object[0]);
            }
            FunctionObject obj3 = new FunctionObject(new CodeSnippet("uploadFunc", "var uploadFunc=function(urlData, fileType){var bytes=window.atob(urlData),n=bytes.length,u8arr=new Uint8Array(n);while(n--){u8arr[n]=bytes.charCodeAt(n);}return new Blob([u8arr], {type:fileType});};", new object[0]));
            JSObject obj4 = new JSObject(obj3.InvokeFunction<CodeSnippet>(new object[] { dependedScript, str2 }));
            new JSObject(dependedScript).ReleaseJSObject();
            return obj4;
        }

        public void UploadFileByFileDialog(string file, int waitDialogTimeout = 0x2710)
        {
            Window modelDialog = this.GetModelDialog(waitDialogTimeout);
            if (modelDialog == null)
            {
                throw new InvalidOperationException(string.Format("Can't find OpenFile dialog in {0}s.", waitDialogTimeout / 0x3e8));
            }
            ComboBox box = null;
            try
            {
                box = modelDialog.Get<ComboBox>(SearchCriteria.ByAutomationId("1148", PropertyConditionFlags.None));
            }
            catch
            {
                AutomationElement element = this.FindWindowsControl(modelDialog.AutomationElement, "1148");
                if (element == null)
                {
                    throw new InvalidProgramException("Can't find Edit element in OpenFileDialog.");
                }
                box = new ComboBox(element, modelDialog.ActionListener);
            }
            box.EditableText = string.Empty;
            box.Click();
            SendKeys.SendWait(ConvertSendKeyValue(file));
            SendKeys.Flush();
            modelDialog.WaitWhileBusy();
            AutomationElement automationElement = this.FindWindowsControl(modelDialog.AutomationElement, "1");
            if (automationElement == null)
            {
                throw new InvalidOperationException("Can't find Open Button in OpenFileDialog.");
            }
            new Button(automationElement, modelDialog.ActionListener).Click();
            modelDialog.WaitWhileBusy();
            DateTime now = DateTime.Now;
            while (DateTime.Now.Subtract(now) < TimeSpan.FromMilliseconds((double) waitDialogTimeout))
            {
                if (modelDialog.IsClosed)
                {
                    return;
                }
                Thread.Sleep(500);
            }
            throw new InvalidOperationException(string.Format("OpenFileDialog can't be closed in {0}s.", waitDialogTimeout / 0x3e8));
        }

        public void UploadMultiFileByFileDialog(string filePath, string file, int waitDialogTimeout = 0x2710)
        {
            Window modelDialog = this.GetModelDialog(waitDialogTimeout);
            if (modelDialog == null)
            {
                throw new InvalidOperationException(string.Format("Can't find OpenFile dialog in {0}s.", waitDialogTimeout / 0x3e8));
            }
            ComboBox editControl = null;
            try
            {
                editControl = modelDialog.Get<ComboBox>(SearchCriteria.ByAutomationId("1148", PropertyConditionFlags.None));
            }
            catch
            {
                AutomationElement element = this.FindWindowsControl(modelDialog.AutomationElement, "1148");
                if (element == null)
                {
                    throw new InvalidProgramException("Can't find Edit element in OpenFileDialog.");
                }
                editControl = new ComboBox(element, modelDialog.ActionListener);
            }
            editControl.EditableText = string.Empty;
            editControl.Click();
            SendKeys.SendWait(ConvertSendKeyValue(filePath));
            SendKeys.Flush();
            modelDialog.WaitWhileBusy();
            AutomationElement automationElement = this.FindWindowsControl(modelDialog.AutomationElement, "1");
            if (automationElement == null)
            {
                throw new InvalidOperationException("Can't find Open Button in OpenFileDialog.");
            }
            Button button = new Button(automationElement, modelDialog.ActionListener);
            button.Click();
            modelDialog.WaitWhileBusy();
            editControl = null;
            try
            {
                editControl = modelDialog.Get<ComboBox>(SearchCriteria.ByAutomationId("1148", PropertyConditionFlags.None));
            }
            catch
            {
                AutomationElement element3 = this.FindWindowsControl(modelDialog.AutomationElement, "1148");
                if (element3 == null)
                {
                    throw new InvalidProgramException("Can't find Edit element in OpenFileDialog.");
                }
                editControl = new ComboBox(element3, modelDialog.ActionListener);
            }
            TestUtility.WaitFunc(() => editControl.Enabled, waitDialogTimeout / 2, true, "Path edit can't enabled in OpenFileDialog.");
            editControl.EditableText = string.Empty;
            editControl.Click();
            SendKeys.SendWait(ConvertSendKeyValue(file));
            SendKeys.Flush();
            modelDialog.WaitWhileBusy();
            button.Click();
            modelDialog.WaitWhileBusy();
            DateTime now = DateTime.Now;
            while (DateTime.Now.Subtract(now) < TimeSpan.FromMilliseconds((double) waitDialogTimeout))
            {
                if (modelDialog.IsClosed)
                {
                    return;
                }
                Thread.Sleep(500);
            }
            throw new InvalidOperationException(string.Format("OpenFileDialog can't be closed in {0}s.", waitDialogTimeout / 0x3e8));
        }

        public DomElementGUI WaitFindDisplayedElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindDisplayedElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindDisplayedElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            return TestUtility.WaitFindDisplayElementGUI<T>(this.WebDriver, this.WebDriver, new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindDisplayedElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindDisplayedElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindDisplayedElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindDisplayedElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            return TestUtility.WaitFindDisplayElementGUI<T>(this.WebDriver, this.WebDriver, by, throwExpection, timeout);
        }

        public DomElementGUI WaitFindElementByText(By by, string text, TextFindCondition condition, TextComparison comparison = 1)
        {
            return this.WaitFindElementByText<DomElementGUI>(by, text, condition, comparison, true, -1);
        }

        public T WaitFindElementByText<T>(By by, string text, TextFindCondition condition, TextComparison comparison = 1, bool throwExpection = true, int timeout = -1)
        {
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            return TestUtility.WaitFindElementGUI<T>(this.WebDriver, this.WebDriver, new ByContentText(by, text, condition, comparison, this.UseResourceTextFinder), throwExpection, timeout);
        }

        public DomElementGUI WaitFindElementGUI(By by, int timeout)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, true, timeout);
        }

        public T WaitFindElementGUI<T>(By by, int timeout)
        {
            return this.WaitFindElementGUI<T>(by, true, timeout);
        }

        public DomElementGUI WaitFindElementGUI(By by, bool throwExpection = true, int timeout = -1)
        {
            return this.WaitFindElementGUI<DomElementGUI>(by, throwExpection, timeout);
        }

        public T WaitFindElementGUI<T>(By by, bool throwExpection = true, int timeout = -1)
        {
            if (timeout < 0)
            {
                timeout = PageGUI.PageFindElementTimeout;
            }
            return TestUtility.WaitFindElementGUI<T>(this.WebDriver, this.WebDriver, by, throwExpection, timeout);
        }

        public void WaitForAjax(int timeout = 0x1388)
        {
            Func<IWebDriver, bool> func = null;
            try
            {
                WebDriverWait wait = new WebDriverWait(this.WebDriver, TimeSpan.FromMilliseconds((double) timeout));
                if (func == null)
                {
                    func = delegate (IWebDriver d) {
                        bool flag = this.IsAjaxRequestComplete();
                        if (!flag)
                        {
                            Thread.Sleep(300);
                        }
                        return flag;
                    };
                }
                wait.Until<bool>(func);
            }
            catch
            {
            }
        }

        public virtual DomElementGUI ActiveElement
        {
            get
            {
                string str = "return document.activeElement;";
                IWebElement element = (IWebElement) (this.WebDriver as IJavaScriptExecutor).ExecuteScript(str, new object[0]);
                if (element != null)
                {
                    return new DomElementGUI(element);
                }
                return null;
            }
        }

        public IAlert Alert
        {
            get
            {
                Func<IWebDriver, bool> func = null;
                IAlert alert;
                if (Manager.IgnoreAssertAlertDialog)
                {
                    return MockAlert.Instance;
                }
                int num = 0x7530;
                WebDriverWait wait = new WebDriverWait(this.WebDriver, TimeSpan.FromMilliseconds((double) num));
                try
                {
                    if (func == null)
                    {
                        func = delegate (IWebDriver d) {
                            try
                            {
                                this.WebDriver.SwitchTo().Alert();
                                return true;
                            }
                            catch
                            {
                                Thread.Sleep(500);
                                return false;
                            }
                        };
                    }
                    wait.Until<bool>(func);
                    alert = this.WebDriver.SwitchTo().Alert();
                }
                catch
                {
                    throw new InvalidProgramException(string.Format("Can't find Alert dialog until timeout {0}.", num));
                }
                return alert;
            }
        }

        public DomElementGUI Body
        {
            get
            {
                return this.BOMWindow.document.body;
            }
        }

        public Window BOMWindow
        {
            get
            {
                return new Window();
            }
        }

        internal Rectangle BrowserContentRectangle
        {
            get
            {
                if (this.WebDriver == null)
                {
                    return Rectangle.Empty;
                }
                if (this._catchedBrowserContentBounds != Rectangle.Empty)
                {
                    return this._catchedBrowserContentBounds;
                }
                Window browserWindowFromDesktop = this.GetBrowserWindowFromDesktop();
                IUIItem item = null;
                Selenium.Test.Toolkit.Core.BrowserType browserType = this.BrowserType;
                if (browserType <= Selenium.Test.Toolkit.Core.BrowserType.Edge)
                {
                    switch (browserType)
                    {
                        case Selenium.Test.Toolkit.Core.BrowserType.IE:
                            item = browserWindowFromDesktop.Get(SearchCriteria.ByClassName("Internet Explorer_Server", PropertyConditionFlags.None).AndControlType(ControlType.Pane));
                            goto Label_01E3;

                        case Selenium.Test.Toolkit.Core.BrowserType.Firefox:
                        {
                            DateTime now = DateTime.Now;
                            while (DateTime.Now.Subtract(now) < TimeSpan.FromSeconds(10.0))
                            {
                                AutomationElement automationElement = this.FindWindowsControl(browserWindowFromDesktop.AutomationElement, SearchCriteria.ByControlType(ControlType.Document), null);
                                if (automationElement == null)
                                {
                                    automationElement = this.FindWindowsControl(browserWindowFromDesktop.AutomationElement, SearchCriteria.ByControlType(ControlType.Custom), element => element.Current.BoundingRectangle.Width > 600.0);
                                }
                                if (automationElement != null)
                                {
                                    item = new UIItem(automationElement, browserWindowFromDesktop.ActionListener);
                                    break;
                                }
                                Thread.Sleep(300);
                            }
                            goto Label_01E3;
                        }
                        case Selenium.Test.Toolkit.Core.BrowserType.Chrome:
                            item = browserWindowFromDesktop.Get(SearchCriteria.ByControlType(ControlType.Document));
                            goto Label_01E3;

                        case Selenium.Test.Toolkit.Core.BrowserType.Edge:
                        {
                            Window bOMWindow = this.BOMWindow;
                            int jSProperty = bOMWindow.GetJSProperty<int>("screenTop");
                            int num2 = bOMWindow.GetJSProperty<int>("screenLeft");
                            System.Drawing.Size size = this.Size;
                            this._catchedBrowserContentBounds = new Rectangle(num2, jSProperty, size.Width, size.Height);
                            return this._catchedBrowserContentBounds;
                        }
                    }
                }
                else
                {
                    switch (browserType)
                    {
                        case Selenium.Test.Toolkit.Core.BrowserType.Opera:
                        case Selenium.Test.Toolkit.Core.BrowserType.Chrome360se:
                            item = browserWindowFromDesktop.Get(SearchCriteria.ByClassName("Chrome_RenderWidgetHostHWND", PropertyConditionFlags.None).AndControlType(ControlType.Pane));
                            goto Label_01E3;
                    }
                    if (browserType == Selenium.Test.Toolkit.Core.BrowserType.ALL)
                    {
                    }
                }
                throw new NotImplementedException();
            Label_01E3:
                if (item == null)
                {
                    throw new InvalidOperationException("Can't get browser document rectange.");
                }
                Rect bounds = item.Bounds;
                int x = Convert.ToInt32(bounds.X);
                int y = Convert.ToInt32(bounds.Y);
                int width = Convert.ToInt32(bounds.Width);
                Rectangle rectangle = new Rectangle(x, y, width, Convert.ToInt32(bounds.Height));
                this._catchedBrowserContentBounds = rectangle;
                return rectangle;
            }
        }

        public Selenium.Test.Toolkit.Core.BrowserType BrowserType
        {
            get
            {
                return this.Settings.BrowserType;
            }
        }

        public GrapeCityAutoTest BuildInTestObj
        {
            get
            {
                return new GrapeCityAutoTest();
            }
        }

        internal Rectangle ContentRectangle
        {
            get
            {
                if (this.WebDriver == null)
                {
                    return Rectangle.Empty;
                }
                if ((this._catchedContentBounds != Rectangle.Empty) && !string.IsNullOrEmpty(this._catchedCurrentURL))
                {
                    string str = this.WebDriver.get_Url();
                    if (!str.Equals(this._catchedCurrentURL, StringComparison.OrdinalIgnoreCase))
                    {
                        this._catchedCurrentURL = str;
                        this._catchedContentBounds = Rectangle.Empty;
                    }
                }
                if (this._catchedContentBounds == Rectangle.Empty)
                {
                    this._catchedContentBounds = this.BrowserContentRectangle;
                }
                return this._catchedContentBounds;
            }
        }

        public Selenium.Test.Toolkit.BOMObject.Document Document
        {
            get
            {
                return this.BOMWindow.document;
            }
        }

        public int DocumentScrollLeft
        {
            get
            {
                return Convert.ToInt32((this.WebDriver as IJavaScriptExecutor).ExecuteScript("return Math.max(document.documentElement.scrollLeft, document.body.scrollLeft);", new object[0]));
            }
        }

        public int DocumentScrollTop
        {
            get
            {
                return Convert.ToInt32((this.WebDriver as IJavaScriptExecutor).ExecuteScript("return Math.max(document.documentElement.scrollTop, document.body.scrollTop);", new object[0]));
            }
        }

        public bool IsRemote
        {
            get
            {
                return this.Settings.IsRemote;
            }
        }

        public string MainWindowHandle { get; private set; }

        public Point Position
        {
            get
            {
                return this.WebDriver.Manage().get_Window().get_Position();
            }
            set
            {
                this._catchedBrowserContentBounds = Rectangle.Empty;
                this._catchedContentBounds = Rectangle.Empty;
                this._catchedCurrentURL = null;
                this.WebDriver.Manage().get_Window().set_Position(value);
            }
        }

        private TestSettings Settings
        {
            get
            {
                return this._settings;
            }
        }

        public System.Drawing.Size Size
        {
            get
            {
                return this.WebDriver.Manage().get_Window().get_Size();
            }
            set
            {
                this._catchedBrowserContentBounds = Rectangle.Empty;
                this._catchedContentBounds = Rectangle.Empty;
                this._catchedCurrentURL = null;
                this.WebDriver.Manage().get_Window().set_Size(value);
            }
        }

        public DomElementGUI StyleConverter
        {
            get
            {
                return this.BuildInTestObj.InvokeJSMehtod<DomElementGUI>("getStyleConverterDom", new object[0]);
            }
        }

        public virtual bool UseResourceTextFinder { get; set; }

        public IWebDriver WebDriver
        {
            get
            {
                if (this._webDriver == null)
                {
                    this.CheckBrowserLaunchStatus = true;
                    this._webDriver = this.CreateWebDriver();
                    if (string.IsNullOrEmpty(this.MainWindowHandle))
                    {
                        this.MainWindowHandle = this._webDriver.get_CurrentWindowHandle();
                    }
                }
                return this._webDriver;
            }
        }

        public int WindowCount
        {
            get
            {
                if (this._webDriver == null)
                {
                    return 0;
                }
                return this.WebDriver.get_WindowHandles().Count;
            }
        }
    }
}

