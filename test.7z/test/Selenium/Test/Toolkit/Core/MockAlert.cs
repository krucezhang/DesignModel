﻿namespace Selenium.Test.Toolkit.Core
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Serialization;
    using System;

    public class MockAlert : IAlert
    {
        private static MockAlert _alert;
        internal static bool IsAcceptAlert = true;
        internal static string MockAlertScript = "alert = function(text){window.alertText = text;GrapeCityAutoTest.setCookie('_ATAlertText',text,null);};confirm = function(text){window.alertText = text;GrapeCityAutoTest.setCookie('_ATAlertText',text,null);return true;};";
        internal static string MockDismissAlertScript = "alert = function(text){window.alertText = text;GrapeCityAutoTest.setCookie('_ATAlertText',text,null);};confirm = function(text){window.alertText = text;GrapeCityAutoTest.setCookie('_ATAlertText',text,null);return false;};";

        public void Accept()
        {
            IsAcceptAlert = true;
            Manager.Current.ActiveBrowser.WebDriver.ExecuteScript(MockAlertScript, new object[0]);
        }

        public void ClearAlertTextCache()
        {
            new JSObject();
            Manager.Current.ActiveBrowser.WebDriver.ExecuteScript("if(window.alertText){window.alertText = undefined;};if(window.GrapeCityAutoTest){window.GrapeCityAutoTest.delCookie('_ATAlertText');}", new object[0]);
        }

        public void Dismiss()
        {
            this.Accept();
        }

        protected virtual string GetAlertText()
        {
            new JSObject();
            IJavaScriptExecutor webDriver = Manager.Current.ActiveBrowser.WebDriver;
            return (webDriver.ExecuteScript("if(window.alertText){return window.alertText;}else{return window.GrapeCityAutoTest.getCookie('_ATAlertText');}", new object[0]) as string);
        }

        public void ProspectiveDismiss()
        {
            IsAcceptAlert = false;
            Manager.Current.ActiveBrowser.WebDriver.ExecuteScript(MockDismissAlertScript, new object[0]);
        }

        public void SendKeys(string keysToSend)
        {
        }

        public void SetAuthenticationCredentials(string userName, string password)
        {
        }

        public static MockAlert Instance
        {
            get
            {
                if (_alert == null)
                {
                    _alert = new MockAlert();
                }
                return _alert;
            }
        }

        public string Text
        {
            get
            {
                return this.GetAlertText();
            }
        }
    }
}

