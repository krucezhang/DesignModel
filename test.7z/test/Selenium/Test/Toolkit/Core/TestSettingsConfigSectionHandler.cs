﻿namespace Selenium.Test.Toolkit.Core
{
    using Selenium.Test.Toolkit.Action;
    using System;
    using System.Configuration;

    internal sealed class TestSettingsConfigSectionHandler : ConfigurationSection
    {
        private TestSettingsConfigSectionHandler()
        {
        }

        [ConfigurationProperty("ActionType", IsRequired=false, DefaultValue="Auto")]
        public Selenium.Test.Toolkit.Action.ActionType ActionType
        {
            get
            {
                return (Selenium.Test.Toolkit.Action.ActionType) Enum.Parse(typeof(Selenium.Test.Toolkit.Action.ActionType), Convert.ToString(base["ActionType"]));
            }
        }

        [ConfigurationProperty("BrowserType", IsRequired=true, DefaultValue="Firefox")]
        public Selenium.Test.Toolkit.Core.BrowserType BrowserType
        {
            get
            {
                return (Selenium.Test.Toolkit.Core.BrowserType) Enum.Parse(typeof(Selenium.Test.Toolkit.Core.BrowserType), Convert.ToString(base["BrowserType"]));
            }
        }

        [ConfigurationProperty("CommandTimeout", IsRequired=false)]
        public int CommandTimeout
        {
            get
            {
                return Convert.ToInt32(base["CommandTimeout"]);
            }
        }

        public static TestSettingsConfigSectionHandler ConfigTestSettings
        {
            get
            {
                return (ConfigurationManager.GetSection("SeleniumDriver") as TestSettingsConfigSectionHandler);
            }
        }

        [ConfigurationProperty("DriverPath", IsRequired=false, DefaultValue=null)]
        public string DriverPath
        {
            get
            {
                return Convert.ToString(base["DriverPath"]);
            }
        }

        [ConfigurationProperty("DriverType", IsRequired=true, DefaultValue="OpenQA.Selenium.Firefox.FirefoxDriver")]
        public string DriverType
        {
            get
            {
                return Convert.ToString(base["DriverType"]);
            }
        }

        [ConfigurationProperty("IsHeadless", IsRequired=false, DefaultValue="false")]
        public bool IsHeadless
        {
            get
            {
                return Convert.ToBoolean(base["IsHeadless"]);
            }
        }

        [ConfigurationProperty("IsRemote", IsRequired=false, DefaultValue="false")]
        public bool IsRemote
        {
            get
            {
                return Convert.ToBoolean(base["IsRemote"]);
            }
        }

        [ConfigurationProperty("RemoteAddress", IsRequired=false)]
        public string RemoteAddress
        {
            get
            {
                return Convert.ToString(base["RemoteAddress"]);
            }
        }
    }
}

