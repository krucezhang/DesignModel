﻿namespace Selenium.Test.Toolkit.Test
{
    using GrapeCity.Testing.Tools.Framework;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit;
    using Selenium.Test.Toolkit.Action;
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Configuration;
    using System.IO;
    using System.Runtime.InteropServices;

    public abstract class BaseTest : IDisposable
    {
        private static Assertion ____LoadTestFramework = null;
        private Selenium.Test.Toolkit.Core.Manager _currentManager;
        private int _currentRunCount;
        private static bool _ensureKillAllBrowsers = true;
        private static int _keepBrowserRunCount = 30;
        private const string ConfigSettingsString = "SeleniumDriver";
        private string mainTestPageHandle;
        private Microsoft.VisualStudio.TestTools.UnitTesting.TestContext testContextInstance;

        static BaseTest()
        {
            _keepBrowserRunCount = 30;
            _ensureKillAllBrowsers = true;
        }

        protected BaseTest()
        {
        }

        protected virtual void AfterInitializeTestDriver()
        {
        }

        public void AlertProspectiveDismiss()
        {
            if (this.Alert is MockAlert)
            {
                (this.Alert as MockAlert).ProspectiveDismiss();
            }
        }

        public virtual void AssertNumber(object expected, object actual, double delta = 0.0, string message = null)
        {
            Assert.AreEqual(Convert.ToDouble(expected), Convert.ToDouble(actual), delta, message);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            ShutDown(null);
            ClearOutputFile();
        }

        public void CleanUp()
        {
            if (((this._currentManager != null) && (this.ActiveBrowser.WebDriver != null)) && !Selenium.Test.Toolkit.Core.Manager.IgnoreAssertAlertDialog)
            {
                try
                {
                    IAlert alert = this.ActiveBrowser.WebDriver.SwitchTo().Alert();
                    if (alert != null)
                    {
                        alert.Dismiss();
                    }
                }
                catch
                {
                }
            }
            if ((this._currentManager != null) && (this._currentRunCount >= this.KeepBrowserRunCount))
            {
                ShutDown(this);
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        public static void ClearOutputFile()
        {
            string path = Path.Combine(FileHelper.CurrentAssemblyPath, "Output");
            if (Directory.Exists(path))
            {
                new DirectoryInfo(path).Delete(true);
            }
        }

        public virtual void Dispose()
        {
            this.testContextInstance = null;
        }

        public IUIActions GetActions(IWebElement webElement, ActionType actionType = 0)
        {
            return this.Manager.ActionFactory.GetUIActions(webElement, actionType);
        }

        public string GetBaseURL(string url)
        {
            return Path.Combine(this.Host, url);
        }

        public virtual string GetResourceFile(string relatedFilePath)
        {
            return Path.Combine(FileHelper.CurrentAssemblyPath, relatedFilePath);
        }

        public static TestSettings GetSettings()
        {
            TestSettingsConfigSectionHandler section = (TestSettingsConfigSectionHandler) ConfigurationManager.GetSection("SeleniumDriver");
            if (section == null)
            {
                return new TestSettings();
            }
            return new TestSettings(section);
        }

        public void Initialize()
        {
            this.Initialize(GetSettings());
        }

        public void Initialize(TestSettings settings)
        {
            if ((this._currentRunCount < this.KeepBrowserRunCount) && (Selenium.Test.Toolkit.Core.Manager.Current != null))
            {
                this._currentManager = Selenium.Test.Toolkit.Core.Manager.Current;
            }
            if (this._currentManager == null)
            {
                this._currentManager = new Selenium.Test.Toolkit.Core.Manager(settings);
                this.AfterInitializeTestDriver();
            }
            this._currentRunCount++;
        }

        public virtual void NavigateTestPage(string uri, bool isMaximize = true)
        {
            if (isMaximize)
            {
                this.ActiveBrowser.Maximize();
            }
            this.ActiveBrowser.GoToUrl(uri);
            this.mainTestPageHandle = this.ActiveBrowser.WebDriver.get_CurrentWindowHandle();
        }

        public virtual void NavigateTestPage(Uri uri, bool isMaximize = true)
        {
            this.NavigateTestPage(uri.ToString(), isMaximize);
        }

        public virtual string OpenResourceFile(string relatedFilePath)
        {
            using (StreamReader reader = new StreamReader(this.GetResourceFile(relatedFilePath)))
            {
                return reader.ReadToEnd();
            }
        }

        public static void ShutDown(BaseTest testRunner = null)
        {
            if (testRunner == null)
            {
                if (Selenium.Test.Toolkit.Core.Manager.Current != null)
                {
                    BrowserType browserType = Selenium.Test.Toolkit.Core.Manager.Current.ActiveBrowser.BrowserType;
                    Selenium.Test.Toolkit.Core.Manager.Current.Dispose();
                }
            }
            else
            {
                testRunner._currentRunCount = 0;
                if (testRunner._currentManager != null)
                {
                    BrowserType type2 = testRunner._currentManager.ActiveBrowser.BrowserType;
                    testRunner._currentManager.Dispose();
                    testRunner._currentManager = null;
                }
            }
            TestUtility.CloseAllBrowsersWith(_ensureKillAllBrowsers, new string[] { "dwwin", "WerFault", "IEDriverServer", "chromedriver", "geckodriver", "operadriver", "MicrosoftWebDriver", "chrome360driver" });
        }

        [TestCleanup]
        public virtual void TestCleanup()
        {
            this.CleanUp();
        }

        [TestInitialize]
        public virtual void TestInitialize()
        {
            this.Initialize();
            this.mainTestPageHandle = null;
        }

        public virtual void Wait()
        {
            WaitHelper.Wait();
        }

        public virtual void Wait(float seconds)
        {
            WaitHelper.Wait(seconds);
        }

        public Browser ActiveBrowser
        {
            get
            {
                return this.Manager.ActiveBrowser;
            }
        }

        public IAlert Alert
        {
            get
            {
                return this.ActiveBrowser.Alert;
            }
        }

        public bool EnsureKillAllBrowsers
        {
            get
            {
                return _ensureKillAllBrowsers;
            }
            set
            {
                _ensureKillAllBrowsers = value;
            }
        }

        public string Host
        {
            get
            {
                return ConfigurationManager.AppSettings["Host"];
            }
        }

        public int KeepBrowserRunCount
        {
            get
            {
                return _keepBrowserRunCount;
            }
            set
            {
                _keepBrowserRunCount = value;
            }
        }

        protected string MainTestPageHandle
        {
            get
            {
                return this.mainTestPageHandle;
            }
        }

        public Selenium.Test.Toolkit.Core.Manager Manager
        {
            get
            {
                return this._currentManager;
            }
        }

        public virtual string OutputPath
        {
            get
            {
                string path = Path.Combine(FileHelper.CurrentAssemblyPath, "Output" + Path.DirectorySeparatorChar);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                return path;
            }
        }

        public Microsoft.VisualStudio.TestTools.UnitTesting.TestContext TestContext
        {
            get
            {
                return this.testContextInstance;
            }
            set
            {
                this.testContextInstance = value;
            }
        }
    }
}

