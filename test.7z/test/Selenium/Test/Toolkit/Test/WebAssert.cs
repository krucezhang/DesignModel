﻿namespace Selenium.Test.Toolkit.Test
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    public static class WebAssert
    {
        public static void AssertNumber(object a, object b)
        {
            Assert.AreEqual(Convert.ToDouble(a), Convert.ToDouble(b), 0.0, "");
        }
    }
}

