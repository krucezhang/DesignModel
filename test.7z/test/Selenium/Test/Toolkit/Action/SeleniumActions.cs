﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using System;
    using System.Drawing;

    public class SeleniumActions : UIActionsBase
    {
        private IUIActions _jsActions;

        public SeleniumActions(IWebElement webElement) : base(webElement)
        {
        }

        public override void Dispose()
        {
            if (this._jsActions != null)
            {
                this._jsActions = null;
            }
            base.Dispose();
        }

        private DomElementGUI GetEffectElementGUI(Point point)
        {
            return new DomElementGUI(base.WebElement).GetEffectChildElementGUI(point.X, point.Y);
        }

        private Point TranslationPoint(DomElementGUI childGUI, Point point)
        {
            Point point2 = base.WebElement.get_Location();
            point2.Offset(point);
            Point location = childGUI.Location;
            return new Point(point2.X - location.X, point2.Y - location.Y);
        }

        public override void UIClearValue(Point point)
        {
            this.UIClick(point, MouseButtonType.Left);
            this.UIKeyPress(Keys.Home);
            this.UIModifierKeyDown(Keys.LeftShift);
            this.UIKeyPress(Keys.End);
            this.UIModifierKeyUp(Keys.LeftShift);
            this.UIKeyPress(Keys.Backspace);
            base.WebElement.Clear();
        }

        public override void UIClick(Point point, MouseButtonType mouseButtons)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                DomElementGUI effectElementGUI = this.GetEffectElementGUI(point);
                this.JavaScriptActions.UIClick(this.TranslationPoint(effectElementGUI, point), mouseButtons);
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.MoveToElement(base.WebElement, point.X, point.Y);
                if (mouseButtons == MouseButtonType.Left)
                {
                    actions.Click();
                }
                else
                {
                    actions.ContextClick();
                }
                actions.Perform();
            }
        }

        public override void UIDoubleClick(Point point)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                DomElementGUI effectElementGUI = this.GetEffectElementGUI(point);
                this.JavaScriptActions.UIDoubleClick(this.TranslationPoint(effectElementGUI, point));
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.MoveToElement(base.WebElement, point.X, point.Y).DoubleClick().Perform();
            }
        }

        public override void UIDragTo(Point from, Point to)
        {
            this.UIMouseDown(from);
            this.UIHover(to);
            this.UIMouseUp(to);
        }

        public override void UIHover(Point point)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                DomElementGUI effectElementGUI = this.GetEffectElementGUI(point);
                this.JavaScriptActions.UIHover(this.TranslationPoint(effectElementGUI, point));
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.MoveToElement(base.WebElement, point.X, point.Y).Perform();
            }
        }

        public override void UIKeyPress(string key)
        {
            this.UISendKeys(key);
        }

        public override void UIModifierKeyDown(string key)
        {
            Actions actions = new Actions(this.WebDriver);
            actions.KeyDown(base.WebElement, key).Perform();
        }

        public override void UIModifierKeyUp(string key)
        {
            Actions actions = new Actions(this.WebDriver);
            actions.KeyUp(base.WebElement, key).Perform();
        }

        public override void UIMouseDown(Point point)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                DomElementGUI effectElementGUI = this.GetEffectElementGUI(point);
                this.JavaScriptActions.UIMouseDown(this.TranslationPoint(effectElementGUI, point));
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.MoveToElement(base.WebElement, point.X, point.Y).ClickAndHold().Perform();
            }
        }

        public override void UIMouseUp(Point point)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                DomElementGUI effectElementGUI = this.GetEffectElementGUI(point);
                this.JavaScriptActions.UIMouseUp(this.TranslationPoint(effectElementGUI, point));
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.MoveToElement(base.WebElement, point.X, point.Y).Release().Perform();
            }
        }

        public override void UIMoveHover(Point point)
        {
            this.UIHover(point);
        }

        public override void UISendKeys(string keysToSend)
        {
            if (Manager.Current.ActiveBrowser.BrowserType == BrowserType.Safari)
            {
                this.JavaScriptActions.UISendKeys(keysToSend);
            }
            else
            {
                Actions actions = new Actions(this.WebDriver);
                actions.SendKeys(base.WebElement, keysToSend).Perform();
            }
        }

        private IUIActions JavaScriptActions
        {
            get
            {
                if (this._jsActions == null)
                {
                    this._jsActions = new Selenium.Test.Toolkit.Action.JavaScriptActions(base.WebElement);
                }
                return this._jsActions;
            }
        }
    }
}

