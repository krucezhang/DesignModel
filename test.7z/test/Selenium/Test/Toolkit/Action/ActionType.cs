﻿namespace Selenium.Test.Toolkit.Action
{
    using System;

    public enum ActionType
    {
        Auto,
        JavaScript,
        Selenium,
        SeleniumTouch,
        Windows
    }
}

