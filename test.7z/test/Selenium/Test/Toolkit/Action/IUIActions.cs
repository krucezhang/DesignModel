﻿namespace Selenium.Test.Toolkit.Action
{
    using System;
    using System.Drawing;

    public interface IUIActions
    {
        void UIClearValue(Point point);
        void UIClick(Point point, MouseButtonType mouseButtons);
        void UIDoubleClick(Point point);
        void UIDragTo(Point from, Point to);
        void UIHover(Point point);
        void UIKeyPress(string key);
        void UIModifierKeyDown(string key);
        void UIModifierKeyUp(string key);
        void UIMouseDown(Point point);
        void UIMouseUp(Point point);
        void UIMoveHover(Point point);
        void UISendKeys(string keysToSend);
    }
}

