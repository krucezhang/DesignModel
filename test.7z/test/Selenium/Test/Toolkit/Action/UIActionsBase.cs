﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using System;
    using System.Drawing;

    public abstract class UIActionsBase : IUIActions, IDisposable
    {
        private IWebElement _webElement;

        public UIActionsBase(IWebElement webElement)
        {
            this._webElement = webElement;
        }

        public virtual void Dispose()
        {
            this._webElement = null;
        }

        public virtual void UIClearValue(Point point)
        {
            this.WebElement.Clear();
        }

        public abstract void UIClick(Point point, MouseButtonType mouseButtons);
        public abstract void UIDoubleClick(Point point);
        public abstract void UIDragTo(Point from, Point to);
        public abstract void UIHover(Point point);
        public abstract void UIKeyPress(string key);
        public abstract void UIModifierKeyDown(string key);
        public abstract void UIModifierKeyUp(string key);
        public abstract void UIMouseDown(Point point);
        public abstract void UIMouseUp(Point point);
        public abstract void UIMoveHover(Point point);
        public abstract void UISendKeys(string keysToSend);

        protected virtual IWebDriver WebDriver
        {
            get
            {
                return Manager.Current.ActiveBrowser.WebDriver;
            }
        }

        internal IWebElement WebElement
        {
            get
            {
                return this._webElement;
            }
        }
    }
}

