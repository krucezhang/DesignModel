﻿namespace Selenium.Test.Toolkit.Action
{
    using System;

    public static class SimulateEventType
    {
        public static string Change = "change";
        public static string Click = "click";
        public static string DoubleClick = "dblclick";
        public static string Focus = "focus";
        public static string MouseDown = "mousedown";
        public static string MouseMove = "mousemove";
        public static string MouseOver = "mouseover";
        public static string MouseUp = "mouseup";
    }
}

