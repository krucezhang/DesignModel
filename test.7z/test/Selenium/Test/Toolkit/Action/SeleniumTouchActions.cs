﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using System;
    using System.Drawing;

    public class SeleniumTouchActions : SeleniumActions
    {
        public SeleniumTouchActions(IWebElement webElement) : base(webElement)
        {
        }

        public override void UIClick(Point point, MouseButtonType mouseButtons)
        {
            TouchActions actions = new TouchActions(this.WebDriver);
            actions.MoveToElement(base.WebElement, point.X, point.Y);
            if (mouseButtons == MouseButtonType.Left)
            {
                actions.SingleTap(base.WebElement);
            }
            else
            {
                actions.LongPress(base.WebElement);
            }
            actions.Perform();
        }

        public override void UIDoubleClick(Point point)
        {
            TouchActions actions = new TouchActions(this.WebDriver);
            actions.DoubleTap(base.WebElement).Perform();
        }
    }
}

