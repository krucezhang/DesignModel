﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.Desktop;
    using System;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;
    using TestStack.White.UIItems.WindowItems;

    public class WindowsActions : UIActionsBase
    {
        private static KeyBoard _keyboard;
        private static Mouse _mouse;

        public WindowsActions(IWebElement webElement) : base(webElement)
        {
        }

        private Point GetPointByScreem(Point point)
        {
            Point location = Manager.Current.ActiveBrowser.GetElementRectangleByScreem(base.WebElement).Location;
            location.Offset(point);
            return location;
        }

        private Keys KeysConvert(char value)
        {
            string str = value.ToString();
            if ((str == Keys.ArrowDown) || (str == Keys.Down))
            {
                return Keys.Down;
            }
            if ((str == Keys.ArrowUp) || (str == Keys.Up))
            {
                return Keys.Up;
            }
            if ((str == Keys.ArrowLeft) || (str == Keys.Left))
            {
                return Keys.Left;
            }
            if ((str == Keys.ArrowRight) || (str == Keys.Right))
            {
                return Keys.Right;
            }
            if (str == Keys.Enter)
            {
                return Keys.Enter;
            }
            if (str == Keys.Backspace)
            {
                return Keys.Back;
            }
            if (str == Keys.Space)
            {
                return Keys.Space;
            }
            if (str == Keys.Home)
            {
                return Keys.Home;
            }
            if (str == Keys.End)
            {
                return Keys.End;
            }
            if (str == Keys.Tab)
            {
                return Keys.Tab;
            }
            if (str == Keys.Delete)
            {
                return Keys.Delete;
            }
            if (str == Keys.Escape)
            {
                return Keys.Escape;
            }
            if (str == Keys.PageDown)
            {
                return Keys.Next;
            }
            if (str == Keys.PageUp)
            {
                return Keys.PageUp;
            }
            if (str == Keys.Semicolon)
            {
                return Keys.Oem1;
            }
            switch (str.ToLower())
            {
                case "a":
                    return Keys.A;

                case "b":
                    return Keys.B;

                case "c":
                    return Keys.C;

                case "d":
                    return Keys.D;

                case "e":
                    return Keys.E;

                case "f":
                    return Keys.F;

                case "g":
                    return Keys.G;

                case "h":
                    return Keys.H;

                case "i":
                    return Keys.I;

                case "j":
                    return Keys.J;

                case "k":
                    return Keys.K;

                case "l":
                    return Keys.L;

                case "m":
                    return Keys.M;

                case "n":
                    return Keys.N;

                case "o":
                    return Keys.O;

                case "p":
                    return Keys.P;

                case "q":
                    return Keys.Q;

                case "r":
                    return Keys.R;

                case "s":
                    return Keys.S;

                case "t":
                    return Keys.T;

                case "u":
                    return Keys.U;

                case "v":
                    return Keys.V;

                case "w":
                    return Keys.W;

                case "x":
                    return Keys.X;

                case "y":
                    return Keys.Y;

                case "z":
                    return Keys.Z;

                case "0":
                    return Keys.D0;

                case "1":
                    return Keys.D1;

                case "2":
                    return Keys.D2;

                case "3":
                    return Keys.D3;

                case "4":
                    return Keys.D4;

                case "5":
                    return Keys.D5;

                case "6":
                    return Keys.D6;

                case "7":
                    return Keys.D7;

                case "8":
                    return Keys.D8;

                case "9":
                    return Keys.D9;

                case "{":
                case "[":
                    return Keys.Oem4;

                case "}":
                case "]":
                    return Keys.Oem6;

                case "|":
                case @"\":
                    return Keys.Oem5;

                case ",":
                    return Keys.Oemcomma;

                case ";":
                    return Keys.Oem1;

                case ".":
                    return Keys.OemPeriod;
            }
            return Keys.None;
        }

        private void MessageFlush()
        {
            Browser activeBrowser = Manager.Current.ActiveBrowser;
            if ((activeBrowser.WebDriver != null) && Manager.DoMessageFlushAfterAction)
            {
                Win32NativeMethods.MSG lpMsg = new Win32NativeMethods.MSG();
                Window browserWindowFromDesktop = activeBrowser.GetBrowserWindowFromDesktop();
                IntPtr hwnd = new IntPtr(browserWindowFromDesktop.AutomationElement.Current.NativeWindowHandle);
                while (Win32NativeMethods.PeekMessage(ref lpMsg, hwnd, 0, 0, 0))
                {
                    try
                    {
                        if (browserWindowFromDesktop.ModalWindows().Count > 0)
                        {
                            break;
                        }
                    }
                    catch
                    {
                    }
                    Thread.Sleep(300);
                }
            }
        }

        internal static void ReleaseResource()
        {
            if (_keyboard != null)
            {
                _keyboard.Dispose();
                _keyboard = null;
            }
            if (_mouse != null)
            {
                _mouse.Dispose();
                _mouse = null;
            }
        }

        public override void UIClearValue(Point point)
        {
            this.UIClick(point, MouseButtonType.Left);
            this.UIKeyPress(Keys.Home);
            this.UIModifierKeyDown(Keys.LeftShift);
            this.UIKeyPress(Keys.End);
            this.UIModifierKeyUp(Keys.LeftShift);
            this.UIKeyPress(Keys.Backspace);
        }

        public override void UIClick(Point point, MouseButtonType mouseButtons)
        {
            if (mouseButtons == MouseButtonType.Left)
            {
                this.DesktopMouse.Click(MouseClickType.LeftClick, this.GetPointByScreem(point));
            }
            else
            {
                this.DesktopMouse.Click(MouseClickType.RightClick, this.GetPointByScreem(point));
            }
            this.MessageFlush();
        }

        public override void UIDoubleClick(Point point)
        {
            this.DesktopMouse.Click(MouseClickType.LeftDoubleClick, this.GetPointByScreem(point));
            this.MessageFlush();
        }

        public override void UIDragTo(Point from, Point to)
        {
            this.DesktopMouse.DragDrop(this.GetPointByScreem(from), this.GetPointByScreem(to));
            this.MessageFlush();
        }

        public override void UIHover(Point point)
        {
            this.DesktopMouse.HoverOver(this.GetPointByScreem(point));
            this.MessageFlush();
        }

        public override void UIKeyPress(string key)
        {
            this.DesktopKeyboard.KeyPress(this.KeysConvert(key.ToCharArray()[0]));
            this.MessageFlush();
        }

        public override void UIModifierKeyDown(string key)
        {
            if ((key == Keys.Control) || (key == Keys.LeftControl))
            {
                this.DesktopKeyboard.KeyDown(Keys.LControlKey);
            }
            if ((key == Keys.Alt) || (key == Keys.LeftAlt))
            {
                this.DesktopKeyboard.KeyDown(Keys.Alt);
            }
            if ((key == Keys.Shift) || (key == Keys.LeftShift))
            {
                this.DesktopKeyboard.KeyDown(Keys.LShiftKey);
            }
            this.MessageFlush();
        }

        public override void UIModifierKeyUp(string key)
        {
            if ((key == Keys.Control) || (key == Keys.LeftControl))
            {
                this.DesktopKeyboard.KeyUp(Keys.LControlKey);
            }
            if ((key == Keys.Alt) || (key == Keys.LeftAlt))
            {
                this.DesktopKeyboard.KeyUp(Keys.Alt);
            }
            if ((key == Keys.Shift) || (key == Keys.LeftShift))
            {
                this.DesktopKeyboard.KeyUp(Keys.LShiftKey);
            }
            this.MessageFlush();
        }

        public override void UIMouseDown(Point point)
        {
            this.DesktopMouse.Click(MouseClickType.LeftDown, this.GetPointByScreem(point));
            this.MessageFlush();
        }

        public override void UIMouseUp(Point point)
        {
            this.DesktopMouse.Click(MouseClickType.LeftUp, this.GetPointByScreem(point));
            this.MessageFlush();
        }

        public override void UIMoveHover(Point point)
        {
            Point mousePosition = Control.MousePosition;
            this.DesktopMouse.Move(mousePosition, this.GetPointByScreem(point));
            this.MessageFlush();
        }

        public override void UISendKeys(string keysToSend)
        {
            this.DesktopKeyboard.TypeText(keysToSend, 10);
            this.MessageFlush();
        }

        internal KeyBoard DesktopKeyboard
        {
            get
            {
                if (_keyboard == null)
                {
                    _keyboard = new KeyBoard(Manager.Current.ActiveBrowser);
                }
                return _keyboard;
            }
        }

        internal Mouse DesktopMouse
        {
            get
            {
                if (_mouse == null)
                {
                    _mouse = new Mouse(Manager.Current.ActiveBrowser);
                }
                return _mouse;
            }
        }
    }
}

