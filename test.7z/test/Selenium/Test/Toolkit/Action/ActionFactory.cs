﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using System;

    public class ActionFactory
    {
        public IUIActions GetUIActions(IWebElement webElement, ActionType actionType)
        {
            switch (actionType)
            {
                case ActionType.Auto:
                    if (!Manager.Current.TestSettings.IsWinPlatform || Manager.Current.ActiveBrowser.IsRemote)
                    {
                        return this.GetUIActions(webElement, ActionType.Selenium);
                    }
                    return this.GetUIActions(webElement, ActionType.Windows);

                case ActionType.JavaScript:
                    return new JavaScriptActions(webElement);

                case ActionType.Selenium:
                    return new SeleniumActions(webElement);

                case ActionType.SeleniumTouch:
                    return new SeleniumTouchActions(webElement);

                case ActionType.Windows:
                    return new WindowsActions(webElement);
            }
            throw new ArgumentException(string.Format("", actionType));
        }
    }
}

