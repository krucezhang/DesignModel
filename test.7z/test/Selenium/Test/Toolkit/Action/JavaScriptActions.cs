﻿namespace Selenium.Test.Toolkit.Action
{
    using OpenQA.Selenium;
    using Selenium.Test.Toolkit.Core;
    using Selenium.Test.Toolkit.GUI;
    using Selenium.Test.Toolkit.Serialization;
    using System;
    using System.Drawing;

    public class JavaScriptActions : UIActionsBase
    {
        public JavaScriptActions(IWebElement webElement) : base(webElement)
        {
        }

        private Point TransformPoint(Point point)
        {
            Point point2 = base.WebElement.get_Location();
            point2.Offset(point.X, point.Y);
            return point2;
        }

        public override void UIClick(Point point, MouseButtonType mouseButtons)
        {
            Point point2 = this.TransformPoint(point);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseMove, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseOver, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseDown, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseUp, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.Click, point2.X, point2.Y);
        }

        public override void UIDoubleClick(Point point)
        {
            Point point2 = this.TransformPoint(point);
            this.UIClick(point, MouseButtonType.Left);
            this.UIClick(point, MouseButtonType.Left);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.DoubleClick, point2.X, point2.Y);
        }

        public override void UIDragTo(Point from, Point to)
        {
            this.UIMouseDown(from);
            this.UIHover(to);
            this.UIMouseUp(to);
        }

        public override void UIHover(Point point)
        {
            Point point2 = this.TransformPoint(point);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseMove, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseOver, point2.X, point2.Y);
        }

        public override void UIKeyPress(string key)
        {
            this.UISendKeys(key);
        }

        public override void UIModifierKeyDown(string key)
        {
            throw new NotImplementedException();
        }

        public override void UIModifierKeyUp(string key)
        {
            throw new NotImplementedException();
        }

        public override void UIMouseDown(Point point)
        {
            Point point2 = this.TransformPoint(point);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseMove, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseOver, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseDown, point2.X, point2.Y);
        }

        public override void UIMouseUp(Point point)
        {
            Point point2 = this.TransformPoint(point);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseMove, point2.X, point2.Y);
            this.GrapeCityAutoTest.Simulate(this.ElementGUI, SimulateEventType.MouseUp, point2.X, point2.Y);
        }

        public override void UIMoveHover(Point point)
        {
            this.UIHover(point);
        }

        public override void UISendKeys(string keysToSend)
        {
            base.WebElement.SendKeys(keysToSend);
        }

        private DomElementGUI ElementGUI
        {
            get
            {
                return new DomElementGUI(base.WebElement);
            }
        }

        public Selenium.Test.Toolkit.Serialization.GrapeCityAutoTest GrapeCityAutoTest
        {
            get
            {
                return Manager.Current.GrapeCityAutoTest;
            }
        }
    }
}

